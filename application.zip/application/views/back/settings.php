
<div class="wrapper">
	<div class="container"> 
		<div class="row">
			<!--/.span3-->
			<div class="span9">
				<div class="content">
					<br>
					<div class="module">
						<div class="module-head">
							<h3><i class="menu-icon icon-cog"></i>  Settings</h3>
						</div>
						<div class="module-body">
					
					<li><a href="<?php echo base_url(); ?>sms_alert"> SMS ACCOUNT </a></li>
					<hr>
						<li><a href="<?php echo base_url(); ?>account_category_list"> Category Add </a></li>
					<hr>
	 
						</div>
					</div>
				</div>
				
				
			</div>
			
			
			
			<div class="span3">
				<div class="sidebar">
					<ul class="widget widget-menu unstyled">
								
								<li>
									<a href="<?php echo base_url(); ?>dashboard">
										<i class="menu-icon icon-dashboard"></i>
										Dashbaord
									</a>
								</li>
								
								<li>
									<a href="<?php echo base_url(); ?>students_archive">
										<i class="menu-icon icon-user"></i>
										Student List
									</a>
								</li>
								<li>
									<a href="<?php echo base_url(); ?>current_course">
										<i class="menu-icon icon-folder-open"></i>
										Active Course
									</a>
								</li>
								<li>
									<a href="<?php echo base_url(); ?>complited_course">
										<i class="menu-icon icon-list-alt"></i>
										Result
									</a>
								</li>
								<li>
									<a href="<?php echo base_url(); ?>attendance_record">
										<i class="menu-icon icon-ok"></i>
										Attendance
									</a>
								</li>
								<li>
									<a href="<?php echo base_url(); ?>staff_list">
										<i class="menu-icon icon-user"></i>
										Staffs
									</a>
								</li>
								<li>
									<a href="<?php echo base_url(); ?>report">
										<i class="menu-icon icon-print"></i>
										Report
									</a>
								</li>
							</ul><!--/.widget-nav-->
				</div><!--/.sidebar-->
			</div>
		</div>
	</div>
</div>


																										