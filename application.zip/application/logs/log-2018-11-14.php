<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-14 00:47:02 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 14
ERROR - 2018-11-14 00:47:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 14
ERROR - 2018-11-14 01:01:24 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 20
ERROR - 2018-11-14 01:01:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 20
ERROR - 2018-11-14 01:01:24 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 28
ERROR - 2018-11-14 01:01:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 28
ERROR - 2018-11-14 01:01:24 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 36
ERROR - 2018-11-14 01:01:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 36
ERROR - 2018-11-14 01:01:24 --> Severity: error --> Exception: Call to undefined function format_date() C:\xampp\htdocs\training\application\views\back\edit_staff.php 45
ERROR - 2018-11-14 01:04:03 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 27
ERROR - 2018-11-14 01:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 27
ERROR - 2018-11-14 01:04:04 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 35
ERROR - 2018-11-14 01:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 35
ERROR - 2018-11-14 01:04:04 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 43
ERROR - 2018-11-14 01:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 43
ERROR - 2018-11-14 01:04:04 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 52
ERROR - 2018-11-14 01:04:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 52
ERROR - 2018-11-14 01:04:04 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\edit_staff.php 6
ERROR - 2018-11-14 01:04:17 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 27
ERROR - 2018-11-14 01:04:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 27
ERROR - 2018-11-14 01:04:17 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 35
ERROR - 2018-11-14 01:04:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 35
ERROR - 2018-11-14 01:04:17 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 43
ERROR - 2018-11-14 01:04:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 43
ERROR - 2018-11-14 01:04:17 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 52
ERROR - 2018-11-14 01:04:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 52
ERROR - 2018-11-14 01:04:17 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\edit_staff.php 6
ERROR - 2018-11-14 01:15:02 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 21
ERROR - 2018-11-14 01:15:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 21
ERROR - 2018-11-14 01:15:04 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 21
ERROR - 2018-11-14 01:15:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 21
ERROR - 2018-11-14 01:15:15 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\views\back\edit_staff.php 21
ERROR - 2018-11-14 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_staff.php 21
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:39:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:40:49 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:40:56 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-14 01:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 01:54:05 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\training\application\views\back\edit_account_list.php 22
ERROR - 2018-11-14 02:03:25 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\training\application\views\back\edit_account_list.php 35
ERROR - 2018-11-14 02:09:55 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\training\application\views\back\account_list.php 134
ERROR - 2018-11-14 02:10:07 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\training\application\views\back\account_list.php 134
ERROR - 2018-11-14 02:13:01 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\edit_account_list.php 13
ERROR - 2018-11-14 02:13:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 13
ERROR - 2018-11-14 02:29:15 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\edit_account_list.php 20
ERROR - 2018-11-14 02:29:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 20
ERROR - 2018-11-14 02:29:15 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\edit_account_list.php 20
ERROR - 2018-11-14 02:29:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_account_list.php 20
