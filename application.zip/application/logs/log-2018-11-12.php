<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-12 17:45:15 --> Query error: Column 'stu_have_experience' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_password`, `stu_present_address`, `stu_permanent_address`, `stu_have_experience`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES ('', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', 'ff42f80492e2136a86210557e80d2094', '', '', NULL, '', '', '', '', '', '', '', '', '')
ERROR - 2018-11-12 17:45:15 --> Query error: Column 'stu_have_experience' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_password`, `stu_present_address`, `stu_permanent_address`, `stu_have_experience`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES ('', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', 'e195bdc11964ca96eb26c73312534da9', '', '', NULL, '', '', '', '', '', '', '', '', '')
ERROR - 2018-11-12 18:11:26 --> Severity: Notice --> Undefined variable: confirmations C:\xampp\htdocs\training\application\views\public\confirmation.php 48
ERROR - 2018-11-12 18:11:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\public\confirmation.php 48
ERROR - 2018-11-12 18:11:31 --> Severity: Notice --> Undefined variable: confirmations C:\xampp\htdocs\training\application\views\public\confirmation.php 48
ERROR - 2018-11-12 18:11:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\public\confirmation.php 48
ERROR - 2018-11-12 18:38:10 --> Severity: Notice --> Undefined property: stdClass::$stu_image C:\xampp\htdocs\training\application\views\public\confirmation.php 43
ERROR - 2018-11-12 18:46:41 --> Query error: Column 'stu_have_experience' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_username`, `stu_password`, `stu_present_address`, `stu_permanent_address`, `stu_have_experience`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES ('Shamim', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', 'Khayrul', '12d2cb48a690fbba323afcdaf05edb2b', '', '', NULL, '', '', '', '', '', '', '', '', '')
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 19:10:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 19:10:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 19:10:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 19:10:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 19:10:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 19:10:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 19:10:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 19:10:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 19:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 19:54:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 20:00:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-12 20:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
