<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-01 10:48:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\training\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-01 10:48:29 --> Unable to connect to the database
ERROR - 2018-11-01 10:49:08 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:49:08 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:49:34 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:49:34 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:50:20 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:50:20 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:50:32 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:50:32 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:50:40 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:50:40 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:51:00 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:51:00 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:54:36 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-11-01 10:54:36 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
