<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-27 03:10:22 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\training\application\views\back\login.php 80
ERROR - 2018-10-27 03:29:01 --> Severity: Notice --> Undefined property: stdClass::$admin_role C:\xampp\htdocs\training\application\controllers\Admin.php 68
ERROR - 2018-10-27 03:37:50 --> Severity: Notice --> Undefined property: stdClass::$admin_role C:\xampp\htdocs\training\application\controllers\Admin.php 68
ERROR - 2018-10-27 03:49:40 --> Severity: Notice --> Undefined property: stdClass::$admin_role C:\xampp\htdocs\training\application\controllers\Admin.php 68
ERROR - 2018-10-27 03:53:25 --> Severity: Notice --> Undefined property: stdClass::$admin_role C:\xampp\htdocs\training\application\controllers\Admin.php 68
ERROR - 2018-10-27 00:29:05 --> Severity: error --> Exception: Class Admin already exists and doesn't extend CI_Model C:\xampp\htdocs\training\system\core\Loader.php 353
ERROR - 2018-10-27 01:48:22 --> 404 Page Not Found: Login/index
ERROR - 2018-10-27 01:48:36 --> 404 Page Not Found: Login/index
ERROR - 2018-10-27 01:48:53 --> 404 Page Not Found: Login/index
ERROR - 2018-10-27 01:49:55 --> 404 Page Not Found: Login/index
ERROR - 2018-10-27 01:55:36 --> 404 Page Not Found: Logout/index
ERROR - 2018-10-27 01:56:36 --> 404 Page Not Found: Logout/index
ERROR - 2018-10-27 01:56:41 --> 404 Page Not Found: Logout/index
ERROR - 2018-10-27 02:01:37 --> 404 Page Not Found: Noticephp/index
ERROR - 2018-10-27 02:01:47 --> 404 Page Not Found: Indexhtml/index
ERROR - 2018-10-27 02:02:30 --> 404 Page Not Found: Course_listphp/index
ERROR - 2018-10-27 02:02:37 --> 404 Page Not Found: Students_archivephp/index
ERROR - 2018-10-27 02:12:56 --> 404 Page Not Found: Students_archivephp/index
ERROR - 2018-10-27 02:14:06 --> 404 Page Not Found: Adfdf/index
ERROR - 2018-10-27 02:14:12 --> 404 Page Not Found: Dsfdsf/index
ERROR - 2018-10-27 02:14:15 --> 404 Page Not Found: Sdfsdfds/index
ERROR - 2018-10-27 02:14:17 --> 404 Page Not Found: Sdfdsf/index
ERROR - 2018-10-27 02:49:57 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_category.php 24
ERROR - 2018-10-27 02:49:57 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_category.php 24
ERROR - 2018-10-27 02:49:57 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_category.php 76
ERROR - 2018-10-27 02:49:57 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_category.php 76
ERROR - 2018-10-27 02:49:57 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_category.php 85
ERROR - 2018-10-27 02:49:57 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_category.php 85
ERROR - 2018-10-27 02:52:17 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_category.php 76
ERROR - 2018-10-27 02:52:17 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_category.php 76
ERROR - 2018-10-27 02:52:17 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_category.php 85
ERROR - 2018-10-27 02:52:17 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_category.php 85
ERROR - 2018-10-27 03:37:27 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\training\application\controllers\AccountCategory.php 38
ERROR - 2018-10-27 03:38:18 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' C:\xampp\htdocs\training\application\controllers\AccountCategory.php 38
ERROR - 2018-10-27 03:38:19 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' C:\xampp\htdocs\training\application\controllers\AccountCategory.php 38
ERROR - 2018-10-27 06:50:50 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_account_category.php 52
ERROR - 2018-10-27 06:50:50 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_account_category.php 52
ERROR - 2018-10-27 06:50:50 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_account_category.php 61
ERROR - 2018-10-27 06:50:50 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_account_category.php 61
ERROR - 2018-10-27 06:51:04 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_account_category.php 109
ERROR - 2018-10-27 06:51:04 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_account_category.php 109
ERROR - 2018-10-27 12:07:59 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_notice.php 25
ERROR - 2018-10-27 12:07:59 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_notice.php 25
ERROR - 2018-10-27 12:07:59 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_notice.php 60
ERROR - 2018-10-27 12:07:59 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_notice.php 60
ERROR - 2018-10-27 12:08:56 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_notice.php 35
ERROR - 2018-10-27 12:08:56 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_notice.php 35
ERROR - 2018-10-27 12:08:58 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_notice.php 35
ERROR - 2018-10-27 12:08:58 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_notice.php 35
ERROR - 2018-10-27 13:06:39 --> Severity: Compile Error --> Cannot redeclare AccountCategory::save_account_category() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 45
ERROR - 2018-10-27 13:06:52 --> Severity: Compile Error --> Cannot redeclare AccountCategory::save_account_category() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 45
ERROR - 2018-10-27 13:08:03 --> Severity: Compile Error --> Cannot redeclare AccountCategory::save_account_category() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 45
ERROR - 2018-10-27 13:08:04 --> Severity: Compile Error --> Cannot redeclare AccountCategory::save_account_category() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 45
ERROR - 2018-10-27 13:08:05 --> Severity: Compile Error --> Cannot redeclare AccountCategory::save_account_category() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 45
ERROR - 2018-10-27 13:08:53 --> Severity: Compile Error --> Cannot redeclare AccountCategory::save_account_category() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 45
ERROR - 2018-10-27 13:08:55 --> Severity: Compile Error --> Cannot redeclare AccountCategory::save_account_category() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 45
ERROR - 2018-10-27 13:08:56 --> Severity: Compile Error --> Cannot redeclare AccountCategory::save_account_category() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 45
ERROR - 2018-10-27 14:11:27 --> Severity: Notice --> Undefined variable: gfd C:\xampp\htdocs\training\application\controllers\AccountCategory.php 35
ERROR - 2018-10-27 14:11:33 --> Severity: Notice --> Undefined variable: gfd C:\xampp\htdocs\training\application\controllers\AccountCategory.php 35
ERROR - 2018-10-27 14:13:25 --> Severity: Notice --> Undefined variable: acc_cat_title C:\xampp\htdocs\training\application\controllers\AccountCategory.php 37
ERROR - 2018-10-27 14:19:39 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\account_category_list.php 52
ERROR - 2018-10-27 14:19:39 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\account_category_list.php 52
ERROR - 2018-10-27 14:19:39 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\account_category_list.php 61
ERROR - 2018-10-27 14:19:39 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\account_category_list.php 61
ERROR - 2018-10-27 14:19:51 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\account_category_list.php 52
ERROR - 2018-10-27 14:19:51 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\account_category_list.php 52
ERROR - 2018-10-27 14:30:47 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_category_list.php 37
ERROR - 2018-10-27 14:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_category_list.php 37
ERROR - 2018-10-27 14:30:47 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_category_list.php 37
ERROR - 2018-10-27 14:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_category_list.php 37
ERROR - 2018-10-27 14:30:47 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_category_list.php 37
ERROR - 2018-10-27 14:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_category_list.php 37
ERROR - 2018-10-27 14:30:47 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_category_list.php 37
ERROR - 2018-10-27 14:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_category_list.php 37
ERROR - 2018-10-27 15:02:41 --> Severity: error --> Exception: Call to undefined method AccountCategorymodel::delete_account_caetgory() C:\xampp\htdocs\training\application\controllers\AccountCategory.php 73
ERROR - 2018-10-27 15:43:38 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\account_list.php 57
ERROR - 2018-10-27 15:43:38 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\account_list.php 57
ERROR - 2018-10-27 16:09:41 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-27 16:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-27 16:13:45 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-27 16:13:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-27 17:11:35 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-27 17:11:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-27 17:12:13 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-27 17:12:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-27 18:00:08 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:11 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:38 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:39 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:42 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:00:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:01:03 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:01:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:01:06 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:01:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:01:10 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:01:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:01:22 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:01:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:02:18 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:02:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:02:53 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:02:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:03:14 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:03:14 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'hgjghjgj', '2018-10-17', '2018-10-25')
ERROR - 2018-10-27 18:08:37 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:08:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:09:35 --> Severity: error --> Exception: syntax error, unexpected ':', expecting ';' C:\xampp\htdocs\training\application\views\back\account_list.php 78
ERROR - 2018-10-27 18:09:55 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:09:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:15:37 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:15:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:16:52 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:16:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:17:02 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:17:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:19:05 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:19:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:19:07 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:19:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:19:50 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:19:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:20:03 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:20:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:20:46 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:20:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:20:57 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 18:26:04 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`account_id`
ERROR - 2018-10-27 18:28:35 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:28:37 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:28:47 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:28:49 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:30:56 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:34:13 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:34:15 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:34:33 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:34:34 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 18:36:33 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:36:33 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'test', '2018-10-08', '2018-10-17')
ERROR - 2018-10-27 18:40:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:40:15 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'testghf', '2018-10-10', '2018-10-12')
ERROR - 2018-10-27 18:48:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:48:10 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'vcnbgn', '2018-10-09', '2018-10-17')
ERROR - 2018-10-27 18:50:41 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:50:41 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, NULL, NULL, NULL)
ERROR - 2018-10-27 18:50:55 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:50:55 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'vcnbgn', '2018-10-10', '2018-10-17')
ERROR - 2018-10-27 18:51:08 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:51:08 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, NULL, NULL, NULL)
ERROR - 2018-10-27 18:51:10 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:51:10 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, NULL, NULL, NULL)
ERROR - 2018-10-27 18:51:15 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:51:15 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'vcnbgn', '2018-10-10', '2018-10-17')
ERROR - 2018-10-27 18:53:30 --> Severity: error --> Exception: syntax error, unexpected '$rows' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Account.php 35
ERROR - 2018-10-27 18:53:49 --> Severity: error --> Exception: syntax error, unexpected '$row' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Account.php 35
ERROR - 2018-10-27 18:53:59 --> Severity: error --> Exception: syntax error, unexpected '$row' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Account.php 35
ERROR - 2018-10-27 18:55:36 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:55:37 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'vcnbgn', '2018-10-23', '2018-10-17')
ERROR - 2018-10-27 18:56:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 18:56:32 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'ghjhgj', '2018-10-02', '2018-10-08')
ERROR - 2018-10-27 19:15:13 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\system\database\DB_driver.php 1477
ERROR - 2018-10-27 19:15:13 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `tbl_account` (`categories`, `acc_cat_id`, `account_description`, `account_cash_in`, `account_cash_out`) VALUES (Array, NULL, 'ghjhgjrsgt', '2018-10-18', '2018-10-17')
ERROR - 2018-10-27 19:31:18 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 19:46:10 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 19:46:18 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 19:46:18 --> Query error: Not unique table/alias: 'tbl_account_category' - Invalid query: SELECT *
FROM `tbl_account_category`
JOIN `tbl_account_category` ON `tbl_account_category`.`acc_cat_id` = `tbl_account`.`acc_cat_id`
ERROR - 2018-10-27 19:47:33 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 19:47:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 75
ERROR - 2018-10-27 20:00:56 --> Severity: Notice --> Undefined property: stdClass::$acc_cat_title C:\xampp\htdocs\training\application\views\back\account_list.php 47
ERROR - 2018-10-27 20:00:56 --> Severity: Notice --> Undefined property: stdClass::$acc_cat_title C:\xampp\htdocs\training\application\views\back\account_list.php 47
ERROR - 2018-10-27 20:00:56 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 87
ERROR - 2018-10-27 20:00:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 87
ERROR - 2018-10-27 20:01:42 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 87
ERROR - 2018-10-27 20:01:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 87
ERROR - 2018-10-27 20:57:18 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-27 20:57:18 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-27 20:57:18 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-27 20:57:18 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-27 20:57:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'account_description', 1 = 'ghjhgjrsgt', 2 = 'acc_cat_id', 3 = NULL, 4 = 'ac' at line 1 - Invalid query: UPDATE `tbl_account` SET 0 = 'account_description', 1 = 'ghjhgjrsgt', 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_cash_in', 5 = '', 6 = 'account_cash_out', 7 = ''
WHERE `account_id` = '2'
ERROR - 2018-10-27 20:59:54 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-27 20:59:54 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-27 20:59:54 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-27 20:59:54 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-27 20:59:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'account_description', 1 = 'testing purpos', 2 = 'acc_cat_id', 3 = NULL, 4 =' at line 1 - Invalid query: UPDATE `tbl_account` SET 0 = 'account_description', 1 = 'testing purpos', 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_cash_in', 5 = '', 6 = 'account_cash_out', 7 = ''
WHERE `account_id` = '3'
ERROR - 2018-10-27 21:01:17 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-27 21:01:17 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-27 21:01:17 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-27 21:01:17 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-27 21:01:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'account_description', 1 = NULL, 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_ca' at line 1 - Invalid query: UPDATE `tbl_account` SET 0 = 'account_description', 1 = NULL, 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_cash_in', 5 = NULL, 6 = 'account_cash_out', 7 = NULL
WHERE `account_id` = '3'
ERROR - 2018-10-27 21:01:18 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-27 21:01:18 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-27 21:01:18 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-27 21:01:18 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-27 21:01:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'account_description', 1 = NULL, 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_ca' at line 1 - Invalid query: UPDATE `tbl_account` SET 0 = 'account_description', 1 = NULL, 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_cash_in', 5 = NULL, 6 = 'account_cash_out', 7 = NULL
WHERE `account_id` = '3'
ERROR - 2018-10-27 21:01:24 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-27 21:01:25 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-27 21:01:25 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-27 21:01:25 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-27 21:01:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'account_description', 1 = 'jhgjk', 2 = 'acc_cat_id', 3 = NULL, 4 = 'account' at line 1 - Invalid query: UPDATE `tbl_account` SET 0 = 'account_description', 1 = 'jhgjk', 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_cash_in', 5 = '', 6 = 'account_cash_out', 7 = ''
WHERE `account_id` = '1'
ERROR - 2018-10-27 21:05:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'account_description', 1 = 'jhgjkvcnvcbn', 2 = 'acc_cat_id', 3 = NULL, 4 = '' at line 1 - Invalid query: UPDATE `tbl_account` SET 0 = 'account_description', 1 = 'jhgjkvcnvcbn', 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_cash_in', 5 = '2018-10-11', 6 = 'account_cash_out', 7 = '2018-10-18'
WHERE `account_id` = '1'
ERROR - 2018-10-27 21:15:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0 = 'account_description', 1 = 'jhgjkcn', 2 = 'acc_cat_id', 3 = NULL, 4 = 'accou' at line 1 - Invalid query: UPDATE `tbl_account` SET 0 = 'account_description', 1 = 'jhgjkcn', 2 = 'acc_cat_id', 3 = NULL, 4 = 'account_cash_in', 5 = '2018-10-11', 6 = 'account_cash_out', 7 = '2018-10-16'
WHERE `account_id` = '1'
ERROR - 2018-10-27 21:16:41 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-27 21:16:41 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-27 21:16:41 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-27 21:16:41 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-27 21:17:19 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-27 21:17:19 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-27 21:17:19 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-27 21:17:19 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-27 21:31:11 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 87
ERROR - 2018-10-27 21:31:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 87
ERROR - 2018-10-27 21:31:12 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_list.php 167
ERROR - 2018-10-27 21:31:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_list.php 167
ERROR - 2018-10-27 22:42:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\controllers\Staff.php 32
ERROR - 2018-10-27 22:42:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 32
ERROR - 2018-10-27 23:20:16 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\training\application\views\back\staff_list.php 54
ERROR - 2018-10-27 23:20:16 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\training\application\views\back\staff_list.php 59
ERROR - 2018-10-27 23:20:16 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\training\application\views\back\staff_list.php 54
ERROR - 2018-10-27 23:20:16 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\training\application\views\back\staff_list.php 59
ERROR - 2018-10-27 23:20:16 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\training\application\views\back\staff_list.php 54
ERROR - 2018-10-27 23:20:16 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\training\application\views\back\staff_list.php 59
ERROR - 2018-10-27 23:52:29 --> Severity: Notice --> Undefined variable: staff_fullname C:\xampp\htdocs\training\application\models\Staffmodel.php 33
ERROR - 2018-10-27 23:52:30 --> Severity: Notice --> Undefined variable: staff_designation C:\xampp\htdocs\training\application\models\Staffmodel.php 34
ERROR - 2018-10-27 23:52:30 --> Severity: Notice --> Undefined variable: staff_joining_date C:\xampp\htdocs\training\application\models\Staffmodel.php 35
ERROR - 2018-10-27 23:52:30 --> Severity: Notice --> Undefined variable: staff_cnumber C:\xampp\htdocs\training\application\models\Staffmodel.php 36
ERROR - 2018-10-27 23:52:30 --> Severity: error --> Exception: Call to undefined method Staffmodel::edit_staff_info() C:\xampp\htdocs\training\application\controllers\Staff.php 145
ERROR - 2018-10-27 23:58:22 --> Severity: Notice --> Undefined variable: staff_fullname C:\xampp\htdocs\training\application\models\Staffmodel.php 33
ERROR - 2018-10-27 23:58:22 --> Severity: Notice --> Undefined variable: staff_designation C:\xampp\htdocs\training\application\models\Staffmodel.php 34
ERROR - 2018-10-27 23:58:22 --> Severity: Notice --> Undefined variable: staff_joining_date C:\xampp\htdocs\training\application\models\Staffmodel.php 35
ERROR - 2018-10-27 23:58:22 --> Severity: Notice --> Undefined variable: staff_cnumber C:\xampp\htdocs\training\application\models\Staffmodel.php 36
