<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-26 20:39:52 --> 404 Page Not Found: Assets/plugins
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-26 20:39:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-26 20:39:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-26 20:40:06 --> 404 Page Not Found: Uploads/favicon.PNG
ERROR - 2018-10-26 20:58:45 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\hrms\application\controllers\Notice.php 186
ERROR - 2018-10-26 20:58:45 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\hrms\application\controllers\Notice.php 186
ERROR - 2018-10-26 21:54:03 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-26 21:54:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-26 21:55:03 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_project.php 91
ERROR - 2018-10-26 21:55:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_project.php 91
ERROR - 2018-10-26 21:55:03 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\add_project.php 102
ERROR - 2018-10-26 21:55:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_project.php 102
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Bootstrap/css
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Scripts/jquery-1.9.1.min.js
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Scripts/jquery-ui-1.10.1.custom.min.js
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Images/icons
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Bootstrap/css
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Css/theme.css
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Scripts/datatables
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Bootstrap/js
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Scripts/jquery-ui-1.10.1.custom.min.js
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Bootstrap/js
ERROR - 2018-10-26 23:06:07 --> 404 Page Not Found: Scripts/datatables
ERROR - 2018-10-26 23:25:26 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2018-10-26 23:25:35 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Uploads/important
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:25:36 --> 404 Page Not Found: Uploads/favicon.PNG
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Uploads/important
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:01 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/bower_components
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:29:02 --> 404 Page Not Found: Assets/dist
ERROR - 2018-10-26 23:52:10 --> 404 Page Not Found: Images/user.png
ERROR - 2018-10-26 23:53:05 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2018-10-26 23:53:36 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2018-10-26 23:55:47 --> 404 Page Not Found: Certificates_archivephp/index
ERROR - 2018-10-26 23:56:00 --> 404 Page Not Found: Course_listphp/index
ERROR - 2018-10-26 23:56:06 --> 404 Page Not Found: Course_listphp/index
ERROR - 2018-10-26 23:56:25 --> 404 Page Not Found: Batch_listphp/index
