<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Undefined variable: client C:\xampp\htdocs\hrms\application\views\stock_category_list.php 56
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\stock_category_list.php 56
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Undefined variable: client C:\xampp\htdocs\hrms\application\views\stock_category_list.php 58
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\stock_category_list.php 58
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Undefined variable: client C:\xampp\htdocs\hrms\application\views\stock_category_list.php 56
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\stock_category_list.php 56
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Undefined variable: client C:\xampp\htdocs\hrms\application\views\stock_category_list.php 58
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\stock_category_list.php 58
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Undefined variable: client C:\xampp\htdocs\hrms\application\views\stock_category_list.php 56
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\stock_category_list.php 56
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Undefined variable: client C:\xampp\htdocs\hrms\application\views\stock_category_list.php 58
ERROR - 2018-10-24 00:00:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\stock_category_list.php 58
ERROR - 2018-10-24 00:23:11 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Stock_categorymodel.php 72
ERROR - 2018-10-24 00:25:10 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Stock_categorymodel.php 73
ERROR - 2018-10-24 00:25:11 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Stock_categorymodel.php 73
ERROR - 2018-10-24 00:25:12 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Stock_categorymodel.php 73
ERROR - 2018-10-24 00:25:12 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Stock_categorymodel.php 73
ERROR - 2018-10-24 00:25:13 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Stock_categorymodel.php 73
ERROR - 2018-10-24 00:26:21 --> Severity: Notice --> Undefined property: Stock_category::$stocK_categorymodel C:\xampp\htdocs\hrms\application\controllers\Stock_category.php 79
ERROR - 2018-10-24 00:26:21 --> Severity: error --> Exception: Call to a member function update_stock_category() on null C:\xampp\htdocs\hrms\application\controllers\Stock_category.php 79
ERROR - 2018-10-24 00:29:18 --> Severity: Notice --> Undefined property: Stock_category::$stocK_categorymodel C:\xampp\htdocs\hrms\application\controllers\Stock_category.php 79
ERROR - 2018-10-24 00:29:18 --> Severity: error --> Exception: Call to a member function update_stock_category() on null C:\xampp\htdocs\hrms\application\controllers\Stock_category.php 79
ERROR - 2018-10-24 00:30:22 --> Severity: Notice --> Undefined property: Stock_category::$stocK_categorymodel C:\xampp\htdocs\hrms\application\controllers\Stock_category.php 105
ERROR - 2018-10-24 00:30:22 --> Severity: error --> Exception: Call to a member function delete_stock_category() on null C:\xampp\htdocs\hrms\application\controllers\Stock_category.php 105
