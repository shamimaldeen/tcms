<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-21 01:13:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL' at line 3 - Invalid query: DELETE FROM `department`
WHERE `dept_id` = '9'
AND  IS NULL
ERROR - 2018-10-21 01:15:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'IS NULL' at line 3 - Invalid query: DELETE FROM `department`
WHERE `dept_id` = '9'
AND  IS NULL
ERROR - 2018-10-21 00:00:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Designation.php 70
ERROR - 2018-10-21 00:00:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Designation.php 71
ERROR - 2018-10-21 00:00:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Designation.php 75
ERROR - 2018-10-21 00:00:20 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_designation.php 37
ERROR - 2018-10-21 00:00:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_designation.php 37
ERROR - 2018-10-21 00:00:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Designation.php 70
ERROR - 2018-10-21 00:00:28 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Designation.php 71
ERROR - 2018-10-21 00:00:28 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_designation.php 37
ERROR - 2018-10-21 00:00:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_designation.php 37
ERROR - 2018-10-21 00:00:51 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_designation.php 37
ERROR - 2018-10-21 00:00:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_designation.php 37
ERROR - 2018-10-21 00:01:21 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\designation_list.php 54
ERROR - 2018-10-21 00:01:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\designation_list.php 54
ERROR - 2018-10-21 00:05:38 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\designation_list.php 54
ERROR - 2018-10-21 00:05:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\designation_list.php 54
ERROR - 2018-10-21 00:07:43 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\designation_list.php 54
ERROR - 2018-10-21 00:07:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\designation_list.php 54
ERROR - 2018-10-21 00:08:24 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hrms\application\views\designation_list.php 5
ERROR - 2018-10-21 00:08:34 --> Severity: error --> Exception: syntax error, unexpected 's' (T_STRING) C:\xampp\htdocs\hrms\application\views\designation_list.php 50
ERROR - 2018-10-21 00:12:06 --> 404 Page Not Found: Save_designation/index
ERROR - 2018-10-21 00:15:38 --> 404 Page Not Found: Edit_designation/1
ERROR - 2018-10-21 00:16:10 --> Severity: Compile Error --> Cannot redeclare Designation::designation_list() C:\xampp\htdocs\hrms\application\controllers\Designation.php 82
ERROR - 2018-10-21 00:16:56 --> 404 Page Not Found: Edit_designation/5
ERROR - 2018-10-21 00:17:36 --> 404 Page Not Found: Edit_designation/5
ERROR - 2018-10-21 00:17:37 --> 404 Page Not Found: Edit_designation/5
ERROR - 2018-10-21 00:17:37 --> 404 Page Not Found: Edit_designation/5
ERROR - 2018-10-21 00:18:56 --> 404 Page Not Found: Edit_designation/5
ERROR - 2018-10-21 00:18:57 --> 404 Page Not Found: Edit_designation/5
ERROR - 2018-10-21 00:18:58 --> 404 Page Not Found: Edit_designation/5
ERROR - 2018-10-21 00:19:12 --> 404 Page Not Found: Edit_designation/4
ERROR - 2018-10-21 00:19:18 --> 404 Page Not Found: Edit_designation/6
ERROR - 2018-10-21 00:19:20 --> 404 Page Not Found: Edit_designation/3
ERROR - 2018-10-21 00:21:01 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_designation.php 37
ERROR - 2018-10-21 00:21:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_designation.php 37
ERROR - 2018-10-21 00:21:10 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_designation.php 37
ERROR - 2018-10-21 00:21:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_designation.php 37
ERROR - 2018-10-21 00:23:11 --> 404 Page Not Found: Edit_designation/index
ERROR - 2018-10-21 00:23:46 --> Severity: Notice --> Undefined variable: datap C:\xampp\htdocs\hrms\application\controllers\Designation.php 91
ERROR - 2018-10-21 12:36:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-21 12:36:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-21 12:36:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-21 12:36:43 --> 404 Page Not Found: Uploads/favicon.PNG
ERROR - 2018-10-21 13:10:16 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 117
ERROR - 2018-10-21 13:10:16 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 117
ERROR - 2018-10-21 13:10:16 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Designationmodel.php 29
ERROR - 2018-10-21 13:10:16 --> Query error: Column 'dept_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `designation`
JOIN `department` ON `department`.`dept_id` = `designation`.`dept_id`
WHERE `dept_id` IS NULL
AND `desig_name` IS NULL
AND `desig_id` IS NULL
ERROR - 2018-10-21 13:12:10 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:12:10 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:12:10 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Designationmodel.php 29
ERROR - 2018-10-21 13:12:10 --> Query error: Column 'dept_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `designation`
JOIN `department` ON `department`.`dept_id` = `designation`.`dept_id`
WHERE `dept_id` IS NULL
AND `desig_name` IS NULL
AND `desig_id` IS NULL
ERROR - 2018-10-21 13:12:15 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:12:15 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:12:15 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Designationmodel.php 29
ERROR - 2018-10-21 13:12:15 --> Query error: Column 'dept_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `designation`
JOIN `department` ON `department`.`dept_id` = `designation`.`dept_id`
WHERE `dept_id` IS NULL
AND `desig_name` IS NULL
AND `desig_id` IS NULL
ERROR - 2018-10-21 13:13:57 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:13:57 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 126
ERROR - 2018-10-21 13:13:57 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 126
ERROR - 2018-10-21 13:13:57 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 13:13:57 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 13:14:40 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:14:40 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 126
ERROR - 2018-10-21 13:14:40 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 126
ERROR - 2018-10-21 13:14:40 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 13:14:40 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 13:16:33 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:16:33 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 126
ERROR - 2018-10-21 13:16:33 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 13:17:22 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:17:22 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 126
ERROR - 2018-10-21 13:17:22 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 13:17:51 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:17:51 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 126
ERROR - 2018-10-21 13:17:51 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 13:21:07 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:22:22 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 13:22:22 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 13:22:22 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 128
ERROR - 2018-10-21 16:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-21 16:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-21 16:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-21 16:51:06 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 16:51:06 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 16:51:06 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 128
ERROR - 2018-10-21 17:05:47 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 118
ERROR - 2018-10-21 17:05:47 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 127
ERROR - 2018-10-21 17:05:47 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 128
ERROR - 2018-10-21 17:14:22 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 120
ERROR - 2018-10-21 17:14:22 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 120
ERROR - 2018-10-21 17:14:22 --> Query error: Column 'dept_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `designation`
JOIN `department` ON `department`.`dept_id` = `designation`.`dept_id`
WHERE `desig_name` IS NULL
AND `dept_id` IS NULL
ERROR - 2018-10-21 17:14:40 --> Severity: Notice --> Undefined variable: dept_id C:\xampp\htdocs\hrms\application\controllers\Designation.php 120
ERROR - 2018-10-21 17:14:40 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 120
ERROR - 2018-10-21 17:14:40 --> Query error: Column 'dept_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `designation`
JOIN `department` ON `department`.`dept_id` = `designation`.`dept_id`
WHERE `desig_name` IS NULL
AND `dept_id` IS NULL
ERROR - 2018-10-21 17:15:40 --> Query error: Column 'dept_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `designation`
JOIN `department` ON `department`.`dept_id` = `designation`.`dept_id`
WHERE `desig_name` IS NULL
AND `dept_id` IS NULL
ERROR - 2018-10-21 17:15:43 --> Query error: Column 'dept_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `designation`
JOIN `department` ON `department`.`dept_id` = `designation`.`dept_id`
WHERE `desig_name` = 'Manag'
AND `dept_id` = '7'
ERROR - 2018-10-21 17:17:53 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 131
ERROR - 2018-10-21 17:17:53 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 132
ERROR - 2018-10-21 17:19:28 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 131
ERROR - 2018-10-21 17:19:28 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 132
ERROR - 2018-10-21 17:20:44 --> Severity: Notice --> Undefined variable: desig_name C:\xampp\htdocs\hrms\application\controllers\Designation.php 131
ERROR - 2018-10-21 17:20:44 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `designation` SET `desig_id` = NULL, `desig_name` = 'Managghchbgfch', `dept_id` = '7'
ERROR - 2018-10-21 17:24:30 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `designation` SET `desig_id` = NULL, `desig_name` = 'General Manager', `dept_id` = '7'
WHERE `desig_id` = '9'
ERROR - 2018-10-21 17:24:48 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `designation` SET `desig_id` = NULL, `desig_name` = 'General Manager', `dept_id` = '7'
WHERE `desig_id` = '9'
ERROR - 2018-10-21 17:25:46 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `designation` SET `desig_id` = NULL, `desig_name` = 'A Manager', `dept_id` = '7'
WHERE `desig_id` = '9'
ERROR - 2018-10-21 17:26:49 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `designation` SET `desig_id` = NULL, `desig_name` = 'Managefghhhg', `dept_id` = '7'
WHERE `desig_id` = '9'
ERROR - 2018-10-21 17:27:44 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `designation` SET `dept_id` = '7', `desig_name` = 'Managefghhhg', `desig_id` = NULL
WHERE `desig_id` = '9'
ERROR - 2018-10-21 17:27:57 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `designation` SET `dept_id` = '7', `desig_name` = 'Managedfgdsgdg', `desig_id` = NULL
WHERE `desig_id` = '9'
ERROR - 2018-10-21 17:29:59 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\controllers\Designation.php 132
ERROR - 2018-10-21 17:30:01 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\controllers\Designation.php 132
ERROR - 2018-10-21 17:30:06 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\controllers\Designation.php 132
ERROR - 2018-10-21 17:30:44 --> Query error: Duplicate entry '0' for key 'PRIMARY' - Invalid query: UPDATE `designation` SET `dept_id` = '7', `desig_name` = 'Manageghjkghjkhgkljjkh', `desig_id` = NULL
WHERE `desig_id` = '9'
ERROR - 2018-10-21 18:40:23 --> 404 Page Not Found: Delete_designation/9
ERROR - 2018-10-21 18:40:46 --> 404 Page Not Found: Delete_designation/9
ERROR - 2018-10-21 18:41:01 --> 404 Page Not Found: Delete_designation/0
ERROR - 2018-10-21 18:41:52 --> 404 Page Not Found: Delete_designation/9
ERROR - 2018-10-21 18:42:14 --> 404 Page Not Found: Delete_designation/9
ERROR - 2018-10-21 18:44:51 --> 404 Page Not Found: Desigantion/delete_designation
ERROR - 2018-10-21 20:13:11 --> Query error: Column 'desig_name' cannot be null - Invalid query: INSERT INTO `designation` (`dept_id`, `desig_name`) VALUES ('7', NULL)
ERROR - 2018-10-21 20:14:19 --> Query error: Column 'emp_name' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-21 20:14:20 --> Query error: Column 'emp_name' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-21 20:14:20 --> Query error: Column 'emp_name' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-21 20:14:20 --> Query error: Column 'emp_name' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-21 20:14:24 --> Query error: Column 'emp_name' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-21 20:14:25 --> Query error: Column 'emp_name' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-21 20:14:33 --> Query error: Column 'emp_name' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-21 20:15:13 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:15:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:15:13 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:15:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:15:32 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:15:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:15:32 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:15:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:15:34 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:15:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:15:34 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:15:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:15:56 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:15:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:15:57 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:15:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:16:10 --> Query error: Column 'emp_name' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-21 20:16:20 --> Query error: Column 'desig_name' cannot be null - Invalid query: INSERT INTO `desination` (`desig_name`) VALUES (NULL)
ERROR - 2018-10-21 20:17:41 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:17:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:17:41 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:17:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 98
ERROR - 2018-10-21 20:20:28 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:20:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:20:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:20:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:20:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:20:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:20:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:20:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:21:35 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:21:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:21:37 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:21:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:21:38 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:21:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:22:41 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:22:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:23:54 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:23:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:23 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:36 --> Severity: Notice --> Undefined property: Employee::$employee C:\xampp\htdocs\hrms\application\controllers\Employee.php 41
ERROR - 2018-10-21 20:24:36 --> Severity: error --> Exception: Call to a member function save_employee() on null C:\xampp\htdocs\hrms\application\controllers\Employee.php 41
ERROR - 2018-10-21 20:24:56 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:56 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:56 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:56 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:24:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:25:21 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:25:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:25:34 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:25:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:25:54 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`emp_designation`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`) VALUES ('dsfsaf', 'sdfsdf', 'sdfsda', 'fsdfdsa', 'fsdaf', 'sdfsdafs', 'fsdf', 'sdfsdf', '2018-10-16', '2018-10-17')
ERROR - 2018-10-21 20:26:39 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:26:39 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:26:39 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:26:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:27:00 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:27:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:27:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`emp_designation`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `emp_designation`) VALUES ('dsfdsf', 'dsfdsfsd', 'fsdf', 'dsfdsfsd', 'fds', 'fdsfdsf', 'dsfds', 'fdsfdsf', '2018-10-08', '2018-10-16', '3')
ERROR - 2018-10-21 20:27:35 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:27:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:27:36 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:27:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:28:57 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:28:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:30:18 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:30:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:30:19 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:30:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:31:42 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:31:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:09 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:09 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:09 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:12 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:32:35 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`emp_designation`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `emp_designation`) VALUES ('dsfds', 'fdsf', 'sdfdsf', 'sdfds', 'dsfds', 'dsfds', 'sdfsd', 'sdfsd', '2018-10-10', '2018-10-11', '6')
ERROR - 2018-10-21 20:33:42 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:33:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:33:47 --> 404 Page Not Found: Invoicelistphp/index
ERROR - 2018-10-21 20:33:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:33:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:34:08 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:34:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:35:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`emp_designation`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `emp_designation`) VALUES ('dsfdsfsd', 'fdsfdsf', 'dsfsdfdsfds', 'fdsfdsf', 'dsfdsfds', 'fdsfdsf', 'dsfdsfds', 'fdsfdsfds', '2018-10-19', '2018-10-11', '5')
ERROR - 2018-10-21 20:38:03 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:38:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:38:04 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:38:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:38:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`emp_designation`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `emp_designation`) VALUES ('fd', 'dsfdsfd', 'dsfdsfd', 'sfsd', 'fsdfds', 'sfdsf', 'sdfdsfdsf', 'dfdsf', '2018-10-12', '2018-10-24', '4')
ERROR - 2018-10-21 20:50:51 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:50:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:50:58 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`emp_designation`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `emp_designation`) VALUES ('fd', 'dsfdsfd', 'dsfdsfd', 'sfsd', 'fsdfds', 'sfdsf', 'sdfdsfdsf', 'dfdsf', '2018-10-12', '2018-10-24', '4')
ERROR - 2018-10-21 20:51:00 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:51:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:51:08 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:51:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:51:39 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`emp_designation`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `emp_designation`) VALUES ('nbm', 'hgmnhn', 'vbnvbn', 'bn', 'vbnv', 'vbnvvc', 'vcnv', 'vnhv', '2018-10-09', '2018-10-09', '4')
ERROR - 2018-10-21 20:56:53 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:56:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:57:04 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:57:28 --> Query error: Column 'desig_id' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `desig_id`) VALUES ('dgdfg', 'dfgdg', 'fdgdfg', 'fgfd', 'fgdf', 'fxgdsgdsfg', 'dfgfdg', 'fdgfds', '2018-10-09', '2018-10-03', NULL)
ERROR - 2018-10-21 20:58:51 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:58:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:58:56 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:58:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:59:20 --> Query error: Column 'desig_id' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `desig_id`) VALUES ('jhk', 'jv', 'bvkj', 'jk', 'hgk', 'hgk', 'jhkh', 'bhk', '2018-10-25', '2018-10-17', NULL)
ERROR - 2018-10-21 20:59:54 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 20:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 21:01:09 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 21:01:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 21:01:44 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 21:01:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 21:01:47 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 21:01:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 21:02:10 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`desig_id`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `desig_id`) VALUES ('jklhjk,', 'kjlj', 'jkljkl', 'kjljk', 'lnkbjhl', 'jkhljkl', 'jhlj', 'jkljhl', '2018-10-02', '2018-10-04', '3')
ERROR - 2018-10-21 22:48:30 --> 404 Page Not Found: Add_employee/index
ERROR - 2018-10-21 22:48:37 --> 404 Page Not Found: Add_employee/index
ERROR - 2018-10-21 22:48:51 --> 404 Page Not Found: Add_employee/index
ERROR - 2018-10-21 22:49:29 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:49:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:49:46 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:49:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:50:46 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:50:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:51:05 --> Query error: Column 'desig_id' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `desig_id`) VALUES ('ghj', 'gj', 'ghjgf', 'ghjf', 'hgjj', 'ghjgh', 'gj', 'hjg', '2018-10-09', '2018-10-09', NULL)
ERROR - 2018-10-21 22:51:11 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:51:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:52:26 --> Query error: Column 'desig_id' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `desig_id`) VALUES ('ghj', 'gj', 'ghjgf', 'ghjf', 'hgjj', 'ghjgh', 'gj', 'hjg', '2018-10-09', '2018-10-09', NULL)
ERROR - 2018-10-21 22:52:28 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:52:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:52:37 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:52:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:53:17 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`desig_id`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `desig_id`) VALUES ('dsfdsf', 'fdsfsd', 'fdsfdsf', 'dsfdsfds', 'fds', 'sdfsdafs', 'sdfsd', 'sdfds', '2018-10-31', '2018-10-11', '4')
ERROR - 2018-10-21 22:54:11 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:54:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:55:03 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:55:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 85
ERROR - 2018-10-21 22:55:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`desig_id`) REFERENCES `desination` (`desig_id`)) - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `desig_id`) VALUES ('dsfds', 'fdsf', 'fdsfdsf', 'dsfdsfds', 'dsfdsf', 'dsfdsfds', 'dsfds', 'fdx', '2018-10-09', '2018-10-03', '4')
