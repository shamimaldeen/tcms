<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-22 01:14:12 --> 404 Page Not Found: Assets/plugins
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-22 01:14:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-22 01:14:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-22 01:14:16 --> 404 Page Not Found: Uploads/favicon.PNG
ERROR - 2018-10-22 01:18:03 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 01:18:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 01:18:05 --> 404 Page Not Found: Invoicelistphp/index
ERROR - 2018-10-22 01:18:07 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 01:18:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 12:45:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-22 12:45:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-22 12:45:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-22 12:45:58 --> 404 Page Not Found: Uploads/favicon.PNG
ERROR - 2018-10-22 12:46:09 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 12:46:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 12:46:45 --> Query error: Column 'emp_age' cannot be null - Invalid query: INSERT INTO `employee` (`emp_name`, `emp_username`, `emp_password`, `emp_email`, `emp_address`, `emp_contact`, `emp_age`, `emp_image`, `emp_dof`, `emp_joining_date`, `desig_id`) VALUES ('dgdfg', 'fdxgbdfxg', 'gfdgdfg', 'dfgdfg', 'fdgdsf', 'fdghdfgdf', NULL, 'dfgdsf', '2018-10-10', '2018-10-09', '3')
ERROR - 2018-10-22 17:51:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-22 17:51:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-22 17:51:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-22 17:52:01 --> 404 Page Not Found: Uploads/favicon.PNG
ERROR - 2018-10-22 17:52:07 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 17:52:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 17:55:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 17:55:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 17:56:32 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 17:56:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:19:58 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:19:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:20:12 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:20:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:21:17 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:21:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:21:21 --> Severity: Notice --> Undefined property: stdClass::$dept_name C:\xampp\htdocs\hrms\application\views\employee_list.php 62
ERROR - 2018-10-22 18:21:21 --> Severity: Notice --> Undefined property: stdClass::$dept_name C:\xampp\htdocs\hrms\application\views\employee_list.php 62
ERROR - 2018-10-22 18:22:22 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\employee_list.php 56
ERROR - 2018-10-22 18:22:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\employee_list.php 56
ERROR - 2018-10-22 18:22:23 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\employee_list.php 56
ERROR - 2018-10-22 18:22:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\employee_list.php 56
ERROR - 2018-10-22 18:22:25 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\employee_list.php 56
ERROR - 2018-10-22 18:22:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\employee_list.php 56
ERROR - 2018-10-22 18:25:02 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:25:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:34:58 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 92
ERROR - 2018-10-22 18:34:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 92
ERROR - 2018-10-22 18:34:58 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 94
ERROR - 2018-10-22 18:34:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 94
ERROR - 2018-10-22 18:34:58 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 92
ERROR - 2018-10-22 18:34:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 92
ERROR - 2018-10-22 18:34:58 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 94
ERROR - 2018-10-22 18:34:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 94
ERROR - 2018-10-22 18:37:06 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 92
ERROR - 2018-10-22 18:37:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 92
ERROR - 2018-10-22 18:37:06 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 94
ERROR - 2018-10-22 18:37:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 94
ERROR - 2018-10-22 18:37:06 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 92
ERROR - 2018-10-22 18:37:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 92
ERROR - 2018-10-22 18:37:06 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 94
ERROR - 2018-10-22 18:37:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 94
ERROR - 2018-10-22 18:38:41 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:46 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:47 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:47 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:48 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:49 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:38:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:40:26 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:40:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:40:50 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 18:40:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 90
ERROR - 2018-10-22 19:20:59 --> Severity: Error --> Cannot redeclare format_date() (previously declared in C:\xampp\htdocs\hrms\application\views\employee_list.php:90) C:\xampp\htdocs\hrms\application\views\employee_list.php 90
ERROR - 2018-10-22 19:21:38 --> Severity: Error --> Cannot redeclare format_date() (previously declared in C:\xampp\htdocs\hrms\application\views\employee_list.php:90) C:\xampp\htdocs\hrms\application\views\employee_list.php 90
ERROR - 2018-10-22 19:22:37 --> Severity: Error --> Cannot redeclare format_date() (previously declared in C:\xampp\htdocs\hrms\application\views\employee_list.php:90) C:\xampp\htdocs\hrms\application\views\employee_list.php 90
ERROR - 2018-10-22 19:23:57 --> Severity: Error --> Cannot redeclare formatdate() (previously declared in C:\xampp\htdocs\hrms\application\views\employee_list.php:90) C:\xampp\htdocs\hrms\application\views\employee_list.php 90
ERROR - 2018-10-22 19:43:03 --> Severity: Notice --> Undefined variable: employees C:\xampp\htdocs\hrms\application\controllers\Employee.php 72
ERROR - 2018-10-22 19:52:08 --> Severity: Notice --> Undefined index: employee C:\xampp\htdocs\hrms\application\controllers\Employee.php 83
ERROR - 2018-10-22 19:55:46 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 19:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 19:55:46 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 19:55:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:05:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 28
ERROR - 2018-10-22 20:05:10 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:05:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:05:10 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:05:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:06:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 28
ERROR - 2018-10-22 20:06:04 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:06:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:06:04 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:06:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:06:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 28
ERROR - 2018-10-22 20:06:08 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:06:08 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:06:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:06:35 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:06:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:06:35 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:06:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:13:39 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:13:39 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:13:51 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:13:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 91
ERROR - 2018-10-22 20:13:51 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:13:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 102
ERROR - 2018-10-22 20:19:43 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:19:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:19:43 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 114
ERROR - 2018-10-22 20:19:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 114
ERROR - 2018-10-22 20:25:15 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:25:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:25:15 --> Severity: Notice --> Undefined variable: designations C:\xampp\htdocs\hrms\application\views\edit_employee.php 114
ERROR - 2018-10-22 20:25:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 114
ERROR - 2018-10-22 20:26:54 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:26:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:26:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:26:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:26:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:26:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:26:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:26:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:26:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:26:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:26:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_employee.php 115
ERROR - 2018-10-22 20:29:04 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:29:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:31:41 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 20:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 20:36:47 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 20:36:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 20:38:27 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 20:38:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 20:38:34 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\hrms\application\views\edit_employee.php 36
ERROR - 2018-10-22 20:38:44 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\hrms\application\views\edit_employee.php 36
ERROR - 2018-10-22 20:39:18 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:39:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:39:29 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:39:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:40:43 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:40:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:40:48 --> 404 Page Not Found: Employee/update_employee
ERROR - 2018-10-22 20:57:00 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 20:57:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:05:56 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\hrms\application\models\Employeemodel.php 82
ERROR - 2018-10-22 21:06:38 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:06:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:06:40 --> Severity: Notice --> Undefined variable: row C:\xampp\htdocs\hrms\application\controllers\Employee.php 92
ERROR - 2018-10-22 21:07:26 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:07:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:07:28 --> Severity: Notice --> Undefined variable: emp_name C:\xampp\htdocs\hrms\application\models\Employeemodel.php 98
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 99
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_password C:\xampp\htdocs\hrms\application\models\Employeemodel.php 100
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 101
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_address C:\xampp\htdocs\hrms\application\models\Employeemodel.php 102
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 103
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_age C:\xampp\htdocs\hrms\application\models\Employeemodel.php 104
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_image C:\xampp\htdocs\hrms\application\models\Employeemodel.php 105
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_dof C:\xampp\htdocs\hrms\application\models\Employeemodel.php 106
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 107
ERROR - 2018-10-22 21:07:29 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 108
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_name C:\xampp\htdocs\hrms\application\models\Employeemodel.php 98
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 99
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_password C:\xampp\htdocs\hrms\application\models\Employeemodel.php 100
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 101
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_address C:\xampp\htdocs\hrms\application\models\Employeemodel.php 102
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 103
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_age C:\xampp\htdocs\hrms\application\models\Employeemodel.php 104
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_image C:\xampp\htdocs\hrms\application\models\Employeemodel.php 105
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_dof C:\xampp\htdocs\hrms\application\models\Employeemodel.php 106
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 107
ERROR - 2018-10-22 21:09:26 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 108
ERROR - 2018-10-22 21:09:28 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:09:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_name C:\xampp\htdocs\hrms\application\models\Employeemodel.php 98
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 99
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_password C:\xampp\htdocs\hrms\application\models\Employeemodel.php 100
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 101
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_address C:\xampp\htdocs\hrms\application\models\Employeemodel.php 102
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 103
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_age C:\xampp\htdocs\hrms\application\models\Employeemodel.php 104
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_image C:\xampp\htdocs\hrms\application\models\Employeemodel.php 105
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_dof C:\xampp\htdocs\hrms\application\models\Employeemodel.php 106
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 107
ERROR - 2018-10-22 21:09:30 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 108
ERROR - 2018-10-22 21:15:53 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:15:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_name C:\xampp\htdocs\hrms\application\models\Employeemodel.php 98
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 99
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_password C:\xampp\htdocs\hrms\application\models\Employeemodel.php 100
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 101
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_address C:\xampp\htdocs\hrms\application\models\Employeemodel.php 102
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 103
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_age C:\xampp\htdocs\hrms\application\models\Employeemodel.php 104
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_image C:\xampp\htdocs\hrms\application\models\Employeemodel.php 105
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_dof C:\xampp\htdocs\hrms\application\models\Employeemodel.php 106
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 107
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 108
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 104
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 105
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 106
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 107
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 108
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 109
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 110
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 111
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 112
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 113
ERROR - 2018-10-22 21:15:58 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 114
ERROR - 2018-10-22 21:15:58 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`desig_id`) REFERENCES `designation` (`desig_id`)) - Invalid query: UPDATE `employee` SET `emp_name` = NULL, `emp_username` = NULL, `emp_password` = NULL, `emp_email` = NULL, `emp_address` = NULL, `emp_contact` = NULL, `emp_age` = NULL, `emp_image` = NULL, `emp_dof` = NULL, `emp_joining_date` = NULL, `desig_id` = NULL
WHERE `emp_id` = '3'
ERROR - 2018-10-22 21:15:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\hrms\system\core\Exceptions.php:271) C:\xampp\htdocs\hrms\system\core\Common.php 570
ERROR - 2018-10-22 21:17:00 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:17:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_name C:\xampp\htdocs\hrms\application\models\Employeemodel.php 86
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 87
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_password C:\xampp\htdocs\hrms\application\models\Employeemodel.php 88
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 89
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_address C:\xampp\htdocs\hrms\application\models\Employeemodel.php 90
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 91
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_age C:\xampp\htdocs\hrms\application\models\Employeemodel.php 92
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_image C:\xampp\htdocs\hrms\application\models\Employeemodel.php 93
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_dof C:\xampp\htdocs\hrms\application\models\Employeemodel.php 94
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 95
ERROR - 2018-10-22 21:17:04 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 96
ERROR - 2018-10-22 21:17:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\hrms\system\core\Exceptions.php:271) C:\xampp\htdocs\hrms\system\helpers\url_helper.php 564
ERROR - 2018-10-22 21:17:07 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:17:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:17:31 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:17:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_name C:\xampp\htdocs\hrms\application\models\Employeemodel.php 86
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 87
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_password C:\xampp\htdocs\hrms\application\models\Employeemodel.php 88
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 89
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_address C:\xampp\htdocs\hrms\application\models\Employeemodel.php 90
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 91
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_age C:\xampp\htdocs\hrms\application\models\Employeemodel.php 92
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_image C:\xampp\htdocs\hrms\application\models\Employeemodel.php 93
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_dof C:\xampp\htdocs\hrms\application\models\Employeemodel.php 94
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 95
ERROR - 2018-10-22 21:17:39 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 96
ERROR - 2018-10-22 21:17:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\hrms\system\core\Exceptions.php:271) C:\xampp\htdocs\hrms\system\helpers\url_helper.php 564
ERROR - 2018-10-22 21:17:44 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:17:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:19:19 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:19:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_name C:\xampp\htdocs\hrms\application\models\Employeemodel.php 100
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 101
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_password C:\xampp\htdocs\hrms\application\models\Employeemodel.php 102
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 103
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_address C:\xampp\htdocs\hrms\application\models\Employeemodel.php 104
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 105
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_age C:\xampp\htdocs\hrms\application\models\Employeemodel.php 106
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_image C:\xampp\htdocs\hrms\application\models\Employeemodel.php 107
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_dof C:\xampp\htdocs\hrms\application\models\Employeemodel.php 108
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 109
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 110
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 103
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 104
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 105
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 106
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 107
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 108
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 109
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 110
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 111
ERROR - 2018-10-22 21:20:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 112
ERROR - 2018-10-22 21:20:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Employee.php 113
ERROR - 2018-10-22 21:20:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`hrms`.`employee`, CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`desig_id`) REFERENCES `designation` (`desig_id`)) - Invalid query: UPDATE `employee` SET `emp_name` = NULL, `emp_username` = NULL, `emp_password` = NULL, `emp_email` = NULL, `emp_address` = NULL, `emp_contact` = NULL, `emp_age` = NULL, `emp_image` = NULL, `emp_dof` = NULL, `emp_joining_date` = NULL, `desig_id` = NULL
WHERE `emp_id` = '3'
ERROR - 2018-10-22 21:20:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\hrms\system\core\Exceptions.php:271) C:\xampp\htdocs\hrms\system\core\Common.php 570
ERROR - 2018-10-22 21:20:35 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:20:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:21:05 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:21:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:21:32 --> Severity: Notice --> Undefined variable: emp_name C:\xampp\htdocs\hrms\application\models\Employeemodel.php 88
ERROR - 2018-10-22 21:21:32 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 89
ERROR - 2018-10-22 21:21:32 --> Severity: Notice --> Undefined variable: emp_password C:\xampp\htdocs\hrms\application\models\Employeemodel.php 90
ERROR - 2018-10-22 21:21:32 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 91
ERROR - 2018-10-22 21:21:32 --> Severity: Notice --> Undefined variable: emp_address C:\xampp\htdocs\hrms\application\models\Employeemodel.php 92
ERROR - 2018-10-22 21:21:32 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 93
ERROR - 2018-10-22 21:21:32 --> Severity: Notice --> Undefined variable: emp_age C:\xampp\htdocs\hrms\application\models\Employeemodel.php 94
ERROR - 2018-10-22 21:21:32 --> Severity: Notice --> Undefined variable: emp_image C:\xampp\htdocs\hrms\application\models\Employeemodel.php 95
ERROR - 2018-10-22 21:21:33 --> Severity: Notice --> Undefined variable: emp_dof C:\xampp\htdocs\hrms\application\models\Employeemodel.php 96
ERROR - 2018-10-22 21:21:33 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 97
ERROR - 2018-10-22 21:21:33 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 98
ERROR - 2018-10-22 21:21:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\hrms\system\core\Exceptions.php:271) C:\xampp\htdocs\hrms\system\helpers\url_helper.php 564
ERROR - 2018-10-22 21:21:35 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:21:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:21:51 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:21:59 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:21:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:29:11 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:29:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:29:12 --> Severity: Notice --> Undefined variable: emp_username C:\xampp\htdocs\hrms\application\models\Employeemodel.php 87
ERROR - 2018-10-22 21:29:12 --> Severity: Notice --> Undefined variable: emp_email C:\xampp\htdocs\hrms\application\models\Employeemodel.php 88
ERROR - 2018-10-22 21:29:12 --> Severity: Notice --> Undefined variable: emp_contact C:\xampp\htdocs\hrms\application\models\Employeemodel.php 89
ERROR - 2018-10-22 21:29:12 --> Severity: Notice --> Undefined variable: emp_joining_date C:\xampp\htdocs\hrms\application\models\Employeemodel.php 90
ERROR - 2018-10-22 21:29:12 --> Severity: Notice --> Undefined variable: desig_id C:\xampp\htdocs\hrms\application\models\Employeemodel.php 91
ERROR - 2018-10-22 21:31:40 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:31:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:31:41 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:31:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:31:42 --> Severity: error --> Exception: Too few arguments to function Employeemodel::check_employee(), 0 passed in C:\xampp\htdocs\hrms\application\controllers\Employee.php on line 104 and exactly 1 expected C:\xampp\htdocs\hrms\application\models\Employeemodel.php 80
ERROR - 2018-10-22 21:31:55 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:31:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:31:56 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:31:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:32:49 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:32:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:33:17 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:33:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:33:18 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:33:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:33:22 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:33:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:33:23 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:33:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:34:27 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:34:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:34:33 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:34:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:34:38 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:34:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:34:38 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 21:34:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 22:20:01 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 22:20:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 22:21:27 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:27 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:27 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:30 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:30 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:30 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:38 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 22:21:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_employee.php 103
ERROR - 2018-10-22 22:21:41 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:41 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:41 --> Severity: Notice --> Undefined variable: designation C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:21:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:22:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:23:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\employee_list.php 104
ERROR - 2018-10-22 22:29:21 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:29:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:29:53 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:29:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:31:51 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:32:10 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:32:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:33:39 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-22 22:33:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
