<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-27 00:04:40 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 00:06:14 --> Query error: Column 'page_description' cannot be null - Invalid query: INSERT INTO `tbl_page` (`page_id`, `page_title`, `page_type`, `page_description`, `page_testemonial_desig`, `page_slider_button_link`, `page_image`, `page_added_date`, `page_updated_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-11-27', '2018-11-27')
ERROR - 2018-11-27 00:18:28 --> Severity: error --> Exception: Call to undefined function mysql_query() C:\xampp\htdocs\training\application\controllers\Front.php 106
ERROR - 2018-11-27 00:19:45 --> Severity: error --> Exception: Call to undefined function mysql_query() C:\xampp\htdocs\training\application\controllers\Front.php 137
ERROR - 2018-11-27 00:22:15 --> Severity: error --> Exception: Call to undefined function mysql_fetch_assoc() C:\xampp\htdocs\training\application\controllers\Front.php 140
ERROR - 2018-11-27 00:35:56 --> Severity: Notice --> Undefined variable: offset C:\xampp\htdocs\training\application\controllers\Front.php 115
ERROR - 2018-11-27 00:35:56 --> Severity: Notice --> Undefined variable: rowsperpage C:\xampp\htdocs\training\application\controllers\Front.php 115
ERROR - 2018-11-27 00:37:09 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\controllers\Front.php 121
ERROR - 2018-11-27 00:39:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''3', '12'' at line 1 - Invalid query: SELECT * from tbl_page LIMIT '3', '12'
ERROR - 2018-11-27 00:41:32 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\training\application\controllers\Front.php 124
ERROR - 2018-11-27 00:43:32 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
WHERE `page_type` = 'Blog'
 LIMIT 3, 16
ERROR - 2018-11-27 00:44:15 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
WHERE `page_type` = 'Blog'
 LIMIT 3, 12
ERROR - 2018-11-27 00:44:20 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
WHERE `page_type` = 'Blog'
 LIMIT 3, 8
ERROR - 2018-11-27 00:44:24 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
WHERE `page_type` = 'Blog'
 LIMIT 3, 4
ERROR - 2018-11-27 00:44:29 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
 LIMIT 3, 4
ERROR - 2018-11-27 00:44:49 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
 LIMIT 3, 8
ERROR - 2018-11-27 00:45:26 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
 LIMIT 17, 15
ERROR - 2018-11-27 00:45:37 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
 LIMIT 15, 17
ERROR - 2018-11-27 00:45:50 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
 LIMIT 0
ERROR - 2018-11-27 00:46:07 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
 LIMIT 1, 0
ERROR - 2018-11-27 00:46:15 --> Query error: Table 'tcms.tb_page' doesn't exist - Invalid query: SELECT *
FROM `tb_page`
ERROR - 2018-11-27 00:55:17 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Front.php 135
ERROR - 2018-11-27 01:09:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'tbl_page' at line 1 - Invalid query: tbl_page
ERROR - 2018-11-27 01:09:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'tbl_page' at line 1 - Invalid query: tbl_page
ERROR - 2018-11-27 01:10:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'tbl_page' at line 1 - Invalid query: tbl_page
ERROR - 2018-11-27 01:10:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0' at line 1 - Invalid query: SELECT * from tbl_page LIMIT 3 0
ERROR - 2018-11-27 01:10:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''0'' at line 1 - Invalid query: SELECT * from tbl_page LIMIT 3 '0'
ERROR - 2018-11-27 01:10:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''0'' at line 1 - Invalid query: SELECT * from tbl_page LIMIT 3 '0'
ERROR - 2018-11-27 01:10:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''0'' at line 1 - Invalid query: SELECT * from tbl_page LIMIT 3 '0'
ERROR - 2018-11-27 01:11:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''0'' at line 1 - Invalid query: SELECT * from tbl_page LIMIT 3, '0'
ERROR - 2018-11-27 01:14:54 --> Severity: error --> Exception: Too few arguments to function Front::blog(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Front.php 89
ERROR - 2018-11-27 01:17:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:17:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:17:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:17:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:17:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:17:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:17:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:17:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:17:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:17:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:17:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:17:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:17:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:17:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:17:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:17:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:18:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:18:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:18:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:18:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:19:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:19:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:19:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:19:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:19:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:19:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:19:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:19:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:20:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:20:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:20:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:20:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:20:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:20:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:20:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 96
ERROR - 2018-11-27 01:20:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:22:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:22:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:24:34 --> Severity: error --> Exception: syntax error, unexpected '<=' (T_IS_SMALLER_OR_EQUAL), expecting variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\training\application\views\front\blog.php 47
ERROR - 2018-11-27 01:24:49 --> Severity: error --> Exception: syntax error, unexpected '<=' (T_IS_SMALLER_OR_EQUAL), expecting variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\training\application\views\front\blog.php 47
ERROR - 2018-11-27 01:24:51 --> Severity: error --> Exception: syntax error, unexpected '<=' (T_IS_SMALLER_OR_EQUAL), expecting variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\training\application\views\front\blog.php 47
ERROR - 2018-11-27 01:25:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:25:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:25:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:25:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:25:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:25:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:25:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:25:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:26:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:26:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:26:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:26:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:26:04 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:26:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:26:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:26:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:26:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:26:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:26:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:26:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:27:34 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:27:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:27:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:27:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:28:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:28:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:28:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:28:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:28:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:28:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:31:01 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 01:31:25 --> Severity: Notice --> Undefined property: CI_URI::$segements C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 01:31:25 --> Severity: Notice --> Undefined property: CI_URI::$segements C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 01:31:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:31:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:31:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:31:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:31:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:31:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:31:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:31:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:31:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:31:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:31:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:31:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:31:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:31:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:32:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:32:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:32:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 101
ERROR - 2018-11-27 01:32:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 01:32:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 01:32:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 01:32:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 01:32:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 01:32:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 01:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 01:32:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 01:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 01:32:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 01:32:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 01:32:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 01:32:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 01:32:42 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 01:32:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 01:32:42 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 01:32:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 08:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 08:55:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 08:55:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 08:55:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 08:56:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 08:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 08:56:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 08:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 08:56:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-27 08:56:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-27 08:56:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-27 08:56:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-27 09:09:15 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:09:15 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:09:15 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:09:36 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:09:36 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:09:36 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:09:49 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:09:50 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:09:50 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:11 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:11 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:11 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:31 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:31 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:31 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:44 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:44 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:10:44 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:19:45 --> Severity: Notice --> Undefined variable: teams C:\xampp\htdocs\training\application\views\front\about.php 89
ERROR - 2018-11-27 09:19:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\about.php 89
ERROR - 2018-11-27 09:33:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:33:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:33:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:33:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:34:29 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:34:29 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:34:29 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:34:29 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:35:16 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:35:16 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:35:16 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:35:16 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:36:43 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:36:43 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:36:43 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:36:43 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:38:15 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:38:15 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:38:15 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:38:15 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:38:15 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:39:35 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:39:35 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:39:35 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:39:35 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:39:35 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:41:25 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:41:25 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:41:25 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:41:25 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:41:25 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:42:37 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:42:37 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:42:37 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:42:37 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:42:37 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:51 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:51 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:51 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:51 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:51 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:58 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:58 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:58 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:58 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:47:58 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 09:48:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 09:48:14 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:14 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:14 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:14 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:14 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:18 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:18 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:18 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:18 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:48:18 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 09:49:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 09:49:47 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:47 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:47 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:47 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:49:47 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:54 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:54 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:54 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:55 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:55 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:50:56 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 09:51:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 09:51:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 09:51:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 09:51:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 09:51:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 09:51:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 09:51:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 09:51:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:27:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 10:27:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 10:27:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 10:27:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 10:27:01 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\blog.php 55
ERROR - 2018-11-27 10:27:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:27:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:27:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:27:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:28:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:28:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:29:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:29:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:29:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:29:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:29:21 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:29:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:29:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:29:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:29:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:29:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:30:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:30:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:32:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:32:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:34:02 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:34:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:34:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:34:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:34:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:34:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:36:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:36:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:39:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 104
ERROR - 2018-11-27 10:39:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:45:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 117
ERROR - 2018-11-27 10:45:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:45:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 117
ERROR - 2018-11-27 10:45:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:46:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 117
ERROR - 2018-11-27 10:46:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 3 - Invalid query: SELECT *
FROM `tbl_page`
 LIMIT -3, 3
ERROR - 2018-11-27 10:47:01 --> Severity: Notice --> Undefined variable: pageid C:\xampp\htdocs\training\application\controllers\Front.php 75
ERROR - 2018-11-27 10:48:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 121
ERROR - 2018-11-27 10:48:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 10:48:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 121
ERROR - 2018-11-27 10:48:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 10:48:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 121
ERROR - 2018-11-27 10:48:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 10:48:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 121
ERROR - 2018-11-27 10:48:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 10:49:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 121
ERROR - 2018-11-27 10:49:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 10:49:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 121
ERROR - 2018-11-27 10:49:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 10:50:30 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 125
ERROR - 2018-11-27 10:50:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 10:50:33 --> Severity: Notice --> Undefined variable: pageid C:\xampp\htdocs\training\application\controllers\Front.php 75
ERROR - 2018-11-27 10:51:09 --> Severity: Notice --> Undefined variable: pageid C:\xampp\htdocs\training\application\controllers\Front.php 75
ERROR - 2018-11-27 11:00:57 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\news.php 47
ERROR - 2018-11-27 11:00:57 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\news.php 47
ERROR - 2018-11-27 11:02:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\news.php 47
ERROR - 2018-11-27 11:02:27 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\training\application\views\front\news.php 47
ERROR - 2018-11-27 11:03:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 125
ERROR - 2018-11-27 11:03:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:03:08 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 125
ERROR - 2018-11-27 11:03:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:03:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 125
ERROR - 2018-11-27 11:03:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:17:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:17:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:17:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:17:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:17:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:17:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:17:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:17:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:17:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:17:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:19:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:19:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:19:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:19:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:19:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:19:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:19:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:19:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:20:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:20:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:20:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:20:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:20:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:20:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:20:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:20:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:20:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:20:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:21:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:21:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:21:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:21:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:21:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:21:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:21:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:21:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:21:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:21:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:21:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:21:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:21:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:21:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:21:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:21:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:23:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:23:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:23:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:23:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:23:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:23:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:25:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:25:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:25:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:25:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:25:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:25:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:25:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:25:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 129
ERROR - 2018-11-27 11:25:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:25:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 139
ERROR - 2018-11-27 11:25:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:25:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\blog_details.php 140
ERROR - 2018-11-27 11:27:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:27:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:27:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:27:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:27:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:27:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:29:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:29:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:30:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:30:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:30:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:30:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:31:09 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:31:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:31:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:31:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:31:24 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:31:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:31:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:31:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:33:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:33:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:33:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:33:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:33:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:33:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:33:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:33:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:34:59 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:34:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:35:20 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:35:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:35:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:35:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:35:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:35:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:35:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 126
ERROR - 2018-11-27 11:35:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:41:12 --> Severity: Notice --> Undefined variable: blogs C:\xampp\htdocs\training\application\views\front\news_details.php 129
ERROR - 2018-11-27 11:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news_details.php 129
ERROR - 2018-11-27 11:41:12 --> Severity: Notice --> Undefined variable: blogs C:\xampp\htdocs\training\application\views\front\news_details.php 139
ERROR - 2018-11-27 11:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news_details.php 139
ERROR - 2018-11-27 11:41:12 --> Severity: Notice --> Undefined variable: blogs C:\xampp\htdocs\training\application\views\front\news_details.php 140
ERROR - 2018-11-27 11:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news_details.php 140
ERROR - 2018-11-27 11:43:57 --> Severity: error --> Exception: Too few arguments to function Front::news_details(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Front.php 109
ERROR - 2018-11-27 11:44:21 --> Severity: error --> Exception: Too few arguments to function Front::news_details(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Front.php 109
ERROR - 2018-11-27 11:45:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:45:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:45:31 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:45:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:45:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:45:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:46:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:46:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:50:44 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:50:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:51:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:51:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:51:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:51:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:52:07 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:52:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:53:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:53:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:54:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:54:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 11:54:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 152
ERROR - 2018-11-27 11:54:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 12:08:14 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\index.php 133
ERROR - 2018-11-27 12:08:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\index.php 133
ERROR - 2018-11-27 13:16:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:16:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 4 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
 LIMIT -3, 3
ERROR - 2018-11-27 13:17:37 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:17:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 13:17:42 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:17:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 13:17:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:17:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 13:18:09 --> Severity: error --> Exception: Too few arguments to function Front::news_details(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Front.php 114
ERROR - 2018-11-27 13:20:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\news_details.php 116
ERROR - 2018-11-27 13:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news_details.php 116
ERROR - 2018-11-27 13:20:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\news_details.php 129
ERROR - 2018-11-27 13:20:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news_details.php 129
ERROR - 2018-11-27 13:20:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\news_details.php 139
ERROR - 2018-11-27 13:20:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news_details.php 139
ERROR - 2018-11-27 13:20:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\news_details.php 140
ERROR - 2018-11-27 13:20:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news_details.php 140
ERROR - 2018-11-27 13:22:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:22:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 13:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:27:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 13:28:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:28:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 13:31:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 13:31:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 13:31:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 13:31:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 13:32:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 13:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-27 13:32:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 13:32:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-27 13:45:15 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:45:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 13:45:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:45:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 13:46:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 13:46:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 14:07:53 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-27 14:08:00 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 157
ERROR - 2018-11-27 14:08:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 14:08:35 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-27 14:13:17 --> Severity: Notice --> Undefined variable: courses C:\xampp\htdocs\training\application\views\front\index.php 109
ERROR - 2018-11-27 14:13:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\index.php 109
ERROR - 2018-11-27 14:18:02 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\training\application\views\front\index.php 161
ERROR - 2018-11-27 14:18:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\index.php 161
ERROR - 2018-11-27 14:24:08 --> Severity: Notice --> Use of undefined constant e - assumed 'e' C:\xampp\htdocs\training\application\views\front\index.php 154
ERROR - 2018-11-27 14:24:17 --> Severity: Notice --> Use of undefined constant e - assumed 'e' C:\xampp\htdocs\training\application\views\front\index.php 154
ERROR - 2018-11-27 16:04:16 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 165
ERROR - 2018-11-27 16:04:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-27 19:04:01 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\training\application\controllers\Adminback.php 40
ERROR - 2018-11-27 19:04:01 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 18
ERROR - 2018-11-27 19:04:01 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 24
ERROR - 2018-11-27 19:04:01 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 32
ERROR - 2018-11-27 19:04:01 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 38
ERROR - 2018-11-27 19:04:01 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 46
ERROR - 2018-11-27 19:04:01 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 58
ERROR - 2018-11-27 19:04:01 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 76
ERROR - 2018-11-27 19:04:19 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 18
ERROR - 2018-11-27 19:04:19 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 24
ERROR - 2018-11-27 19:04:19 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 32
ERROR - 2018-11-27 19:04:19 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 38
ERROR - 2018-11-27 19:04:19 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 46
ERROR - 2018-11-27 19:04:19 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 58
ERROR - 2018-11-27 19:04:19 --> Severity: Notice --> Undefined variable: customer_data C:\xampp\htdocs\training\application\views\front\admin_back\profile.php 76
ERROR - 2018-11-27 19:39:04 --> Severity: Compile Error --> Cannot redeclare Adminback::upload_image() C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-27 19:39:29 --> Severity: Compile Error --> Cannot redeclare Adminback::upload_image() C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-27 19:39:30 --> Severity: Compile Error --> Cannot redeclare Adminback::upload_image() C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-27 19:40:14 --> Severity: Compile Error --> Cannot redeclare Adminback::upload_image() C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-27 19:41:32 --> Severity: Compile Error --> Cannot redeclare Adminback::upload_image() C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-27 19:53:31 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'map code something', NULL, '2018-11-27')
ERROR - 2018-11-27 19:55:30 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ' DSfghjkl', NULL, '2018-11-27')
ERROR - 2018-11-27 19:56:16 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ' dsfgjkl;', NULL, '2018-11-27')
ERROR - 2018-11-27 19:59:18 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ' dsfjkl', NULL, '2018-11-27')
ERROR - 2018-11-27 20:00:43 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ' ZXcvm,.', NULL, '2018-11-27')
ERROR - 2018-11-27 20:03:54 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ' zxcvbn', NULL, '2018-11-27')
ERROR - 2018-11-27 20:06:35 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ' asdfjkl;', NULL, '2018-11-27')
ERROR - 2018-11-27 20:09:16 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-11-27')
ERROR - 2018-11-27 20:48:10 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `tbl_site` (`site_id`, `site_title`, `site_address`, `email`, `mobile`, `phone`, `web_address`, `facebook`, `twitter`, `youtube`, `map_code`, `site_logo`, `added_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-11-27')
ERROR - 2018-11-27 21:12:38 --> Severity: error --> Exception: syntax error, unexpected '9' (T_LNUMBER), expecting variable (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Adminback.php 103
ERROR - 2018-11-27 21:12:43 --> Severity: error --> Exception: syntax error, unexpected '9' (T_LNUMBER), expecting variable (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Adminback.php 103
ERROR - 2018-11-27 21:12:50 --> Severity: error --> Exception: syntax error, unexpected '9' (T_LNUMBER), expecting variable (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Adminback.php 103
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 18
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 18
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 24
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 24
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 32
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 32
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 38
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 38
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 44
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 44
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 52
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 52
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 58
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 58
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 66
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 66
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 72
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 72
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 96
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 96
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\site.php 110
ERROR - 2018-11-27 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\site.php 110
ERROR - 2018-11-27 21:30:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\controllers\Adminback.php 115
ERROR - 2018-11-27 21:30:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Adminback.php 115
ERROR - 2018-11-27 21:30:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\controllers\Adminback.php 116
ERROR - 2018-11-27 21:30:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Adminback.php 116
ERROR - 2018-11-27 21:30:02 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 116
ERROR - 2018-11-27 21:31:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\controllers\Adminback.php 115
ERROR - 2018-11-27 21:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Adminback.php 115
ERROR - 2018-11-27 21:31:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\controllers\Adminback.php 116
ERROR - 2018-11-27 21:31:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Adminback.php 116
ERROR - 2018-11-27 21:31:13 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 116
ERROR - 2018-11-27 21:32:11 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 116
ERROR - 2018-11-27 21:35:15 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 116
