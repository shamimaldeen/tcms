<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-02 11:07:09 --> Severity: error --> Exception: Too few arguments to function Course::save_courseapp(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\training\application\controllers\Course.php 153
ERROR - 2018-11-02 11:07:19 --> Severity: error --> Exception: Too few arguments to function Course::save_courseapp(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\training\application\controllers\Course.php 153
ERROR - 2018-11-02 11:10:27 --> Severity: error --> Exception: Too few arguments to function Course::save_courseapp(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\training\application\controllers\Course.php 155
ERROR - 2018-11-02 11:10:29 --> Severity: error --> Exception: Too few arguments to function Course::save_courseapp(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\training\application\controllers\Course.php 155
ERROR - 2018-11-02 11:12:04 --> Severity: error --> Exception: Too few arguments to function Course::save_courseapp(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\training\application\controllers\Course.php 155
ERROR - 2018-11-02 11:13:18 --> Severity: error --> Exception: Too few arguments to function Course::save_courseapp(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\training\application\controllers\Course.php 155
ERROR - 2018-11-02 11:13:21 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 81
ERROR - 2018-11-02 11:13:21 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 81
ERROR - 2018-11-02 16:36:58 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 81
ERROR - 2018-11-02 16:36:58 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 81
ERROR - 2018-11-02 16:37:41 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 81
ERROR - 2018-11-02 16:37:41 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 81
ERROR - 2018-11-02 23:06:04 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\training\application\views\back\courseapp.php 54
ERROR - 2018-11-02 23:27:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_courseapply`, CONSTRAINT `tbl_courseapply_ibfk_3` FOREIGN KEY (`pay_id`) REFERENCES `tbl_payment` (`pay_id`)) - Invalid query: UPDATE `tbl_courseapply` SET `capply_id` = '1', `pay_id` = '1'
WHERE `capply_id` = '1'
ERROR - 2018-11-02 23:30:20 --> Severity: Compile Error --> Cannot redeclare Course::select_batch() C:\xampp\htdocs\training\application\controllers\Course.php 170
ERROR - 2018-11-02 23:30:22 --> Severity: Compile Error --> Cannot redeclare Course::select_batch() C:\xampp\htdocs\training\application\controllers\Course.php 170
ERROR - 2018-11-02 23:31:02 --> Severity: Compile Error --> Cannot redeclare Course::select_batch() C:\xampp\htdocs\training\application\controllers\Course.php 170
ERROR - 2018-11-02 23:31:08 --> Severity: Compile Error --> Cannot redeclare Course::select_batch() C:\xampp\htdocs\training\application\controllers\Course.php 170
ERROR - 2018-11-02 23:38:28 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\select_batch.php 21
ERROR - 2018-11-02 23:38:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\select_batch.php 21
ERROR - 2018-11-02 23:38:28 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\select_batch.php 21
ERROR - 2018-11-02 23:38:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\select_batch.php 21
