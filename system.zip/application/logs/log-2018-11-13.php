<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-13 09:13:54 --> Query error: Unknown column 'pay_paidamount' in 'field list' - Invalid query: INSERT INTO `tbl_admin_payment` (`pay_paidamount`, `pay_method`, `pay_tra_id`, `stu_id`, `pay_date`, `apay_fee`, `apay_method`, `apay_tra_id`, `apay_date`) VALUES ('5', 'SureCash', '5', '27', '2018-11-13', '5', 'SureCash', '5', '2018-11-13')
ERROR - 2018-11-13 09:18:34 --> Query error: Unknown column 'pay_paidamount' in 'field list' - Invalid query: INSERT INTO `tbl_admin_payment` (`pay_paidamount`, `pay_method`, `pay_tra_id`, `stu_id`, `pay_date`, `apay_fee`, `apay_method`, `apay_tra_id`, `apay_date`) VALUES ('65', 'Rocket', '65', '27', '2018-11-13', '65', 'Rocket', '65', '2018-11-13')
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 09:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 15:37:43 --> Query error: Not unique table/alias: 'tbl_batch' - Invalid query: SELECT *
FROM `tbl_routine`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` = `tbl_routine`.`batch_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `tbl_courseapply`.`stu_id` = '27'
GROUP BY `tbl_courseapply`.`course_id`
ERROR - 2018-11-13 15:40:21 --> Query error: Unknown column 'tbl_courseapply.stu_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_routine`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` = `tbl_courseapply`.`course_id`
WHERE `tbl_courseapply`.`stu_id` = '27'
GROUP BY `tbl_courseapply`.`course_id`
ERROR - 2018-11-13 10:46:08 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Student.php 106
ERROR - 2018-11-13 15:46:17 --> Query error: Unknown column 'tbl_routine.routine.id' in 'field list' - Invalid query: SELECT `tbl_batch`.`batch_id`, `tbl_batch`.`batch_title`, `tbl_routine`.`routine`.`id`, `tbl_routine`.`routine_details`
FROM `tbl_routine`
JOIN `tbl_courseapply` ON `tbl_courseapply`.`batch_id` =  `tbl_routine`.`batch_id`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` = `tbl_courseapply`.`course_id`
WHERE `tbl_courseapply`.`stu_id` = '27'
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 10:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 10:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 10:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 10:50:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 10:50:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 11:05:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 11:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-13 16:11:25 --> Severity: Notice --> Use of undefined constant base_url - assumed 'base_url' C:\xampp\htdocs\training\application\views\student\dashboard.php 258
ERROR - 2018-11-13 16:19:29 --> Severity: Notice --> Undefined variable: all_edit_routine C:\xampp\htdocs\training\application\views\student\view_routine_details.php 14
ERROR - 2018-11-13 16:19:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 14
ERROR - 2018-11-13 16:19:29 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\student\view_routine_details.php 21
ERROR - 2018-11-13 16:19:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\student\view_routine_details.php 21
ERROR - 2018-11-13 16:19:29 --> Severity: Notice --> Undefined variable: all_edit_routine C:\xampp\htdocs\training\application\views\student\view_routine_details.php 34
ERROR - 2018-11-13 16:19:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 34
ERROR - 2018-11-13 16:22:33 --> Severity: Notice --> Undefined variable: routines C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:22:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:23:57 --> Severity: Notice --> Undefined variable: routines C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:23:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:32:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:32:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:32:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:32:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:33:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:33:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:33:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:33:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:33:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:33:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:34:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:34:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:34:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:34:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:34:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:34:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:34:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 16:34:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\view_routine_details.php 20
ERROR - 2018-11-13 13:03:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-11-13 13:03:20', '', '')
ERROR - 2018-11-13 13:10:03 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-11-13 13:10:03', '', '')
ERROR - 2018-11-13 13:10:14 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-11-13 13:10:14', '', '')
ERROR - 2018-11-13 14:17:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-11-13 14:17:06', '', '')
ERROR - 2018-11-13 14:17:07 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-11-13 14:17:07', '', '')
ERROR - 2018-11-13 14:58:11 --> Query error: Unknown column 'tbl_payment.pay_status' in 'where clause' - Invalid query: SELECT *
FROM `tbl_courseapply`
WHERE `tbl_payment`.`pay_status` = 'approved'
AND `tbl_courseapply`.`capply_status` = 'Complete'
AND `tbl_courseapply`.`capply_result` != 'F'
ORDER BY `tbl_courseapply`.`capply_id` DESC
 LIMIT 1
ERROR - 2018-11-13 15:08:25 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Course.php 304
ERROR - 2018-11-13 15:10:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Course.php 304
ERROR - 2018-11-13 15:15:17 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Certificate.php 70
ERROR - 2018-11-13 20:55:31 --> Severity: Notice --> Undefined variable: totall_current_student C:\xampp\htdocs\training\application\views\back\dashboard.php 71
ERROR - 2018-11-13 20:55:33 --> Severity: Notice --> Undefined variable: totall_current_student C:\xampp\htdocs\training\application\views\back\dashboard.php 71
ERROR - 2018-11-13 20:56:16 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\application\views\back\dashboard.php 71
ERROR - 2018-11-13 20:56:18 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\application\views\back\dashboard.php 71
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-13 15:58:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-13 15:58:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-13 21:20:21 --> Query error: Unknown column 'tbl_admin_payment.apay_status' in 'where clause' - Invalid query: SELECT count(tbl_courseapply.capply_id) as pending_payment_request
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
WHERE `tbl_admin_payment`.`apay_status` = 'pending'
ERROR - 2018-11-13 21:20:52 --> Query error: Unknown column 'tbl_admin_payment.apay_status' in 'where clause' - Invalid query: SELECT count(tbl_courseapply.capply_id) as pending_payment_request
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
WHERE `tbl_admin_payment`.`apay_status` = 'pending'
ERROR - 2018-11-13 21:21:43 --> Query error: Unknown column 'tbl_admin_payment.apay_status' in 'where clause' - Invalid query: SELECT count(tbl_courseapply.capply_id) as pending_payment_request
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
WHERE `tbl_admin_payment`.`apay_status` = 'pending'
ERROR - 2018-11-13 21:21:47 --> Query error: Unknown column 'tbl_admin_payment.apay_status' in 'where clause' - Invalid query: SELECT count(tbl_courseapply.capply_id) as pending_payment_request
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
WHERE `tbl_admin_payment`.`apay_status` = 'pending'
ERROR - 2018-11-13 21:21:52 --> Query error: Unknown column 'tbl_admin_payment.apay_status' in 'where clause' - Invalid query: SELECT count(tbl_courseapply.capply_id) as pending_payment_request
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
WHERE `tbl_admin_payment`.`apay_status` = 'pending'
ERROR - 2018-11-13 21:22:25 --> Query error: Unknown column 'tbl_admin_payment.apay_status' in 'where clause' - Invalid query: SELECT count(tbl_courseapply.capply_id) as pending_payment_request
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
WHERE `tbl_admin_payment`.`apay_status` = 'pending'
ERROR - 2018-11-13 17:23:23 --> Severity: Notice --> Undefined variable: courses C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:23:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:23:23 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:23:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:23:23 --> Severity: Notice --> Undefined variable: starting_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:23:23 --> Severity: Notice --> Undefined variable: ending_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:23:39 --> Severity: Notice --> Undefined variable: courses C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:23:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:23:39 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:23:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:23:39 --> Severity: Notice --> Undefined variable: starting_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:23:39 --> Severity: Notice --> Undefined variable: ending_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:27:43 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Report.php 150
ERROR - 2018-11-13 17:27:43 --> Severity: Notice --> Undefined variable: courses C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:27:43 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:27:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:27:43 --> Severity: Notice --> Undefined variable: starting_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:27:43 --> Severity: Notice --> Undefined variable: ending_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:29:10 --> Severity: Notice --> Undefined variable: batch C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:29:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:29:10 --> Severity: Notice --> Undefined variable: starting_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:29:10 --> Severity: Notice --> Undefined variable: ending_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:30:07 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Report.php 161
ERROR - 2018-11-13 17:30:08 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Report.php 161
ERROR - 2018-11-13 17:30:23 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Report.php 161
ERROR - 2018-11-13 17:30:28 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Report.php 161
ERROR - 2018-11-13 17:32:21 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Report.php 159
ERROR - 2018-11-13 17:32:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:32:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 29
ERROR - 2018-11-13 17:32:21 --> Severity: Notice --> Undefined variable: starting_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:32:21 --> Severity: Notice --> Undefined variable: ending_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:33:01 --> Severity: Notice --> Undefined variable: starting_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 17:33:01 --> Severity: Notice --> Undefined variable: ending_date C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 30
ERROR - 2018-11-13 18:33:54 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-11-13 18:33:54', '', '')
ERROR - 2018-11-13 18:42:22 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 70
ERROR - 2018-11-13 18:42:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 70
ERROR - 2018-11-13 18:42:22 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:22 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 70
ERROR - 2018-11-13 18:42:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 70
ERROR - 2018-11-13 18:42:22 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:24 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 70
ERROR - 2018-11-13 18:42:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 70
ERROR - 2018-11-13 18:42:24 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:24 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 70
ERROR - 2018-11-13 18:42:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 70
ERROR - 2018-11-13 18:42:24 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:39 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:39 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\training\application\views\back\account_list.php 77
ERROR - 2018-11-13 18:42:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\account_list.php 77
