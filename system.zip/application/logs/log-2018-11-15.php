<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-15 18:25:08 --> Severity: Notice --> Undefined variable: pages C:\xampp\htdocs\training\application\views\front\admin_back\index.php 31
ERROR - 2018-11-15 18:25:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\admin_back\index.php 31
ERROR - 2018-11-15 19:11:42 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-15 20:25:18 --> Severity: Notice --> Undefined variable: pages C:\xampp\htdocs\training\application\views\front\index.php 8
ERROR - 2018-11-15 20:25:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\index.php 8
ERROR - 2018-11-15 20:28:29 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-15 20:28:39 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-15 20:29:43 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-15 20:30:24 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-15 20:31:58 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
