<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-26 14:55:49 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\training\application\views\front\index.php 168
ERROR - 2018-11-26 14:55:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 168
ERROR - 2018-11-26 14:55:49 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\training\application\views\front\index.php 170
ERROR - 2018-11-26 14:55:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 170
ERROR - 2018-11-26 14:55:49 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\training\application\views\front\index.php 172
ERROR - 2018-11-26 14:55:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 172
ERROR - 2018-11-26 14:57:50 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\training\application\views\front\index.php 157
ERROR - 2018-11-26 14:57:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\index.php 157
ERROR - 2018-11-26 14:59:43 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\training\application\views\front\index.php 165
ERROR - 2018-11-26 14:59:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\index.php 165
ERROR - 2018-11-26 15:01:10 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\training\application\views\front\index.php 165
ERROR - 2018-11-26 15:01:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\index.php 165
ERROR - 2018-11-26 15:36:06 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 181
ERROR - 2018-11-26 23:34:10 --> Severity: error --> Exception: syntax error, unexpected 'image' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\training\application\views\front\index.php 10
ERROR - 2018-11-26 23:34:18 --> Severity: error --> Exception: syntax error, unexpected 'image' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\training\application\views\front\index.php 10
ERROR - 2018-11-26 23:34:22 --> Severity: error --> Exception: syntax error, unexpected 'image' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\training\application\views\front\index.php 10
ERROR - 2018-11-26 23:34:22 --> Severity: error --> Exception: syntax error, unexpected 'image' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\training\application\views\front\index.php 10
ERROR - 2018-11-26 23:34:22 --> Severity: error --> Exception: syntax error, unexpected 'image' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\training\application\views\front\index.php 10
ERROR - 2018-11-26 23:34:27 --> Severity: error --> Exception: syntax error, unexpected 'image' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\training\application\views\front\index.php 10
ERROR - 2018-11-26 23:55:52 --> Query error: Column 'page_description' cannot be null - Invalid query: INSERT INTO `tbl_page` (`page_id`, `page_title`, `page_type`, `page_description`, `page_testemonial_desig`, `page_slider_button_link`, `page_image`, `page_added_date`, `page_updated_date`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2018-11-26', '2018-11-26')
