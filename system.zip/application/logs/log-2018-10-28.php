<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-28 00:06:12 --> Severity: error --> Exception: Call to undefined method Staffmodel::edit_staff_info() C:\xampp\htdocs\training\application\controllers\Staff.php 140
ERROR - 2018-10-28 00:07:52 --> Severity: error --> Exception: Call to undefined method Staffmodel::edit_staff_info() C:\xampp\htdocs\training\application\controllers\Staff.php 140
ERROR - 2018-10-28 00:10:12 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 141
ERROR - 2018-10-28 00:10:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 141
ERROR - 2018-10-28 00:10:12 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 142
ERROR - 2018-10-28 00:10:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 142
ERROR - 2018-10-28 00:10:12 --> Severity: Warning --> unlink(uploads/staff/image/): Permission denied C:\xampp\htdocs\training\application\controllers\Staff.php 142
ERROR - 2018-10-28 00:10:12 --> Severity: Notice --> Undefined variable: staff_fullname C:\xampp\htdocs\training\application\controllers\Staff.php 115
ERROR - 2018-10-28 00:10:12 --> Severity: Notice --> Undefined variable: staff_designation C:\xampp\htdocs\training\application\controllers\Staff.php 116
ERROR - 2018-10-28 00:10:12 --> Severity: Notice --> Undefined variable: staff_joining_date C:\xampp\htdocs\training\application\controllers\Staff.php 117
ERROR - 2018-10-28 00:10:12 --> Severity: Notice --> Undefined variable: staff_cnumber C:\xampp\htdocs\training\application\controllers\Staff.php 118
ERROR - 2018-10-28 00:10:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\training\system\core\Exceptions.php:271) C:\xampp\htdocs\training\system\helpers\url_helper.php 564
ERROR - 2018-10-28 00:14:04 --> Severity: Notice --> Undefined variable: staff_fullname C:\xampp\htdocs\training\application\controllers\Staff.php 117
ERROR - 2018-10-28 00:14:04 --> Severity: Notice --> Undefined variable: staff_designation C:\xampp\htdocs\training\application\controllers\Staff.php 118
ERROR - 2018-10-28 00:14:04 --> Severity: Notice --> Undefined variable: staff_joining_date C:\xampp\htdocs\training\application\controllers\Staff.php 119
ERROR - 2018-10-28 00:14:04 --> Severity: Notice --> Undefined variable: staff_cnumber C:\xampp\htdocs\training\application\controllers\Staff.php 120
ERROR - 2018-10-28 00:17:08 --> Severity: Notice --> Undefined variable: staff_fullname C:\xampp\htdocs\training\application\controllers\Staff.php 116
ERROR - 2018-10-28 00:17:08 --> Severity: Notice --> Undefined variable: staff_designation C:\xampp\htdocs\training\application\controllers\Staff.php 117
ERROR - 2018-10-28 00:17:08 --> Severity: Notice --> Undefined variable: staff_joining_date C:\xampp\htdocs\training\application\controllers\Staff.php 118
ERROR - 2018-10-28 00:17:08 --> Severity: Notice --> Undefined variable: staff_cnumber C:\xampp\htdocs\training\application\controllers\Staff.php 119
ERROR - 2018-10-28 00:23:29 --> Severity: Notice --> Undefined variable: staff_fullname C:\xampp\htdocs\training\application\controllers\Staff.php 119
ERROR - 2018-10-28 00:23:29 --> Severity: Notice --> Undefined variable: staff_designation C:\xampp\htdocs\training\application\controllers\Staff.php 120
ERROR - 2018-10-28 00:23:29 --> Severity: Notice --> Undefined variable: staff_joining_date C:\xampp\htdocs\training\application\controllers\Staff.php 121
ERROR - 2018-10-28 00:23:29 --> Severity: Notice --> Undefined variable: staff_cnumber C:\xampp\htdocs\training\application\controllers\Staff.php 122
ERROR - 2018-10-28 00:26:48 --> Severity: Notice --> Undefined variable: staff_fullname C:\xampp\htdocs\training\application\controllers\Staff.php 106
ERROR - 2018-10-28 00:26:48 --> Severity: Notice --> Undefined variable: staff_designation C:\xampp\htdocs\training\application\controllers\Staff.php 107
ERROR - 2018-10-28 00:26:48 --> Severity: Notice --> Undefined variable: staff_joining_date C:\xampp\htdocs\training\application\controllers\Staff.php 108
ERROR - 2018-10-28 00:26:48 --> Severity: Notice --> Undefined variable: staff_cnumber C:\xampp\htdocs\training\application\controllers\Staff.php 109
ERROR - 2018-10-28 00:26:48 --> Severity: Notice --> Undefined variable: staff_fullname C:\xampp\htdocs\training\application\controllers\Staff.php 106
ERROR - 2018-10-28 00:26:48 --> Severity: Notice --> Undefined variable: staff_designation C:\xampp\htdocs\training\application\controllers\Staff.php 107
ERROR - 2018-10-28 00:26:48 --> Severity: Notice --> Undefined variable: staff_joining_date C:\xampp\htdocs\training\application\controllers\Staff.php 108
ERROR - 2018-10-28 00:26:48 --> Severity: Notice --> Undefined variable: staff_cnumber C:\xampp\htdocs\training\application\controllers\Staff.php 109
ERROR - 2018-10-28 00:30:31 --> Severity: error --> Exception: Call to undefined method Staffmodel::edit_staff_info() C:\xampp\htdocs\training\application\controllers\Staff.php 137
ERROR - 2018-10-28 00:31:18 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 138
ERROR - 2018-10-28 00:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 138
ERROR - 2018-10-28 00:31:18 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:31:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:31:18 --> Severity: Warning --> unlink(uploads/staff/image/): Permission denied C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:31:32 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 138
ERROR - 2018-10-28 00:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 138
ERROR - 2018-10-28 00:31:32 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:31:32 --> Severity: Warning --> unlink(uploads/staff/image/): Permission denied C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:31:51 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 138
ERROR - 2018-10-28 00:31:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 138
ERROR - 2018-10-28 00:31:51 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:31:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:31:51 --> Severity: Warning --> unlink(uploads/staff/image/): Permission denied C:\xampp\htdocs\training\application\controllers\Staff.php 139
ERROR - 2018-10-28 00:37:14 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 131
ERROR - 2018-10-28 00:37:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 131
ERROR - 2018-10-28 00:37:14 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 132
ERROR - 2018-10-28 00:37:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 132
ERROR - 2018-10-28 00:37:14 --> Severity: Warning --> unlink(uploads/Staff/image/): Permission denied C:\xampp\htdocs\training\application\controllers\Staff.php 132
ERROR - 2018-10-28 00:37:29 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 131
ERROR - 2018-10-28 00:37:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 131
ERROR - 2018-10-28 00:37:29 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 132
ERROR - 2018-10-28 00:37:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 132
ERROR - 2018-10-28 00:37:29 --> Severity: Warning --> unlink(uploads/Staff/image/): Permission denied C:\xampp\htdocs\training\application\controllers\Staff.php 132
ERROR - 2018-10-28 00:38:10 --> Severity: Notice --> Undefined variable: staff C:\xampp\htdocs\training\application\controllers\Staff.php 130
ERROR - 2018-10-28 00:38:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Staff.php 130
ERROR - 2018-10-28 00:39:01 --> Severity: Warning --> unlink(uploads/Staff/image/): Permission denied C:\xampp\htdocs\training\application\controllers\Staff.php 133
ERROR - 2018-10-28 07:07:58 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\course_list.php 25
ERROR - 2018-10-28 07:07:58 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\course_list.php 25
ERROR - 2018-10-28 07:07:58 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\course_list.php 149
ERROR - 2018-10-28 07:07:58 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\course_list.php 149
ERROR - 2018-10-28 08:37:14 --> Severity: error --> Exception: Call to undefined method Coursemodel::all_edit_course() C:\xampp\htdocs\training\application\controllers\Course.php 69
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:39:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:39:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:39:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:39:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:39:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:39:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:39:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:39:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:40:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:41:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:41:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:41:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:41:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:41:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:47:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 08:47:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:00:43 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\training\application\controllers\Course.php 112
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:03:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:04:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:04:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:04:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:06:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:07:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:15:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:15:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 09:15:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:15:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 09:25:49 --> Severity: Compile Error --> Cannot declare class Accountmodel, because the name is already in use C:\xampp\htdocs\training\application\models\Batchmodel.php 15
ERROR - 2018-10-28 09:26:40 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\batch_list.php 24
ERROR - 2018-10-28 09:26:40 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\batch_list.php 24
ERROR - 2018-10-28 09:26:40 --> Severity: Warning --> include(sidebar.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\batch_list.php 78
ERROR - 2018-10-28 09:26:40 --> Severity: Warning --> include(): Failed opening 'sidebar.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\batch_list.php 78
ERROR - 2018-10-28 09:26:40 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\batch_list.php 87
ERROR - 2018-10-28 09:26:40 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\batch_list.php 87
ERROR - 2018-10-28 09:45:03 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\training\application\views\back\batch_list.php 166
ERROR - 2018-10-28 09:45:05 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\training\application\views\back\batch_list.php 166
ERROR - 2018-10-28 13:29:57 --> Severity: error --> Exception: Call to undefined function baes_url() C:\xampp\htdocs\training\application\views\back\batch_list.php 50
ERROR - 2018-10-28 13:30:01 --> Severity: error --> Exception: Call to undefined function baes_url() C:\xampp\htdocs\training\application\views\back\batch_list.php 50
ERROR - 2018-10-28 13:30:18 --> Severity: error --> Exception: Call to undefined function baes_url() C:\xampp\htdocs\training\application\views\back\batch_list.php 50
ERROR - 2018-10-28 13:30:42 --> Severity: error --> Exception: Call to undefined function baes_url() C:\xampp\htdocs\training\application\views\back\batch_list.php 50
ERROR - 2018-10-28 13:30:44 --> Severity: error --> Exception: Call to undefined function baes_url() C:\xampp\htdocs\training\application\views\back\batch_list.php 50
ERROR - 2018-10-28 13:30:55 --> Severity: error --> Exception: Call to undefined function baes_url() C:\xampp\htdocs\training\application\views\back\batch_list.php 50
ERROR - 2018-10-28 13:32:34 --> Severity: error --> Exception: Call to undefined function baes_url() C:\xampp\htdocs\training\application\views\back\batch_list.php 50
ERROR - 2018-10-28 13:32:35 --> Severity: error --> Exception: Call to undefined function baes_url() C:\xampp\htdocs\training\application\views\back\batch_list.php 50
ERROR - 2018-10-28 13:42:14 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-10-28 13:42:20 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-10-28 13:42:24 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-10-28 13:57:35 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\add_routine.php 100
ERROR - 2018-10-28 13:57:35 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\add_routine.php 100
ERROR - 2018-10-28 14:11:53 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:11:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:11:56 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:11:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:16:23 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:16:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:24:49 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:24:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:30:45 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 14:30:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\add_routine.php 22
ERROR - 2018-10-28 15:04:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:04:29 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:04:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:04:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:04:29 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:04:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:05:44 --> Severity: Notice --> Undefined property: stdClass::$batch_title C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:44 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:05:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:44 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:05:54 --> Severity: Notice --> Undefined property: stdClass::$batch_title C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:54 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:05:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:54 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:05:55 --> Severity: Notice --> Undefined property: stdClass::$batch_title C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:55 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:05:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 21
ERROR - 2018-10-28 15:05:55 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:05:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:09:38 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:09:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:09:38 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:09:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\edit_routine.php 22
ERROR - 2018-10-28 15:09:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:11:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:13:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:13:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:13:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:13:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:13:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:13:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:30:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:30:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:37:29 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\training\application\controllers\Routine.php 114
ERROR - 2018-10-28 15:37:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:37:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:37:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:37:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:37:53 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\models\Routinemodel.php 49
ERROR - 2018-10-28 15:37:53 --> Severity: Notice --> Undefined variable: routine_detail C:\xampp\htdocs\training\application\models\Routinemodel.php 50
ERROR - 2018-10-28 15:37:53 --> Query error: Unknown column 'routine_detail' in 'where clause' - Invalid query: SELECT *
FROM `tbl_routine`
WHERE `batch_id` IS NULL
AND `routine_detail` IS NULL
ERROR - 2018-10-28 15:43:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:43:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:43:22 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:43:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:43:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:43:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:43:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:43:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:43:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:43:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:43:37 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:43:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:44:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:44:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:44:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:44:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:45:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:45:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:45:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:45:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:45:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:45:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:45:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:45:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:45:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:45:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:45:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:45:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:46:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:46:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:46:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:46:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:46:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:48:18 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:18 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:18 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:18 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:48:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:48:34 --> Severity: error --> Exception: syntax error, unexpected 'ch_id' (T_STRING) C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:48:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:49:13 --> Severity: Notice --> Undefined property: stdClass::$bacth_id C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:49:13 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:49:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:49:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:49:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:49:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:49:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:49:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:50:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:50:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:50:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:50:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:50:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:50:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:50:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:50:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:16 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:52:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:52:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:52:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:53:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:53:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:53:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:53:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:53:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:53:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:53:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:53:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:54:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 15:54:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 15:54:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 15:54:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 15:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 15:54:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 15:56:41 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-10-28 15:56:45 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:58:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:58:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 15:58:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-10-28 15:58:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-10-28 15:58:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-10-28 15:58:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 19:06:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 19:06:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-28 19:07:21 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-10-28 19:08:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 19:08:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 19:08:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 19:08:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 19:08:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 19:08:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 19:08:15 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 19:08:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 19:08:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 19:08:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-28 19:08:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 19:08:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 19:08:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 19:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-28 19:08:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 19:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-28 19:16:50 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-28 19:16:50 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-28 19:16:50 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-28 19:16:50 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-28 19:23:19 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-28 19:23:19 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-28 19:23:19 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-28 19:23:19 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-28 19:24:19 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-28 19:24:19 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-28 19:24:19 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-28 19:24:19 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-28 19:29:34 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-28 19:29:34 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-28 19:29:34 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-28 19:29:34 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
