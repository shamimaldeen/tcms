<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-20 00:00:06 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:13:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:13:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:13:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:13:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:13:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:13:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 00:15:06 --> 404 Page Not Found: Department/index
ERROR - 2018-10-20 04:15:35 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\department_list.php 63
ERROR - 2018-10-20 04:15:48 --> Severity: Notice --> Use of undefined constant BASE_URL - assumed 'BASE_URL' C:\xampp\htdocs\hrms\application\views\department_list.php 7
ERROR - 2018-10-20 00:20:16 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:20:21 --> 404 Page Not Found: Productsphp/index
ERROR - 2018-10-20 00:20:57 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:23:57 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:26:37 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:26:48 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:27:05 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:30:45 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:31:13 --> 404 Page Not Found: Department/index
ERROR - 2018-10-20 00:31:34 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:50:34 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:50:34 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:50:34 --> 404 Page Not Found: Addproductphp/index
ERROR - 2018-10-20 00:53:08 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 22
ERROR - 2018-10-20 01:04:03 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 19
ERROR - 2018-10-20 01:04:22 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 19
ERROR - 2018-10-20 01:05:07 --> 404 Page Not Found: Productsphp/index
ERROR - 2018-10-20 01:05:14 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 19
ERROR - 2018-10-20 01:15:26 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 19
ERROR - 2018-10-20 05:16:07 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:16:07 --> Severity: error --> Exception: Call to a member function department_info() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:16:12 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:16:12 --> Severity: error --> Exception: Call to a member function department_info() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:17:44 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:17:44 --> Severity: error --> Exception: Call to a member function department_info() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 01:19:00 --> 404 Page Not Found: Department/add_department
ERROR - 2018-10-20 01:19:05 --> 404 Page Not Found: Department/add_department
ERROR - 2018-10-20 01:19:10 --> 404 Page Not Found: Department/add_department
ERROR - 2018-10-20 01:19:34 --> 404 Page Not Found: Department/add_department
ERROR - 2018-10-20 01:22:11 --> 404 Page Not Found: Add_department/index
ERROR - 2018-10-20 01:22:59 --> 404 Page Not Found: Add_department/index
ERROR - 2018-10-20 01:24:22 --> 404 Page Not Found: Add_department/index
ERROR - 2018-10-20 01:24:59 --> 404 Page Not Found: Add_department/index
ERROR - 2018-10-20 01:26:20 --> 404 Page Not Found: Productsphp/index
ERROR - 2018-10-20 05:32:38 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\views\add_department.php 20
ERROR - 2018-10-20 01:37:52 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 68
ERROR - 2018-10-20 01:37:53 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 68
ERROR - 2018-10-20 01:37:59 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 68
ERROR - 2018-10-20 01:38:05 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 68
ERROR - 2018-10-20 01:38:09 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 68
ERROR - 2018-10-20 01:38:22 --> 404 Page Not Found: Productsphp/index
ERROR - 2018-10-20 01:40:48 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 70
ERROR - 2018-10-20 01:40:48 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 70
ERROR - 2018-10-20 05:45:39 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:45:39 --> Severity: error --> Exception: Call to a member function department_info() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:45:53 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:45:53 --> Severity: error --> Exception: Call to a member function department_info() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:45:54 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:45:54 --> Severity: error --> Exception: Call to a member function department_info() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:46:08 --> Severity: error --> Exception: Call to undefined method Departmentmodel::department_info() C:\xampp\htdocs\hrms\application\controllers\Department.php 34
ERROR - 2018-10-20 05:48:26 --> Query error: Unknown column 'department' in 'field list' - Invalid query: SELECT `department`
FROM `department`
ORDER BY `dept_name` ASC
ERROR - 2018-10-20 05:51:15 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\department_list.php 13
ERROR - 2018-10-20 05:51:21 --> Severity: Notice --> Undefined variable: db C:\xampp\htdocs\hrms\application\views\department_list.php 42
ERROR - 2018-10-20 05:51:21 --> Severity: error --> Exception: Call to a member function select() on null C:\xampp\htdocs\hrms\application\views\department_list.php 42
ERROR - 2018-10-20 05:51:55 --> Severity: error --> Exception: syntax error, unexpected 'endwhile' (T_ENDWHILE), expecting end of file C:\xampp\htdocs\hrms\application\views\department_list.php 64
ERROR - 2018-10-20 05:52:06 --> Severity: Notice --> Undefined variable: r C:\xampp\htdocs\hrms\application\views\department_list.php 54
ERROR - 2018-10-20 05:52:06 --> Severity: Notice --> Undefined variable: r C:\xampp\htdocs\hrms\application\views\department_list.php 54
ERROR - 2018-10-20 05:52:06 --> Severity: Notice --> Undefined variable: r C:\xampp\htdocs\hrms\application\views\department_list.php 55
ERROR - 2018-10-20 05:52:06 --> Severity: Notice --> Undefined variable: r C:\xampp\htdocs\hrms\application\views\department_list.php 55
ERROR - 2018-10-20 17:57:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 17:57:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 17:57:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-20 17:57:22 --> 404 Page Not Found: Uploads/favicon.PNG
ERROR - 2018-10-20 18:01:30 --> 404 Page Not Found: Productsphp/index
ERROR - 2018-10-20 18:10:16 --> 404 Page Not Found: Productsphp/index
ERROR - 2018-10-20 18:12:27 --> 404 Page Not Found: Productsphp/index
ERROR - 2018-10-20 18:16:28 --> 404 Page Not Found: Addsupplierphp/index
ERROR - 2018-10-20 19:01:05 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 19:01:34 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 19:01:36 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 19:01:38 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 19:01:39 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:01:40 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 19:01:41 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:01:41 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 19:01:42 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:02:50 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:02:51 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:02:51 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:02:52 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:02:55 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 19:03:25 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:03:26 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:03:28 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:03:29 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:03:30 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:03:46 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 19:03:49 --> Severity: error --> Exception: syntax error, unexpected '*' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 29
ERROR - 2018-10-20 23:04:37 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:04:37 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 19:07:45 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 79
ERROR - 2018-10-20 19:07:46 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 79
ERROR - 2018-10-20 23:08:30 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:08:30 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:08:32 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:08:32 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:10:40 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:10:40 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:10:41 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:10:41 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:12:20 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:12:20 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:12:21 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:12:21 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:12:29 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:12:29 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:13:59 --> Severity: Notice --> Undefined property: CI_Loader::$departmentmodel C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:13:59 --> Severity: error --> Exception: Call to a member function all_edit_department() on null C:\xampp\htdocs\hrms\application\controllers\Department.php 76
ERROR - 2018-10-20 23:14:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:14:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:15:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:15:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:15:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:15:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:16:35 --> Severity: Notice --> Undefined variable: dept_name C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:20:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:20:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:27:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:28:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:31:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 31
ERROR - 2018-10-20 23:31:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 37
ERROR - 2018-10-20 23:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 37
ERROR - 2018-10-20 23:34:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 37
ERROR - 2018-10-20 23:34:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_department.php 37
ERROR - 2018-10-20 19:47:23 --> 404 Page Not Found: Department/update-department
ERROR - 2018-10-20 20:06:02 --> Severity: error --> Exception: syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 48
ERROR - 2018-10-20 20:06:43 --> 404 Page Not Found: Department/update-department
ERROR - 2018-10-20 21:39:30 --> Severity: error --> Exception: syntax error, unexpected '$row' (T_VARIABLE) C:\xampp\htdocs\hrms\application\models\Departmentmodel.php 81
ERROR - 2018-10-20 21:42:49 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 12
ERROR - 2018-10-20 21:43:01 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 12
ERROR - 2018-10-20 21:43:02 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' C:\xampp\htdocs\hrms\application\controllers\Department.php 12
ERROR - 2018-10-20 22:06:01 --> 404 Page Not Found: Addpurchasephp/index
ERROR - 2018-10-20 22:07:39 --> 404 Page Not Found: Add_designation/index
ERROR - 2018-10-20 22:08:18 --> 404 Page Not Found: Add_designation/index
ERROR - 2018-10-20 22:09:01 --> 404 Page Not Found: Add_designation/index
ERROR - 2018-10-20 22:09:02 --> 404 Page Not Found: Add_designation/index
ERROR - 2018-10-20 22:09:03 --> 404 Page Not Found: Add_designation/index
ERROR - 2018-10-20 22:09:03 --> 404 Page Not Found: Add_designation/index
ERROR - 2018-10-20 22:09:06 --> 404 Page Not Found: Add_designation/index
ERROR - 2018-10-20 22:47:54 --> Query error: Column 'desig_name' cannot be null - Invalid query: INSERT INTO `desination` (`desig_name`) VALUES (NULL)
ERROR - 2018-10-20 23:08:25 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Designationmodel.php 17
ERROR - 2018-10-20 23:08:26 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Designationmodel.php 17
ERROR - 2018-10-20 23:08:27 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ',' or ')' C:\xampp\htdocs\hrms\application\models\Designationmodel.php 17
ERROR - 2018-10-20 23:09:49 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:09:49 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:12:00 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:12:00 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:16:53 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:16:53 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:34:51 --> 404 Page Not Found: Purchaselistphp/index
ERROR - 2018-10-20 23:35:20 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:35:20 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:36:05 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:36:05 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:36:14 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:36:14 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:36:43 --> 404 Page Not Found: Save_designation/index
ERROR - 2018-10-20 23:36:52 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:36:52 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:41:09 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:41:09 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:41:18 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:41:18 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:41:31 --> Severity: Notice --> Undefined property: Designation::$designationmodel C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:41:31 --> Severity: error --> Exception: Call to a member function designation_info() on null C:\xampp\htdocs\hrms\application\controllers\Designation.php 16
ERROR - 2018-10-20 23:42:30 --> Query error: Column 'desig_name' cannot be null - Invalid query: INSERT INTO `desination` (`desig_name`) VALUES (NULL)
ERROR - 2018-10-20 23:42:54 --> Query error: Column 'desig_name' cannot be null - Invalid query: INSERT INTO `desination` (`desig_name`) VALUES (NULL)
