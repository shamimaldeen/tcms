<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-28 11:22:47 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 136
ERROR - 2018-11-28 11:26:07 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 136
ERROR - 2018-11-28 11:27:10 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 136
ERROR - 2018-11-28 11:27:57 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 136
ERROR - 2018-11-28 11:28:44 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 136
ERROR - 2018-11-28 11:29:48 --> Severity: Warning --> unlink(./uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 136
ERROR - 2018-11-28 11:30:51 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 136
ERROR - 2018-11-28 11:31:09 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 136
ERROR - 2018-11-28 16:45:42 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 138
ERROR - 2018-11-28 16:48:20 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 138
ERROR - 2018-11-28 16:49:48 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 138
ERROR - 2018-11-28 16:50:27 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 138
ERROR - 2018-11-28 16:53:00 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 138
ERROR - 2018-11-28 16:55:00 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 138
ERROR - 2018-11-28 17:04:30 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 137
ERROR - 2018-11-28 17:09:53 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 137
ERROR - 2018-11-28 17:17:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:17:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:19:04 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:19:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:19:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:19:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:19:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:19:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:19:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:19:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:23:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:23:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:23:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:23:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:24:37 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:24:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:25:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:25:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:25:11 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:25:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:30:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:30:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:31:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:31:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:31:12 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:31:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:34:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:34:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:42:40 --> Severity: Notice --> Undefined variable: sliders C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:42:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:43:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:43:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:48:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:48:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:27 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:55 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:55 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:50:43 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:50:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:50:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:50:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:51:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:51:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:51:45 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:51:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 63
ERROR - 2018-11-28 17:58:40 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 137
ERROR - 2018-11-28 18:04:45 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 139
ERROR - 2018-11-28 18:05:02 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 139
ERROR - 2018-11-28 18:05:12 --> Severity: Warning --> unlink(uploads/front/site/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 139
ERROR - 2018-11-28 18:52:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:52:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:52:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:52:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:52:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:52:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:52:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:52:55 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:52:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:52:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 172
ERROR - 2018-11-28 18:52:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:54:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:54:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:55:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:55:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:56:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:56:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:59:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 18:59:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:02:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:02:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:02:40 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:02:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:02:40 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:02:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:02:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:10:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:10:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:10:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:10:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:10:28 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:10:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:10:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:12:19 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:12:22 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:12:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:12:25 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:24 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:29 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:29 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:29 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:29 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:29 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:30 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:30 --> Severity: Notice --> Undefined variable: dara C:\xampp\htdocs\training\application\controllers\Front.php 60
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:13:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:14:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:15:07 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:15:08 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:15:08 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:15:08 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:15:08 --> Severity: Notice --> Undefined property: stdClass::$site_address C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:15:08 --> Severity: Notice --> Undefined property: stdClass::$facebook C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:15:08 --> Severity: Notice --> Undefined property: stdClass::$twitter C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:15:08 --> Severity: Notice --> Undefined property: stdClass::$youtube C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined property: stdClass::$site_address C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined property: stdClass::$facebook C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined property: stdClass::$twitter C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:16:42 --> Severity: Notice --> Undefined property: stdClass::$youtube C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:17:09 --> Query error: Unknown column 'page_type' in 'where clause' - Invalid query: SELECT *
FROM `tbl_site`
WHERE `page_type` = 'About Us'
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined property: stdClass::$site_address C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined property: stdClass::$facebook C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined property: stdClass::$twitter C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:17:29 --> Severity: Notice --> Undefined property: stdClass::$youtube C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:18:32 --> Query error: Unknown column 'page_type' in 'where clause' - Invalid query: SELECT *
FROM `tbl_site`
WHERE `page_type` = 'About Us'
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:18:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:19:19 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-28 19:19:19 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-28 19:19:19 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 32
ERROR - 2018-11-28 19:19:19 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:20:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:20:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:20:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:20:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:20:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:20:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:20:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:20:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:21:04 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:21:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:21:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:22:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:22:26 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 188
ERROR - 2018-11-28 19:22:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:22:39 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:22:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:22:40 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:22:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:22:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:22:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:23:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:23:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:23:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:23:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:24:13 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:24:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:24:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-28 19:24:19 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:24:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:24:36 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:24:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:24:45 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:24:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:26:14 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:26:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:26:23 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:26:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:26:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:26:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-28 19:26:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:26:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-28 19:26:32 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:26:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:26:35 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 189
ERROR - 2018-11-28 19:26:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:28:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:28:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:28:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:28:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:28:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:28:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:32:06 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:32:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:35:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:35:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:35:41 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:35:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:38:29 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:38:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:41:43 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:41:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:58:05 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:58:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:58:28 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:58:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 19:58:47 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 19:58:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:04:38 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:04:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:04:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:04:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:14:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:14:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:14:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:14:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:15:39 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:15:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:15:46 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:15:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:17:22 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:17:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:17:48 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:17:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 20:39:37 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 20:39:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 20:40:44 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 20:40:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 20:40:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 20:40:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 20:41:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 20:41:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 21:15:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:15:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:16:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:16:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:16:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:16:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:17:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:17:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:17:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:17:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:19:25 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:37 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:40 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:44 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:48 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:53 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:19:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:20:02 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:20:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:20:08 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:20:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:20:42 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:20:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:20:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:20:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:21:03 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:21:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:21:13 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:21:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:21:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:23:55 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:23:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:24:27 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 21:24:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 21:24:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 21:24:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 21:24:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 187
ERROR - 2018-11-28 21:24:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 21:25:47 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:25:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:25:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:25:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:27:31 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:27:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-28 21:28:08 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 3
ERROR - 2018-11-28 21:28:27 --> Severity: Notice --> Undefined variable: totall_current_student C:\xampp\htdocs\training\application\views\back\lib\header.php 3
ERROR - 2018-11-28 21:28:28 --> Severity: Notice --> Undefined variable: totall_current_student C:\xampp\htdocs\training\application\views\back\lib\header.php 3
ERROR - 2018-11-28 21:28:28 --> Severity: Notice --> Undefined variable: totall_current_student C:\xampp\htdocs\training\application\views\back\lib\header.php 3
ERROR - 2018-11-28 21:28:33 --> Severity: Notice --> Undefined variable: total_current_student C:\xampp\htdocs\training\application\views\back\lib\header.php 3
ERROR - 2018-11-28 21:28:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:29:24 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:29:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:29:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:29:30 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:29:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:30:04 --> Severity: Notice --> Undefined variable: total_current_student C:\xampp\htdocs\training\application\views\back\lib\header.php 3
ERROR - 2018-11-28 21:30:28 --> Severity: Notice --> Undefined variable: complited_course C:\xampp\htdocs\training\application\views\back\lib\header.php 3
ERROR - 2018-11-28 21:30:53 --> Severity: Notice --> Undefined variable: complited_course C:\xampp\htdocs\training\application\views\back\lib\header.php 3
ERROR - 2018-11-28 21:31:09 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:31:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:31:46 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:31:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:32:44 --> Severity: Notice --> Undefined variable: site C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:32:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:32:47 --> Severity: Notice --> Undefined variable: site C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:32:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:33:09 --> Severity: Notice --> Undefined variable: site C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:33:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-28 21:37:55 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 21:37:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\admin_back\lib\header.php 39
ERROR - 2018-11-28 22:56:11 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 319
ERROR - 2018-11-28 22:56:32 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 319
ERROR - 2018-11-28 22:56:49 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 319
ERROR - 2018-11-28 22:57:32 --> Severity: Warning --> unlink(uploads/front/): Permission denied C:\xampp\htdocs\training\application\controllers\Adminback.php 319
ERROR - 2018-11-28 23:31:47 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:31:48 --> Severity: Notice --> Undefined variable: page_id C:\xampp\htdocs\training\application\views\front\admin_back\index.php 48
ERROR - 2018-11-28 23:48:17 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 213
ERROR - 2018-11-28 23:48:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
ERROR - 2018-11-28 23:49:33 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\training\application\controllers\Front.php 213
ERROR - 2018-11-28 23:49:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '-3, 3' at line 5 - Invalid query: SELECT *
FROM `tbl_page`
WHERE `page_type` = 'Blog'
ORDER BY `page_id` DESC
 LIMIT -3, 3
