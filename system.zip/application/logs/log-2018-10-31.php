<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-31 11:08:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-31 11:09:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-31 11:09:27 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`tcms`.`tbl_courseapply`, CONSTRAINT `tbl_courseapply_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `tbl_course` (`course_id`)) - Invalid query: DELETE FROM `tbl_course`
WHERE `course_id` = '2'
ERROR - 2018-10-31 11:12:56 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`tcms`.`tbl_courseapply`, CONSTRAINT `tbl_courseapply_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `tbl_course` (`course_id`)) - Invalid query: DELETE FROM `tbl_course`
WHERE `course_id` = '2'
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-31 11:14:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-31 11:32:05 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:32:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:32:07 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:34:40 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:36:15 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:36:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:38:04 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:38:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:38:11 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:38:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:39:04 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:39:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-31 11:39:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-31 11:39:55 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 11:39:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\courseapp.php 104
ERROR - 2018-10-31 12:57:49 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 87
ERROR - 2018-10-31 12:57:49 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 87
ERROR - 2018-10-31 12:57:49 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 161
ERROR - 2018-10-31 12:57:49 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 161
ERROR - 2018-10-31 12:58:59 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 87
ERROR - 2018-10-31 12:58:59 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 87
ERROR - 2018-10-31 12:58:59 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 161
ERROR - 2018-10-31 12:58:59 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 161
ERROR - 2018-10-31 13:02:04 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:02:04 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:03:06 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:03:06 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:05:56 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:05:56 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:07:01 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:07:01 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:07:10 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:07:10 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:08:27 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
ERROR - 2018-10-31 13:08:27 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\views\back\courseapp.php 109
