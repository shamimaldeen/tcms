<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-04 06:52:17 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-04 06:52:17 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-04 06:54:08 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-04 06:54:08 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-04 06:55:50 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-04 06:55:50 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-04 06:57:41 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-04 06:57:41 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-04 06:58:44 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-04 06:58:44 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-04 07:00:00 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-04 07:00:00 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-04 07:02:52 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-04 07:02:52 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-04 07:03:32 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:32 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:32 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:32 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 24
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:03:33 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\attendance_entry.php 86
ERROR - 2018-11-04 07:14:42 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH), expecting end of file C:\xampp\htdocs\training\application\views\back\attendance_entry.php 35
ERROR - 2018-11-04 07:22:44 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\application\controllers\Attendance.php 91
ERROR - 2018-11-04 07:22:44 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\application\controllers\Attendance.php 91
ERROR - 2018-11-04 07:22:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\application\controllers\Attendance.php 91
ERROR - 2018-11-04 07:22:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\training\application\controllers\Attendance.php 91
ERROR - 2018-11-04 07:26:47 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\training\application\controllers\Attendance.php 92
ERROR - 2018-11-04 07:27:38 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\training\application\controllers\Attendance.php 92
ERROR - 2018-11-04 07:29:50 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Attendance.php 74
ERROR - 2018-11-04 07:30:13 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 07:30:13 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'present')
ERROR - 2018-11-04 07:30:52 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\training\application\controllers\Attendance.php 94
ERROR - 2018-11-04 07:32:04 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\training\application\controllers\Attendance.php 94
ERROR - 2018-11-04 07:32:32 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\training\application\controllers\Attendance.php 94
ERROR - 2018-11-04 07:33:48 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\training\application\controllers\Attendance.php 96
ERROR - 2018-11-04 07:34:52 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\training\application\controllers\Attendance.php 97
ERROR - 2018-11-04 07:35:39 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\training\application\controllers\Attendance.php 97
ERROR - 2018-11-04 13:49:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\training\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-04 13:49:33 --> Unable to connect to the database
ERROR - 2018-11-04 14:25:17 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:25:18 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'absent')
ERROR - 2018-11-04 14:27:11 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:27:11 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'absent')
ERROR - 2018-11-04 14:27:58 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:27:58 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'absent')
ERROR - 2018-11-04 14:28:57 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:28:57 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'absent')
ERROR - 2018-11-04 14:29:25 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:29:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'absent')
ERROR - 2018-11-04 14:30:32 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:30:32 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'absent')
ERROR - 2018-11-04 14:36:52 --> Severity: Notice --> Undefined property: stdClass::$att_status C:\xampp\htdocs\training\application\views\back\attendance_entry.php 32
ERROR - 2018-11-04 14:36:52 --> Severity: Notice --> Undefined property: stdClass::$att_status C:\xampp\htdocs\training\application\views\back\attendance_entry.php 32
ERROR - 2018-11-04 14:45:21 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:45:21 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 97
ERROR - 2018-11-04 14:45:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', NULL)
ERROR - 2018-11-04 14:47:15 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:47:15 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 98
ERROR - 2018-11-04 14:47:16 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', NULL)
ERROR - 2018-11-04 14:47:42 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:47:42 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 98
ERROR - 2018-11-04 14:47:42 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', NULL)
ERROR - 2018-11-04 14:48:25 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:48:25 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'absent')
ERROR - 2018-11-04 14:50:51 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:50:51 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 98
ERROR - 2018-11-04 14:50:51 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', NULL)
ERROR - 2018-11-04 14:52:12 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 14:52:12 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('19', '', 'present')
ERROR - 2018-11-04 15:15:50 --> Severity: Notice --> Undefined index: stu_id C:\xampp\htdocs\training\application\controllers\Attendance.php 90
ERROR - 2018-11-04 15:17:24 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 15:17:24 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'present')
ERROR - 2018-11-04 15:17:33 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 15:17:33 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'present')
ERROR - 2018-11-04 15:17:45 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 15:17:45 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'present')
ERROR - 2018-11-04 15:18:26 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 15:18:27 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'present')
ERROR - 2018-11-04 15:18:58 --> Severity: Notice --> Uninitialized string offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 93
ERROR - 2018-11-04 15:18:59 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_attendance`, CONSTRAINT `tbl_attendance_ibfk_2` FOREIGN KEY (`batch_id`) REFERENCES `tbl_batch` (`batch_id`)) - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_status`) VALUES ('21', '', 'present')
ERROR - 2018-11-04 15:19:40 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 98
ERROR - 2018-11-04 15:20:11 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 98
ERROR - 2018-11-04 15:21:08 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\training\application\controllers\Attendance.php 98
ERROR - 2018-11-04 15:27:28 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Attendance.php 115
ERROR - 2018-11-04 15:27:28 --> Query error: Unknown column 'tbl_courseapply.stu_id' in 'on clause' - Invalid query: SELECT `tbl_student`.*, `tbl_batch`.`batch_title`, `tbl_batch`.`batch_id`
FROM `tbl_attendance`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `tbl_batch`.`batch_id` IS NULL
GROUP BY `tbl_courseapply`.`stu_id`
ORDER BY `tbl_student`.`stu_id` ASC
ERROR - 2018-11-04 15:27:40 --> Query error: Unknown column 'tbl_courseapply.stu_id' in 'on clause' - Invalid query: SELECT `tbl_student`.*, `tbl_batch`.`batch_title`, `tbl_batch`.`batch_id`
FROM `tbl_attendance`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
GROUP BY `tbl_courseapply`.`stu_id`
ORDER BY `tbl_student`.`stu_id` ASC
ERROR - 2018-11-04 15:28:04 --> Query error: Unknown column 'tbl_courseapply.stu_id' in 'on clause' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_attendance`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
GROUP BY `tbl_courseapply`.`stu_id`
ORDER BY `tbl_student`.`stu_id` ASC
ERROR - 2018-11-04 15:28:11 --> Query error: Unknown column 'tbl_courseapply.stu_id' in 'on clause' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_attendance`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
GROUP BY `tbl_courseapply`.`stu_id`
ORDER BY `tbl_student`.`stu_id` ASC
ERROR - 2018-11-04 15:28:19 --> Query error: Unknown column 'tbl_courseapply.stu_id' in 'on clause' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_attendance`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
ORDER BY `tbl_student`.`stu_id` ASC
ERROR - 2018-11-04 15:31:44 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\attendance_record.php 37
ERROR - 2018-11-04 15:31:44 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\attendance_record.php 37
ERROR - 2018-11-04 15:31:44 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\attendance_record.php 37
ERROR - 2018-11-04 15:31:44 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\attendance_record.php 37
ERROR - 2018-11-04 15:31:44 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\attendance_record.php 37
ERROR - 2018-11-04 15:33:53 --> Query error: Unknown column 'tbl_attendance.batch_i' in 'group statement' - Invalid query: SELECT `tbl_student`.`stu_id`, `tbl_student`.`stu_name`, `tbl_attendance`.`att_date`, `tbl_attendance`.`att_status`, `tbl_attendance`.`att_id`
FROM `tbl_attendance`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_attendance`.`stu_id`
GROUP BY `tbl_attendance`.`stu_id`, `tbl_attendance`.`att_date`, `tbl_attendance`.`batch_i`
ORDER BY `tbl_student`.`stu_id` ASC
ERROR - 2018-11-04 15:38:45 --> Query error: Column 'att_date' cannot be null - Invalid query: INSERT INTO `tbl_attendance` (`stu_id`, `batch_id`, `att_date`, `att_status`) VALUES ('19', '3', NULL, 'present')
ERROR - 2018-11-04 15:39:43 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\attendance_record.php 6
ERROR - 2018-11-04 15:40:09 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\attendance_record.php 6
ERROR - 2018-11-04 15:40:10 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\attendance_record.php 6
ERROR - 2018-11-04 15:40:10 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\attendance_record.php 6
ERROR - 2018-11-04 15:40:10 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\attendance_record.php 6
ERROR - 2018-11-04 15:40:11 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\attendance_record.php 6
ERROR - 2018-11-04 15:40:11 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\attendance_record.php 6
ERROR - 2018-11-04 15:43:24 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Batch.php 101
ERROR - 2018-11-04 15:46:11 --> Severity: Notice --> Undefined variable: all_edit_routine C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:46:11 --> Severity: Notice --> Undefined variable: all_edit_routine C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:46:11 --> Severity: Notice --> Undefined variable: all_edit_routine C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:46:11 --> Severity: Notice --> Undefined variable: all_edit_routine C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:46:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:47:38 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\back\sms_alert.php 6
ERROR - 2018-11-04 15:47:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\sms_alert.php 6
ERROR - 2018-11-04 15:49:36 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:37 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:37 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:51 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:51 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:53 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:53 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:54 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:49:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\sms_alert.php 15
ERROR - 2018-11-04 15:56:28 --> Query error: Unknown column 'tbl_courseapply.batch_id' in 'on clause' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_student`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
JOIN `tbl_courseapply` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
WHERE `tbl_courseapply`.`batch_id` = '3'
ERROR - 2018-11-04 15:56:54 --> Query error: Unknown column 'tbl_courseapply.batch_id' in 'on clause' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_student`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
JOIN `tbl_courseapply` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
WHERE `tbl_courseapply`.`batch_id` = '3'
ERROR - 2018-11-04 16:04:36 --> Severity: error --> Exception: syntax error, unexpected '' students'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampp\htdocs\training\application\controllers\Batch.php 142
ERROR - 2018-11-04 16:04:51 --> Severity: error --> Exception: syntax error, unexpected '' students'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampp\htdocs\training\application\controllers\Batch.php 142
ERROR - 2018-11-04 16:04:52 --> Severity: error --> Exception: syntax error, unexpected '' students'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampp\htdocs\training\application\controllers\Batch.php 142
ERROR - 2018-11-04 16:04:52 --> Severity: error --> Exception: syntax error, unexpected '' students'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampp\htdocs\training\application\controllers\Batch.php 142
ERROR - 2018-11-04 16:04:52 --> Severity: error --> Exception: syntax error, unexpected '' students'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ')' C:\xampp\htdocs\training\application\controllers\Batch.php 142
ERROR - 2018-11-04 17:43:55 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\report.php 41
ERROR - 2018-11-04 17:43:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\report.php 41
ERROR - 2018-11-04 17:44:43 --> Severity: Notice --> Undefined variable: batchs C:\xampp\htdocs\training\application\views\back\report.php 41
ERROR - 2018-11-04 17:44:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\report.php 41
ERROR - 2018-11-04 21:07:50 --> 404 Page Not Found: Courseapp/index
ERROR - 2018-11-04 21:07:58 --> 404 Page Not Found: Dashboardphp/index
ERROR - 2018-11-04 21:14:11 --> Severity: Compile Error --> Cannot redeclare Report::student_list_batch() C:\xampp\htdocs\training\application\controllers\Report.php 53
ERROR - 2018-11-04 21:19:50 --> Severity: Compile Error --> Cannot redeclare Report::student_list_batch() C:\xampp\htdocs\training\application\controllers\Report.php 68
ERROR - 2018-11-04 21:33:07 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 77
ERROR - 2018-11-04 21:33:07 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 82
ERROR - 2018-11-04 21:33:07 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 77
ERROR - 2018-11-04 21:33:07 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 82
ERROR - 2018-11-04 21:33:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 77
ERROR - 2018-11-04 21:33:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 82
ERROR - 2018-11-04 21:33:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 77
ERROR - 2018-11-04 21:33:56 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 82
ERROR - 2018-11-04 21:34:05 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 81
ERROR - 2018-11-04 21:34:05 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Report.php 81
ERROR - 2018-11-04 21:40:25 --> Severity: Notice --> Undefined variable: starting_date C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 21
ERROR - 2018-11-04 21:40:25 --> Severity: Notice --> Undefined variable: ending_date C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 21
ERROR - 2018-11-04 21:40:25 --> Severity: Notice --> Undefined variable: starting_date C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 21
ERROR - 2018-11-04 21:40:25 --> Severity: Notice --> Undefined variable: ending_date C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 21
ERROR - 2018-11-04 21:42:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 20
ERROR - 2018-11-04 21:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 20
ERROR - 2018-11-04 21:42:21 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 20
ERROR - 2018-11-04 21:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 20
ERROR - 2018-11-04 21:42:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 20
ERROR - 2018-11-04 21:42:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 20
ERROR - 2018-11-04 21:42:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 20
ERROR - 2018-11-04 21:42:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 20
ERROR - 2018-11-04 22:54:44 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Report.php 125
ERROR - 2018-11-04 22:54:44 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 20
ERROR - 2018-11-04 22:54:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 20
ERROR - 2018-11-04 22:54:45 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Report.php 125
ERROR - 2018-11-04 22:54:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 20
ERROR - 2018-11-04 22:54:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_course.php 20
