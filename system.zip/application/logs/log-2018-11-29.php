<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-29 01:42:10 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 01:42:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 01:43:18 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 01:43:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 01:43:44 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 01:43:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 01:43:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 01:43:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:03:55 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:03:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:15:21 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:15:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:16:26 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:16:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:16:49 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:16:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:17:01 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:17:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:17:11 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:17:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:21:36 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:21:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:21:39 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:21:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:21:51 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:21:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:18 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:19 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:51 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:56 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:58 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:25:54 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:25:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 43
ERROR - 2018-11-29 02:29:22 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-29 02:29:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\lib\header.php 47
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 04:59:32 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 04:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 04:59:33 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 04:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 04:59:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 04:59:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 04:59:59 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 40
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 41
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 42
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 50
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 51
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\header.php 64
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 45
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 46
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 47
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 48
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 65
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 66
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Undefined variable: sites C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 05:00:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 67
ERROR - 2018-11-29 05:00:12 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:12 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:32 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:33 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:00:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 00:01:33 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 36
ERROR - 2018-11-29 00:01:48 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\training\application\controllers\Error404.php 34
ERROR - 2018-11-29 00:01:49 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\training\application\controllers\Error404.php 34
ERROR - 2018-11-29 00:01:55 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\training\application\controllers\Error404.php 31
ERROR - 2018-11-29 00:02:32 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\training\application\controllers\Error404.php 23
ERROR - 2018-11-29 00:02:33 --> Severity: error --> Exception: syntax error, unexpected ';' C:\xampp\htdocs\training\application\controllers\Error404.php 23
ERROR - 2018-11-29 00:02:45 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 31
ERROR - 2018-11-29 00:02:59 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 31
ERROR - 2018-11-29 00:03:37 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 30
ERROR - 2018-11-29 00:03:38 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 30
ERROR - 2018-11-29 00:03:38 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 30
ERROR - 2018-11-29 00:04:37 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 31
ERROR - 2018-11-29 00:04:47 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 31
ERROR - 2018-11-29 00:04:48 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\training\application\controllers\Error404.php 31
ERROR - 2018-11-29 05:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Error404.php 21
ERROR - 2018-11-29 05:05:27 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:27 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:50 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:51 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:55 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:57 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:57 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:05:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:00 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:00 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:01 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:13 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:13 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:23 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:23 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:24 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:45 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:45 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
ERROR - 2018-11-29 05:06:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\lib\footer.php 10
