<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-29 00:07:06 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-29 00:07:06 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-29 00:07:06 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-29 00:07:06 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-29 00:08:55 --> Severity: Notice --> Undefined variable: account_description C:\xampp\htdocs\training\application\models\Accountmodel.php 33
ERROR - 2018-10-29 00:08:55 --> Severity: Notice --> Undefined variable: acc_cat_id C:\xampp\htdocs\training\application\models\Accountmodel.php 34
ERROR - 2018-10-29 00:08:55 --> Severity: Notice --> Undefined variable: account_cash_in C:\xampp\htdocs\training\application\models\Accountmodel.php 35
ERROR - 2018-10-29 00:08:55 --> Severity: Notice --> Undefined variable: account_cash_out C:\xampp\htdocs\training\application\models\Accountmodel.php 36
ERROR - 2018-10-29 00:31:16 --> Severity: error --> Exception: Too few arguments to function Accountmodel::update_account(), 0 passed in C:\xampp\htdocs\training\application\controllers\Account.php on line 66 and exactly 1 expected C:\xampp\htdocs\training\application\models\Accountmodel.php 30
ERROR - 2018-10-29 00:32:03 --> Severity: error --> Exception: Too few arguments to function Accountmodel::update_account(), 0 passed in C:\xampp\htdocs\training\application\controllers\Account.php on line 66 and exactly 1 expected C:\xampp\htdocs\training\application\models\Accountmodel.php 30
ERROR - 2018-10-29 00:32:17 --> Severity: error --> Exception: Too few arguments to function Accountmodel::update_account(), 0 passed in C:\xampp\htdocs\training\application\controllers\Account.php on line 66 and exactly 1 expected C:\xampp\htdocs\training\application\models\Accountmodel.php 30
ERROR - 2018-10-29 00:37:03 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-29 00:37:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-29 00:37:50 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-29 00:37:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\account_category_list.php 40
ERROR - 2018-10-29 00:46:47 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\training\application\views\back\account_list.php 82
ERROR - 2018-10-29 01:02:14 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\training\application\views\back\account_list.php 154
ERROR - 2018-10-29 01:02:55 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\training\application\views\back\account_list.php 154
ERROR - 2018-10-29 01:03:05 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\training\application\views\back\account_list.php 154
ERROR - 2018-10-29 01:03:29 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\training\application\views\back\account_list.php 154
ERROR - 2018-10-29 01:03:48 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\training\application\views\back\account_list.php 154
ERROR - 2018-10-29 01:03:54 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\training\application\views\back\account_list.php 154
ERROR - 2018-10-29 01:04:05 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\training\application\views\back\account_list.php 156
ERROR - 2018-10-29 01:08:16 --> Severity: error --> Exception: syntax error, unexpected '}' C:\xampp\htdocs\training\application\views\back\account_list.php 159
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 01:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 01:16:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 01:17:43 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-10-29 01:18:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-29 01:18:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-29 01:18:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-29 01:18:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-29 01:18:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-29 01:18:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-29 01:18:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-29 01:18:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-29 01:18:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-29 01:18:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-10-29 01:18:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-29 01:18:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-29 01:18:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-29 01:18:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-10-29 01:18:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-29 01:18:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-10-29 02:01:16 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\training\application\views\back\account_list.php 127
ERROR - 2018-10-29 02:01:18 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\training\application\views\back\account_list.php 127
ERROR - 2018-10-29 02:01:20 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\training\application\views\back\account_list.php 127
ERROR - 2018-10-29 02:01:21 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\training\application\views\back\account_list.php 127
ERROR - 2018-10-29 02:01:25 --> Severity: error --> Exception: syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\training\application\views\back\account_list.php 127
ERROR - 2018-10-29 02:13:06 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\account_list.php 57
ERROR - 2018-10-29 02:13:06 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\account_list.php 57
ERROR - 2018-10-29 02:14:29 --> Severity: error --> Exception: syntax error, unexpected '?' C:\xampp\htdocs\training\application\views\back\account_list.php 38
ERROR - 2018-10-29 02:16:28 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:16:28 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:05 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:05 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:05 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:30 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:30 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:30 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:41 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:41 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:17:41 --> Severity: Warning --> date_format() expects parameter 1 to be DateTimeInterface, string given C:\xampp\htdocs\training\application\views\back\account_list.php 39
ERROR - 2018-10-29 02:18:14 --> Severity: Notice --> Undefined property: stdClass::$acc_cat_name C:\xampp\htdocs\training\application\views\back\account_list.php 40
ERROR - 2018-10-29 02:18:14 --> Severity: Notice --> Undefined property: stdClass::$acc_cat_name C:\xampp\htdocs\training\application\views\back\account_list.php 40
ERROR - 2018-10-29 02:18:14 --> Severity: Notice --> Undefined property: stdClass::$acc_cat_name C:\xampp\htdocs\training\application\views\back\account_list.php 40
ERROR - 2018-10-29 02:39:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-10-29 02:39:15', '', '')
ERROR - 2018-10-29 02:39:15 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-10-29 02:39:15', '', '')
ERROR - 2018-10-29 02:39:22 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-10-29 02:39:22', '', '')
ERROR - 2018-10-29 02:40:20 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: UPDATE `tbl_account` SET `account_description` = '', `acc_cat_id` = '', `account_cash_in` = '1500.00', `account_cash_out` = '1250.00'
WHERE `account_id` = '47'
ERROR - 2018-10-29 02:41:16 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: UPDATE `tbl_account` SET `account_description` = '', `acc_cat_id` = '', `account_cash_in` = '1600', `account_cash_out` = '1250.00'
WHERE `account_id` = '47'
ERROR - 2018-10-29 02:44:21 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: INSERT INTO `tbl_account` (`acc_cat_id`, `account_description`, `account_date`, `account_cash_in`, `account_cash_out`) VALUES ('', '', '2018-10-29 02:44:21', '', '')
ERROR - 2018-10-29 02:48:42 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: UPDATE `tbl_account` SET `account_description` = '', `acc_cat_id` = '', `account_cash_in` = '1504', `account_cash_out` = '1254'
WHERE `account_id` = '47'
ERROR - 2018-10-29 03:02:31 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: UPDATE `tbl_account` SET `account_description` = 'Rent Fee', `acc_cat_id` = '', `account_cash_in` = '1500.00', `account_cash_out` = '1250.00'
WHERE `account_id` = '47'
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:03:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:04:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:04:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:04:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:04:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:04:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:04:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:04:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:04:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:05:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:05:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:05:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:05:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:05:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:05:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:05:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:05:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 03:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-10-29 13:36:21 --> Query error: Column 'stu_sex' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_present_address`, `stu_permanent_address`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-29 13:44:04 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Publiccontroller.php 69
ERROR - 2018-10-29 14:22:59 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Publiccontroller.php 72
ERROR - 2018-10-29 14:36:16 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Publiccontroller.php 72
ERROR - 2018-10-29 14:39:09 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Publiccontroller.php 74
ERROR - 2018-10-29 14:39:09 --> Query error: Column 'stu_have_experience' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_present_address`, `stu_permanent_address`, `stu_have_experience`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES ('', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '')
ERROR - 2018-10-29 14:41:05 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Publiccontroller.php 74
ERROR - 2018-10-29 14:42:02 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Publiccontroller.php 74
ERROR - 2018-10-29 14:42:02 --> Query error: Column 'stu_have_experience' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_present_address`, `stu_permanent_address`, `stu_have_experience`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES ('dfgdfhgh', '525654', 'Female', 'Hindu', 'Unmarried', '56465152454564', 'student', NULL, '', '', '', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', '', '')
ERROR - 2018-10-29 15:00:54 --> Severity: Notice --> Undefined index: confirmations C:\xampp\htdocs\training\application\controllers\Publiccontroller.php 127
ERROR - 2018-10-29 15:28:29 --> Query error: Column 'stu_have_experience' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_password`, `stu_present_address`, `stu_permanent_address`, `stu_have_experience`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES ('Shamim', '2018-10-10', 'Male', 'Islam', 'Unmarried', '1256666', 'Student', NULL, 'Iman Ali', 'Somla Begum', 'SHarif', 'Brother', '0155555555', '01738298666', 'shamim@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', 'Savar', 'Ghatail', NULL, '', '', '', '', '', '', '', '', '')
ERROR - 2018-10-29 18:02:40 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\xampp\htdocs\training\application\views\back\students_archive.php 34
ERROR - 2018-10-29 18:02:40 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\training\application\views\back\students_archive.php 36
ERROR - 2018-10-29 18:02:40 --> Severity: Notice --> Undefined property: stdClass::$mobile C:\xampp\htdocs\training\application\views\back\students_archive.php 34
ERROR - 2018-10-29 18:02:40 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\training\application\views\back\students_archive.php 36
ERROR - 2018-10-29 18:23:49 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:49 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:49 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:49 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(top_menu.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'top_menu.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 54
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(footer.php): failed to open stream: No such file or directory C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:23:50 --> Severity: Warning --> include(): Failed opening 'footer.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\training\application\views\back\view_students_archive.php 266
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:49:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:49:58 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:49:59 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:50:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:50:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:50:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:50:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:50:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:50:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:50:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:50:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:51:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:51:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:51:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:52:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:52:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-10-29 18:52:52 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 79
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 91
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 103
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 115
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 118
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Undefined variable: view_students_archive C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 18:52:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 228
ERROR - 2018-10-29 19:04:21 --> Severity: error --> Exception: Call to undefined method Studentsarchive::where() C:\xampp\htdocs\training\application\controllers\Studentsarchive.php 45
ERROR - 2018-10-29 19:04:23 --> Severity: error --> Exception: Call to undefined method Studentsarchive::where() C:\xampp\htdocs\training\application\controllers\Studentsarchive.php 45
ERROR - 2018-10-29 19:04:53 --> Severity: error --> Exception: Call to undefined method Studentsarchive::where() C:\xampp\htdocs\training\application\controllers\Studentsarchive.php 45
ERROR - 2018-10-29 19:08:53 --> Query error: Column 'stu_have_experience' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_password`, `stu_present_address`, `stu_permanent_address`, `stu_have_experience`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES ('', '', '', '', '', '', '', NULL, '', '', '', '', '', '', '', 'd41d8cd98f00b204e9800998ecf8427e', '', '', NULL, '', '', '', '', '', '', '', '', '')
