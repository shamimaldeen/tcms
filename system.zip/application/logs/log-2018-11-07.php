<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-07 00:42:41 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Student.php 81
ERROR - 2018-11-07 00:48:56 --> Severity: error --> Exception: Call to undefined function format_date() C:\xampp\htdocs\training\application\views\student\dashboard.php 175
ERROR - 2018-11-07 03:27:27 --> Query error: Unknown column 'pay_fee' in 'field list' - Invalid query: INSERT INTO `tbl_payment` (`stu_id`, `pay_fee`, `pay_tra_id`, `pay_method`, `pay_date`) VALUES (NULL, NULL, NULL, NULL, '2018-11-07 03:27:27')
ERROR - 2018-11-07 03:48:41 --> Query error: Unknown column 'apay_paidamount' in 'field list' - Invalid query: INSERT INTO `tbl_admin_payment` (`stu_id`, `apay_paidamount`, `apay_method`, `apay_tra_id`, `pay_date`) VALUES ('25', '500', 'Bkash', '66666666666666', '2018-11-07 03:48:41')
ERROR - 2018-11-07 03:49:25 --> Query error: Unknown column 'pay_date' in 'field list' - Invalid query: INSERT INTO `tbl_admin_payment` (`stu_id`, `apay_fee`, `apay_method`, `apay_tra_id`, `pay_date`) VALUES ('25', '566', 'Bkash', '54646', '2018-11-07 03:49:25')
