<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-23 00:19:44 --> 404 Page Not Found: Employee/add_notice
ERROR - 2018-10-23 00:44:15 --> 404 Page Not Found: Notice/notice_list
ERROR - 2018-10-23 00:48:44 --> Severity: Notice --> Undefined variable: notices C:\xampp\htdocs\hrms\application\controllers\Notice.php 60
ERROR - 2018-10-23 00:50:05 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\notice_list.php 64
ERROR - 2018-10-23 00:50:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\notice_list.php 64
ERROR - 2018-10-23 02:24:46 --> 404 Page Not Found: Notice/edit_notice
ERROR - 2018-10-23 02:28:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\hrms\application\controllers\Notice.php 164
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 35
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 35
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 46
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 46
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 55
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 55
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 64
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 64
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 72
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 72
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 90
ERROR - 2018-10-23 02:38:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 90
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 35
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 35
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 46
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 46
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 55
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 55
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 64
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 64
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 72
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 72
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Undefined variable: notice C:\xampp\htdocs\hrms\application\views\edit_notice.php 90
ERROR - 2018-10-23 02:38:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\edit_notice.php 90
ERROR - 2018-10-23 02:58:15 --> Severity: error --> Exception: syntax error, unexpected '?>', expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\hrms\application\controllers\Notice.php 245
ERROR - 2018-10-23 03:11:24 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\hrms\application\controllers\Notice.php 183
ERROR - 2018-10-23 03:23:38 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\hrms\application\controllers\Notice.php 186
ERROR - 2018-10-23 03:23:38 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\hrms\application\controllers\Notice.php 186
ERROR - 2018-10-23 12:34:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:34:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:34:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:34:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:34:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:34:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:34:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:34:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:34:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 12:35:11 --> 404 Page Not Found: Uploads/favicon.PNG
ERROR - 2018-10-23 12:36:57 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\hrms\application\controllers\Notice.php 186
ERROR - 2018-10-23 12:36:57 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\hrms\application\controllers\Notice.php 186
ERROR - 2018-10-23 12:40:10 --> Severity: Notice --> Undefined variable: filename C:\xampp\htdocs\hrms\application\controllers\Notice.php 186
ERROR - 2018-10-23 12:40:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\hrms\application\controllers\Notice.php 186
ERROR - 2018-10-23 13:43:17 --> Severity: error --> Exception: Call to undefined method Trainingmodel::designation_info() C:\xampp\htdocs\hrms\application\controllers\Training.php 25
ERROR - 2018-10-23 14:08:20 --> Severity: Notice --> Undefined variable: employees C:\xampp\htdocs\hrms\application\views\add_training.php 54
ERROR - 2018-10-23 14:08:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_training.php 54
ERROR - 2018-10-23 14:11:45 --> Severity: Notice --> Undefined variable: employees C:\xampp\htdocs\hrms\application\views\add_training.php 54
ERROR - 2018-10-23 14:11:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_training.php 54
ERROR - 2018-10-23 14:13:28 --> Severity: Notice --> Undefined variable: employees C:\xampp\htdocs\hrms\application\views\add_training.php 54
ERROR - 2018-10-23 14:13:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_training.php 54
ERROR - 2018-10-23 14:14:38 --> Severity: Notice --> Undefined variable: employees C:\xampp\htdocs\hrms\application\views\add_training.php 54
ERROR - 2018-10-23 14:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_training.php 54
ERROR - 2018-10-23 14:15:47 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\hrms\application\views\add_training.php 55
ERROR - 2018-10-23 14:16:52 --> 404 Page Not Found: Notice/save_training
ERROR - 2018-10-23 14:22:53 --> 404 Page Not Found: Notice/save_training
ERROR - 2018-10-23 14:24:39 --> 404 Page Not Found: Notice/save_training
ERROR - 2018-10-23 14:25:57 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\hrms\application\views\add_training.php 55
ERROR - 2018-10-23 16:47:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 16:47:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2018-10-23 16:47:56 --> Severity: Notice --> Undefined index: employees C:\xampp\htdocs\hrms\application\controllers\Training.php 78
ERROR - 2018-10-23 17:00:06 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:00:06 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:00:06 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:04:14 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:07:46 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:07:46 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:07:46 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:08:59 --> Severity: Notice --> Undefined variable: Employees C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:08:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:08:59 --> Severity: Notice --> Undefined variable: Employees C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:08:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:08:59 --> Severity: Notice --> Undefined variable: Employees C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:08:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:09:01 --> Severity: Notice --> Undefined variable: Employees C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:09:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:09:01 --> Severity: Notice --> Undefined variable: Employees C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:09:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:09:01 --> Severity: Notice --> Undefined variable: Employees C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:09:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:10:20 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:10:20 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:10:20 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:10:22 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:10:22 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:10:22 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:11:03 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:11:03 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:11:03 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:14:01 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:14:01 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:14:01 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:15:03 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:15:03 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:15:03 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:15:05 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:15:05 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:15:05 --> Severity: Notice --> Undefined property: stdClass::$emp_name C:\xampp\htdocs\hrms\application\views\training_list.php 72
ERROR - 2018-10-23 17:45:05 --> 404 Page Not Found: Training/edit_training
ERROR - 2018-10-23 17:47:02 --> Severity: Notice --> Undefined variable: employees C:\xampp\htdocs\hrms\application\views\edit_training.php 54
ERROR - 2018-10-23 17:47:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\edit_training.php 54
ERROR - 2018-10-23 18:02:22 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\hrms\application\views\edit_training.php 55
ERROR - 2018-10-23 18:02:24 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\hrms\application\views\edit_training.php 55
ERROR - 2018-10-23 18:02:30 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\xampp\htdocs\hrms\application\views\edit_training.php 55
ERROR - 2018-10-23 18:12:16 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\edit_training.php 56
ERROR - 2018-10-23 18:14:12 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\edit_training.php 56
ERROR - 2018-10-23 18:14:13 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\edit_training.php 56
ERROR - 2018-10-23 18:14:18 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\edit_training.php 56
ERROR - 2018-10-23 18:15:08 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\edit_training.php 56
ERROR - 2018-10-23 18:15:09 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\edit_training.php 56
ERROR - 2018-10-23 18:15:13 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\edit_training.php 56
ERROR - 2018-10-23 18:19:38 --> Severity: error --> Exception: syntax error, unexpected 'endif' (T_ENDIF), expecting end of file C:\xampp\htdocs\hrms\application\views\edit_training.php 56
ERROR - 2018-10-23 18:27:46 --> 404 Page Not Found: Training/update_training
ERROR - 2018-10-23 18:27:53 --> 404 Page Not Found: Training/update_training
ERROR - 2018-10-23 18:47:05 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-23 18:47:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-23 18:47:53 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-23 18:47:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-23 18:47:57 --> Severity: Notice --> Undefined variable: departments C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-23 18:47:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\hrms\application\views\add_employee.php 91
ERROR - 2018-10-23 20:47:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:17 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:18 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:34 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:35 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:36 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:37 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:49:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:50:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:50:00 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:50:07 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:50:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 20:50:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Client C:\xampp\htdocs\hrms\system\core\Loader.php 348
ERROR - 2018-10-23 21:16:20 --> Severity: Notice --> Undefined property: stdClass::$cli_data C:\xampp\htdocs\hrms\application\controllers\Client.php 37
ERROR - 2018-10-23 21:16:21 --> Severity: Notice --> Undefined variable: cli_id C:\xampp\htdocs\hrms\application\controllers\Client.php 74
ERROR - 2018-10-23 21:22:09 --> Severity: Notice --> Undefined property: stdClass::$cli_data C:\xampp\htdocs\hrms\application\controllers\Client.php 37
ERROR - 2018-10-23 21:22:54 --> Query error: Column 'cli_name' cannot be null - Invalid query: INSERT INTO `client` (`cli_name`, `cli_address`, `cli_contact`, `cli_image`) VALUES (NULL, NULL, NULL, NULL)
ERROR - 2018-10-23 21:23:23 --> Severity: Notice --> Undefined property: stdClass::$cli_data C:\xampp\htdocs\hrms\application\controllers\Client.php 37
ERROR - 2018-10-23 21:23:52 --> Severity: Notice --> Undefined property: stdClass::$cli_data C:\xampp\htdocs\hrms\application\controllers\Client.php 37
ERROR - 2018-10-23 21:28:46 --> Severity: Notice --> Undefined property: stdClass::$cli_data C:\xampp\htdocs\hrms\application\controllers\Client.php 37
ERROR - 2018-10-23 21:33:58 --> Severity: Notice --> Undefined variable: cli_id C:\xampp\htdocs\hrms\application\controllers\Client.php 78
ERROR - 2018-10-23 21:36:47 --> Query error: Column 'cli_name' cannot be null - Invalid query: INSERT INTO `client` (`cli_name`, `cli_address`, `cli_contact`, `cli_image`) VALUES (NULL, NULL, NULL, NULL)
ERROR - 2018-10-23 21:58:01 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\xampp\htdocs\hrms\application\models\Clientmodel.php 27
ERROR - 2018-10-23 22:00:37 --> 404 Page Not Found: Imagesjpg/index
ERROR - 2018-10-23 22:00:41 --> 404 Page Not Found: Imagesjpg/index
ERROR - 2018-10-23 22:03:17 --> Severity: error --> Exception: syntax error, unexpected '$client' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\hrms\application\views\client_list.php 77
ERROR - 2018-10-23 22:04:44 --> 404 Page Not Found: Imagesjpg/index
ERROR - 2018-10-23 22:17:10 --> 404 Page Not Found: Training/edit_client
ERROR - 2018-10-23 22:18:20 --> 404 Page Not Found: Training/edit_client
ERROR - 2018-10-23 22:18:29 --> 404 Page Not Found: Training/edit_client
ERROR - 2018-10-23 22:19:20 --> 404 Page Not Found: Training/edit_client
ERROR - 2018-10-23 22:19:34 --> 404 Page Not Found: Training/edit_client
ERROR - 2018-10-23 22:24:01 --> 404 Page Not Found: Client/update_client
ERROR - 2018-10-23 22:39:08 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\xampp\htdocs\hrms\application\models\Clientmodel.php 77
ERROR - 2018-10-23 22:39:35 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\xampp\htdocs\hrms\application\models\Clientmodel.php 77
ERROR - 2018-10-23 22:42:45 --> Severity: error --> Exception: Call to undefined method Noticemodel::delete_client() C:\xampp\htdocs\hrms\application\controllers\Client.php 201
ERROR - 2018-10-23 23:43:45 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\xampp\htdocs\hrms\application\models\Clientmodel.php 27
ERROR - 2018-10-23 23:43:45 --> Query error: Column 'cli_name' cannot be null - Invalid query: INSERT INTO `client` (`cli_name`, `cli_address`, `cli_contact`, `cli_image`, `cli_last_update`) VALUES (NULL, NULL, NULL, NULL, ' 00:00:00')
ERROR - 2018-10-23 23:45:16 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\xampp\htdocs\hrms\application\models\Clientmodel.php 27
ERROR - 2018-10-23 23:45:16 --> Query error: Column 'cli_name' cannot be null - Invalid query: INSERT INTO `client` (`cli_name`, `cli_address`, `cli_contact`, `cli_image`, `cli_last_update`) VALUES (NULL, NULL, NULL, NULL, ' 00:00:00')
ERROR - 2018-10-23 23:47:12 --> Severity: Warning --> date() expects at least 1 parameter, 0 given C:\xampp\htdocs\hrms\application\models\Clientmodel.php 27
ERROR - 2018-10-23 23:47:12 --> Query error: Column 'cli_name' cannot be null - Invalid query: INSERT INTO `client` (`cli_name`, `cli_address`, `cli_contact`, `cli_image`, `cli_last_update`) VALUES (NULL, NULL, NULL, NULL, ' 00:00:00')
