<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-06 13:46:29 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`tcms`.`tbl_admin_payment`, CONSTRAINT `tbl_admin_payment_ibfk_1` FOREIGN KEY (`stu_id`) REFERENCES `tbl_student` (`stu_id`)) - Invalid query: DELETE FROM `tbl_student`
WHERE `stu_id` = '16'
ERROR - 2018-11-06 14:35:45 --> Query error: Unknown column 'tbl_student.stu_id' in 'where clause' - Invalid query: SELECT *
FROM `tbl_courseapply`
JOIN `tbl_payment` ON `tbl_payment`.`stu_id` =  `tbl_student`.`stu_id`
WHERE `tbl_payment`.`pay_status` = 'approved'
AND `tbl_student`.`stu_id` = '19'
ERROR - 2018-11-06 14:37:15 --> Query error: Not unique table/alias: 'tbl_payment' - Invalid query: SELECT *
FROM `tbl_payment`
JOIN `tbl_payment` ON `tbl_payment`.`stu_id` =  `tbl_student`.`stu_id`
WHERE `tbl_payment`.`pay_status` = 'approved'
AND `tbl_student`.`stu_id` = '19'
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:38:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:39:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Undefined variable: certificate C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:42:43 --> Severity: error --> Exception: syntax error, unexpected ']', expecting ',' or ';' C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:43:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:45:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 15:47:29 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`tcms`.`tbl_admin_payment`, CONSTRAINT `tbl_admin_payment_ibfk_1` FOREIGN KEY (`stu_id`) REFERENCES `tbl_student` (`stu_id`)) - Invalid query: DELETE FROM `tbl_student`
WHERE `stu_id` = '16'
ERROR - 2018-11-06 15:48:01 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`tcms`.`tbl_admin_payment`, CONSTRAINT `tbl_admin_payment_ibfk_1` FOREIGN KEY (`stu_id`) REFERENCES `tbl_student` (`stu_id`)) - Invalid query: DELETE FROM `tbl_student`
WHERE `stu_id` = '16'
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:49:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:50:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:51:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 15:51:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:51:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 15:51:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:51:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 15:51:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:51:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 15:51:26 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:51:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 15:52:34 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-06 15:53:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-06 15:53:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-06 15:58:36 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_account`, CONSTRAINT `tbl_account_ibfk_1` FOREIGN KEY (`acc_cat_id`) REFERENCES `tbl_account_category` (`acc_cat_id`)) - Invalid query: UPDATE `tbl_account` SET `account_description` = 'iiiiiiiiii', `acc_cat_id` = '', `account_cash_in` = '1444.00', `account_cash_out` = '25555.00'
WHERE `account_id` = '56'
ERROR - 2018-11-06 16:07:15 --> Severity: Notice --> Undefined index: stu_id C:\xampp\htdocs\training\application\controllers\Attendance.php 87
ERROR - 2018-11-06 16:07:42 --> Severity: Notice --> Undefined index: stu_id C:\xampp\htdocs\training\application\controllers\Attendance.php 87
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 16:44:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 81
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 81
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 93
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 93
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 96
ERROR - 2018-11-06 17:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 96
ERROR - 2018-11-06 17:45:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 222
ERROR - 2018-11-06 17:45:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 222
ERROR - 2018-11-06 17:45:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 227
ERROR - 2018-11-06 17:45:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 227
ERROR - 2018-11-06 17:45:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-11-06 17:45:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-11-06 17:45:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-11-06 17:45:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-11-06 17:45:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-11-06 17:45:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-11-06 17:45:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-11-06 17:45:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 81
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 81
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 93
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 93
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 96
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 96
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 222
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 222
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 227
ERROR - 2018-11-06 17:45:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 227
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 55
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 58
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 62
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 67
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 70
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 73
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 81
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 81
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 93
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 93
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 96
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 96
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 222
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 222
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\view_students_archive.php 227
ERROR - 2018-11-06 17:45:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\view_students_archive.php 227
ERROR - 2018-11-06 17:48:22 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\training\system\libraries\Session\drivers\Session_files_driver.php 212
ERROR - 2018-11-06 17:48:22 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2018-11-06 17:48:22 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\htdocs\training\system\cache) Unknown 0
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 17:50:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-06 17:53:57 --> Severity: Notice --> Undefined variable: batch_title C:\xampp\htdocs\training\application\models\Batchmodel.php 35
ERROR - 2018-11-06 23:14:31 --> Severity: Notice --> Undefined variable: running_courses C:\xampp\htdocs\training\application\views\student\dashboard.php 72
ERROR - 2018-11-06 23:14:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\student\dashboard.php 72
ERROR - 2018-11-06 23:17:24 --> Severity: Notice --> Undefined variable: running_courses C:\xampp\htdocs\training\application\views\student\dashboard.php 72
ERROR - 2018-11-06 23:17:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\student\dashboard.php 72
ERROR - 2018-11-06 23:22:49 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Student.php 44
ERROR - 2018-11-06 23:23:04 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Student.php 44
ERROR - 2018-11-06 23:24:09 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Student.php 57
ERROR - 2018-11-06 23:24:09 --> Query error: Column 'stu_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `stu_id` = '25'
AND `tbl_payment`.`pay_status` = 'approved'
AND `tbl_courseapply`.`capply_status` = 'Incomplete'
AND `tbl_courseapply`.`stu_id` IS NULL
ERROR - 2018-11-06 23:31:07 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Student.php 57
ERROR - 2018-11-06 23:31:07 --> Query error: Column 'stu_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `stu_id` = '25'
AND `tbl_payment`.`pay_status` = 'approved'
AND `tbl_courseapply`.`capply_status` = 'Incomplete'
AND `tbl_courseapply`.`stu_id` IS NULL
ERROR - 2018-11-06 23:31:10 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Student.php 57
ERROR - 2018-11-06 23:31:10 --> Query error: Column 'stu_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `stu_id` = '25'
AND `tbl_payment`.`pay_status` = 'approved'
AND `tbl_courseapply`.`capply_status` = 'Incomplete'
AND `tbl_courseapply`.`stu_id` IS NULL
ERROR - 2018-11-06 18:32:19 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\training\application\controllers\Student.php 58
ERROR - 2018-11-06 18:32:24 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\training\application\controllers\Student.php 57
ERROR - 2018-11-06 18:32:25 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\training\application\controllers\Student.php 57
ERROR - 2018-11-06 18:32:26 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\training\application\controllers\Student.php 57
ERROR - 2018-11-06 23:32:40 --> Query error: Column 'stu_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `stu_id` = '25'
AND `tbl_payment`.`pay_status` = 'approved'
AND `tbl_courseapply`.`capply_status` = 'Incomplete'
AND `tbl_courseapply`.`stu_id` = '25'
ERROR - 2018-11-06 23:33:19 --> Query error: Column 'stu_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `stu_id` = '25'
AND `tbl_payment`.`pay_status` = 'approved'
AND `tbl_courseapply`.`capply_status` = 'Incomplete'
AND `tbl_courseapply`.`stu_id` = '25'
ERROR - 2018-11-06 18:34:33 --> Severity: error --> Exception: syntax error, unexpected ')', expecting ']' C:\xampp\htdocs\training\application\controllers\Student.php 62
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:53:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 18:59:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 92
ERROR - 2018-11-06 19:00:32 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:00:32 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:32 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:48 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:00:58 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:01:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:01 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:03 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 100
ERROR - 2018-11-06 19:01:28 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\certificate\certificate.php 6
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 15
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 23
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-06 19:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_routine.php 35
ERROR - 2018-11-06 19:24:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:24:58 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:24:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:25:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:25:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:25:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:25:34 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:25:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:25:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:25:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:25:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:25:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:25:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:25:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:25:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:25:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 19
ERROR - 2018-11-06 19:25:52 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\add_notice.php 30
ERROR - 2018-11-06 19:25:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\add_notice.php 30
