<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-10 20:34:59 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\training\system\libraries\Session\drivers\Session_files_driver.php 212
ERROR - 2018-11-10 20:34:59 --> Severity: Warning --> Unknown: Cannot call session save handler in a recursive manner Unknown 0
ERROR - 2018-11-10 20:34:59 --> Severity: Warning --> Unknown: Failed to write session data using user defined save handler. (session.save_path: C:\xampp\htdocs\training\system\cache) Unknown 0
