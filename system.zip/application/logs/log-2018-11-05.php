<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-05 00:03:50 --> Query error: Not unique table/alias: 'tbl_course' - Invalid query: SELECT *
FROM `tbl_course`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `tbl_courseapply`.`course_id` = '3'
AND `course_id` = '3'
ERROR - 2018-11-05 00:06:11 --> Query error: Not unique table/alias: 'tbl_course' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_course`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `tbl_courseapply`.`course_id` = '3'
AND `course_id` = '3'
ERROR - 2018-11-05 00:07:22 --> Query error: Not unique table/alias: 'tbl_course' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_course`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `tbl_courseapply`.`course_id` = '3'
AND `course_id` = '3'
ERROR - 2018-11-05 00:10:40 --> Query error: Unknown column 'tbl_course' in 'field list' - Invalid query: SELECT `tbl_course`
FROM `tbl_course`
WHERE `course_id` = '3'
ERROR - 2018-11-05 00:10:48 --> Query error: Unknown column 'tbl_course' in 'field list' - Invalid query: SELECT `tbl_course`
FROM `tbl_course`
WHERE `course_id` = '2'
ERROR - 2018-11-05 00:40:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 28
ERROR - 2018-11-05 00:40:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 28
ERROR - 2018-11-05 00:40:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 28
ERROR - 2018-11-05 00:40:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 28
ERROR - 2018-11-05 00:40:19 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 28
ERROR - 2018-11-05 00:40:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\students_list_batch.php 28
ERROR - 2018-11-05 00:55:16 --> Severity: error --> Exception: C:\xampp\htdocs\training\application\models/Paymentmodel.php exists, but doesn't declare class Paymentmodel C:\xampp\htdocs\training\system\core\Loader.php 340
ERROR - 2018-11-05 00:55:21 --> Severity: error --> Exception: C:\xampp\htdocs\training\application\models/Paymentmodel.php exists, but doesn't declare class Paymentmodel C:\xampp\htdocs\training\system\core\Loader.php 340
ERROR - 2018-11-05 00:55:22 --> Severity: error --> Exception: C:\xampp\htdocs\training\application\models/Paymentmodel.php exists, but doesn't declare class Paymentmodel C:\xampp\htdocs\training\system\core\Loader.php 340
ERROR - 2018-11-05 00:55:23 --> Severity: error --> Exception: C:\xampp\htdocs\training\application\models/Paymentmodel.php exists, but doesn't declare class Paymentmodel C:\xampp\htdocs\training\system\core\Loader.php 340
ERROR - 2018-11-05 11:02:57 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`tcms`.`tbl_admin_payment`, CONSTRAINT `tbl_admin_payment_ibfk_1` FOREIGN KEY (`stu_id`) REFERENCES `tbl_student` (`stu_id`)) - Invalid query: INSERT INTO `tbl_admin_payment` (`stu_id`, `apay_fee`, `apay_method`, `apay_date`) VALUES ('15', '500', 'Rocket', '2018-11-05 11:02:57')
ERROR - 2018-11-05 11:30:09 --> Severity: Notice --> Undefined variable: apay_id C:\xampp\htdocs\training\application\controllers\Payment.php 49
ERROR - 2018-11-05 11:30:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\training\application\controllers\Payment.php 49
ERROR - 2018-11-05 11:31:00 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\training\application\controllers\Payment.php 49
ERROR - 2018-11-05 11:53:37 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:53:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:53:43 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:53:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:54:27 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:54:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:54:31 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:54:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:54:59 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:54:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:55:05 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:55:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:56:22 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:56:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:56:28 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:56:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:58:01 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:58:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:58:16 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 11:58:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:00 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:04 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:40 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:43 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:49 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:00:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:01:40 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:01:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:07:45 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:10:53 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:10:56 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:10:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:10:59 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:10:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:11:01 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:11:20 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:11:23 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:11:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:13:13 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:13:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:13:18 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:13:18 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:15:56 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:15:56 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:17:54 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:17:54 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:17:56 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:17:56 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:22:09 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:22:09 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:22:12 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:22:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:22:19 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:22:19 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:23:10 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:23:10 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:23:38 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:23:38 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:23:43 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:23:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:27:24 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:27:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 12:27:27 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:27:27 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:49:47 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 12:49:47 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\payment_pending.php 36
ERROR - 2018-11-05 13:19:41 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:19:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:22:48 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:22:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:22:52 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:22:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:23:02 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:23:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:23:25 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:23:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:34:38 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:34:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:34:40 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:35:43 --> Severity: error --> Exception: syntax error, unexpected '}', expecting end of file C:\xampp\htdocs\training\application\views\back\payment.php 49
ERROR - 2018-11-05 13:36:12 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:36:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:38:20 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 13:38:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\payment.php 38
ERROR - 2018-11-05 14:00:14 --> Severity: Compile Error --> Cannot redeclare Inquiry::inquiry() C:\xampp\htdocs\training\application\controllers\Inquiry.php 41
ERROR - 2018-11-05 17:06:51 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\reports\new_application_list.php 7
ERROR - 2018-11-05 18:01:16 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:01:16 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:32 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:32 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:33 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:33 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:34 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:34 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:34 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:34 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:04:35 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 21
ERROR - 2018-11-05 18:05:42 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 29
ERROR - 2018-11-05 18:05:42 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 29
ERROR - 2018-11-05 18:07:15 --> Severity: Notice --> Undefined property: stdClass::$starting_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 29
ERROR - 2018-11-05 18:07:15 --> Severity: Notice --> Undefined property: stdClass::$ending_date C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 29
ERROR - 2018-11-05 18:32:16 --> Severity: error --> Exception: syntax error, unexpected ''tbl_admin_payment.apay_date >' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Report.php 265
ERROR - 2018-11-05 18:34:50 --> Query error: Not unique table/alias: 'tbl_admin_payment' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_admin_payment`
JOIN `tbl_admin_payment` ON `tbl_admin_payment`.`stu_id` =  `tbl_student`.`stu_id`
ERROR - 2018-11-05 18:35:18 --> Query error: Not unique table/alias: 'tbl_admin_payment' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_admin_payment`
JOIN `tbl_admin_payment` ON `tbl_admin_payment`.`stu_id` =  `tbl_student`.`stu_id`
ERROR - 2018-11-05 18:36:38 --> Query error: Not unique table/alias: 'tbl_admin_payment' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_admin_payment`
JOIN `tbl_admin_payment` ON `tbl_admin_payment`.`stu_id` =  `tbl_student`.`stu_id`
ERROR - 2018-11-05 18:37:42 --> Query error: Unknown table 'tcms.tbl_student' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_admin_payment`
ERROR - 2018-11-05 18:37:49 --> Query error: Unknown table 'tcms.tbl_student' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_admin_payment`
ERROR - 2018-11-05 18:38:16 --> Query error: Unknown table 'tcms.tbl_student' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_admin_payment`
ERROR - 2018-11-05 18:38:24 --> Query error: Not unique table/alias: 'tbl_admin_payment' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_admin_payment`
JOIN `tbl_admin_payment` ON `tbl_admin_payment`.`stu_id` =  `tbl_student`.`stu_id`
ERROR - 2018-11-05 18:38:46 --> Severity: Notice --> Undefined index: applications C:\xampp\htdocs\training\application\controllers\Report.php 272
ERROR - 2018-11-05 18:39:13 --> Query error: Not unique table/alias: 'tbl_admin_payment' - Invalid query: SELECT `tbl_student`.*
FROM `tbl_admin_payment`
JOIN `tbl_admin_payment` ON `tbl_admin_payment`.`stu_id` =  `tbl_student`.`stu_id`
WHERE `tbl_admin_payment`.`apay_status` = 'approved'
AND `tbl_admin_payment`.`apay_date` >= '2018-08-08'
AND `tbl_admin_payment`.`apay_date` <= '2019-03-22'
ERROR - 2018-11-05 18:39:56 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 28
ERROR - 2018-11-05 18:39:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 28
ERROR - 2018-11-05 18:39:56 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 28
ERROR - 2018-11-05 18:39:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 28
ERROR - 2018-11-05 18:39:56 --> Severity: Notice --> Undefined property: stdClass::$apay_fee C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 54
ERROR - 2018-11-05 18:39:56 --> Severity: Notice --> Undefined property: stdClass::$apay_method C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 57
ERROR - 2018-11-05 18:39:56 --> Severity: Notice --> Undefined property: stdClass::$apay_tra_id C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 58
ERROR - 2018-11-05 18:39:56 --> Severity: Notice --> Undefined property: stdClass::$apay_date C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 59
ERROR - 2018-11-05 18:39:56 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 6
ERROR - 2018-11-05 18:40:17 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 28
ERROR - 2018-11-05 18:40:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 28
ERROR - 2018-11-05 18:40:17 --> Severity: Notice --> Undefined variable: apayments C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 28
ERROR - 2018-11-05 18:40:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 28
ERROR - 2018-11-05 18:40:17 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 6
ERROR - 2018-11-05 18:40:53 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\reports\collection_report.php 6
ERROR - 2018-11-05 18:45:23 --> Severity: Notice --> Undefined property: stdClass::$att_status C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 48
ERROR - 2018-11-05 18:45:23 --> Severity: Notice --> Undefined property: stdClass::$att_status C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 48
ERROR - 2018-11-05 18:45:23 --> Severity: Notice --> Undefined property: stdClass::$att_status C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 48
ERROR - 2018-11-05 18:45:23 --> Severity: Notice --> Undefined property: stdClass::$att_status C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 48
ERROR - 2018-11-05 18:45:23 --> Severity: Notice --> Undefined property: stdClass::$att_status C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 48
ERROR - 2018-11-05 18:46:03 --> Query error: Unknown column 'tbl_attendance.att_status' in 'field list' - Invalid query: SELECT `tbl_student`.*, `tbl_attendance`.`att_status`
FROM `tbl_student`
ERROR - 2018-11-05 18:47:22 --> Severity: 4096 --> Object of class Report could not be converted to string C:\xampp\htdocs\training\application\controllers\Report.php 232
ERROR - 2018-11-05 18:47:22 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\training\application\controllers\Report.php 232
ERROR - 2018-11-05 18:47:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\controllers\Report.php 232
ERROR - 2018-11-05 18:47:22 --> Severity: error --> Exception: Call to a member function where() on null C:\xampp\htdocs\training\application\controllers\Report.php 232
ERROR - 2018-11-05 18:48:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:46 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:48:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:49:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\attendance_indv.php 28
ERROR - 2018-11-05 18:57:06 --> Query error: Table 'tcms.tbl_stuff' doesn't exist - Invalid query: SELECT *
FROM `tbl_stuff`
ERROR - 2018-11-05 18:57:24 --> Query error: Table 'tcms.tbl_stuff' doesn't exist - Invalid query: SELECT *
FROM `tbl_stuff`
ERROR - 2018-11-05 18:57:24 --> Query error: Table 'tcms.tbl_stuff' doesn't exist - Invalid query: SELECT *
FROM `tbl_stuff`
ERROR - 2018-11-05 19:00:10 --> Severity: Notice --> Undefined property: stdClass::$staff_full_name C:\xampp\htdocs\training\application\views\back\reports\stuff_list.php 43
ERROR - 2018-11-05 19:00:10 --> Severity: Notice --> Undefined property: stdClass::$staff_full_name C:\xampp\htdocs\training\application\views\back\reports\stuff_list.php 43
ERROR - 2018-11-05 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$staff_contact C:\xampp\htdocs\training\application\views\back\reports\stuff_list.php 46
ERROR - 2018-11-05 19:00:38 --> Severity: Notice --> Undefined property: stdClass::$staff_contact C:\xampp\htdocs\training\application\views\back\reports\stuff_list.php 46
ERROR - 2018-11-05 19:01:04 --> Severity: Notice --> Undefined property: stdClass::$staff_joinint_date C:\xampp\htdocs\training\application\views\back\reports\stuff_list.php 47
ERROR - 2018-11-05 19:01:04 --> Severity: Notice --> Undefined property: stdClass::$staff_joinint_date C:\xampp\htdocs\training\application\views\back\reports\stuff_list.php 47
ERROR - 2018-11-05 19:22:51 --> Severity: error --> Exception: syntax error, unexpected '.' C:\xampp\htdocs\training\application\controllers\Report.php 80
ERROR - 2018-11-05 19:23:47 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date.php 50
ERROR - 2018-11-05 19:23:47 --> Severity: error --> Exception: Call to a member function format() on boolean C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date.php 6
ERROR - 2018-11-05 19:24:50 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date.php 50
ERROR - 2018-11-05 19:24:50 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date.php 50
ERROR - 2018-11-05 19:25:06 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date.php 50
ERROR - 2018-11-05 19:25:06 --> Severity: Notice --> Undefined property: stdClass::$stu_date C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date.php 50
ERROR - 2018-11-05 19:44:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date_category.php 28
ERROR - 2018-11-05 19:44:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date_category.php 28
ERROR - 2018-11-05 19:46:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date_category.php 28
ERROR - 2018-11-05 19:46:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\reports\account_report_by_date_category.php 28
ERROR - 2018-11-05 19:54:49 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:54:49 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:55:41 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:55:41 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:56:07 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:56:07 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:56:08 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:56:09 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:57:16 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:57:16 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:57:28 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
ERROR - 2018-11-05 19:57:28 --> Severity: Notice --> Undefined property: stdClass::$inquiry_id C:\xampp\htdocs\training\application\views\back\inquiry.php 59
