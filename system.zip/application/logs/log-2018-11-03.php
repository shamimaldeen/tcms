<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-03 00:03:22 --> Severity: Notice --> Undefined index: batch_id C:\xampp\htdocs\training\application\controllers\Course.php 172
ERROR - 2018-11-03 00:03:26 --> Severity: Notice --> Undefined index: batch_id C:\xampp\htdocs\training\application\controllers\Course.php 172
ERROR - 2018-11-03 00:03:41 --> Severity: Notice --> Undefined index: batch_id C:\xampp\htdocs\training\application\controllers\Course.php 172
ERROR - 2018-11-03 00:11:59 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Course.php 190
ERROR - 2018-11-03 00:11:59 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 194
ERROR - 2018-11-03 00:11:59 --> Severity: Notice --> Undefined variable: pay_id C:\xampp\htdocs\training\application\controllers\Course.php 202
ERROR - 2018-11-03 00:18:52 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Course.php 193
ERROR - 2018-11-03 00:18:52 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 197
ERROR - 2018-11-03 00:18:52 --> Severity: Notice --> Undefined variable: pay_id C:\xampp\htdocs\training\application\controllers\Course.php 205
ERROR - 2018-11-03 00:45:52 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Course.php 189
ERROR - 2018-11-03 00:45:52 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 193
ERROR - 2018-11-03 00:45:52 --> Severity: Notice --> Undefined variable: pay_id C:\xampp\htdocs\training\application\controllers\Course.php 201
ERROR - 2018-11-03 01:18:29 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Course.php 223
ERROR - 2018-11-03 01:25:44 --> Severity: Notice --> Undefined property: stdClass::$0 C:\xampp\htdocs\training\application\views\back\current_course.php 33
ERROR - 2018-11-03 01:54:17 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-03 01:54:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-03 01:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-03 01:54:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 23
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 28
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 34
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 40
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 48
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 49
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 50
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-03 01:55:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_course.php 61
ERROR - 2018-11-03 02:25:06 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:26:24 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:26:25 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:26:29 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:27:35 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:27:42 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:28:09 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:28:24 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:31:57 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:32:29 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:36:27 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:38:06 --> Severity: Notice --> Undefined property: stdClass::$course_id C:\xampp\htdocs\training\application\views\back\current_course.php 38
ERROR - 2018-11-03 02:55:22 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 02:55:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 02:58:05 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 02:58:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 02:58:13 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 02:58:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:00:00 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:00:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:00:04 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:00:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:00:58 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:00:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:01:02 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:01:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\student_info.php 31
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:01:40 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:11 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:05:19 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:46 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:53 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:53 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:53 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:06:54 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:07:48 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:08:59 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\student_info.php 35
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_sex C:\xampp\htdocs\training\application\views\back\student_info.php 36
ERROR - 2018-11-03 03:09:22 --> Severity: Notice --> Undefined property: stdClass::$stu_mobile C:\xampp\htdocs\training\application\views\back\student_info.php 37
ERROR - 2018-11-03 03:18:36 --> Query error: Unknown column 'tbl_payment.pay_id' in 'field list' - Invalid query: SELECT `tbl_student`.`stu_id`, `tbl_student`.`stu_sex`, `tbl_student`.`stu_mobile`, `tbl_student`.`stu_name`, `tbl_courseapply`.`capply_id`, `tbl_course`.`course_id`, `tbl_course`.`course_title`, `tbl_course`.`course_duration`, `tbl_payment`.`pay_id`, `tbl_payment`.`pay_date`, `tbl_payment`.`pay_tra_id`, `tbl_payment`.`pay_method`, `tbl_batch`.`batch_title`, `tbl_batch`.`batch_id`
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_batch` ON `tbl_batch`.`batch_id` =  `tbl_courseapply`.`batch_id`
WHERE `tbl_payment`.`pay_status` = 'approved'
AND `tbl_courseapply`.`course_id` = '2'
AND `tbl_courseapply`.`batch_id` = '3'
ERROR - 2018-11-03 10:48:04 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\training\application\views\back\student_info.php 56
ERROR - 2018-11-03 11:03:21 --> Query error: Unknown column 'tbl_course' in 'where clause' - Invalid query: SELECT *
FROM `tbl_course`
WHERE `tbl_course` = '1'
ERROR - 2018-11-03 11:03:41 --> Query error: Unknown column 'tbl_batch' in 'where clause' - Invalid query: SELECT *
FROM `tbl_batch`
WHERE `tbl_batch` = '3'
ERROR - 2018-11-03 11:04:24 --> Query error: Unknown column 'tbl_course' in 'where clause' - Invalid query: SELECT *
FROM `tbl_course`
WHERE `tbl_course` = '1'
ERROR - 2018-11-03 11:04:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\student_info.php 11
ERROR - 2018-11-03 11:04:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\student_info.php 11
ERROR - 2018-11-03 11:04:55 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\student_info.php 11
ERROR - 2018-11-03 11:04:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\student_info.php 11
ERROR - 2018-11-03 11:05:08 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\student_info.php 11
ERROR - 2018-11-03 11:05:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\student_info.php 11
ERROR - 2018-11-03 12:31:33 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 12:31:33 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 12:31:33 --> Severity: Notice --> Undefined variable: batch_id C:\xampp\htdocs\training\application\controllers\Course.php 302
ERROR - 2018-11-03 12:33:02 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 12:33:16 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 12:33:48 --> Severity: error --> Exception: Too few arguments to function Course::complited_course(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Course.php 289
ERROR - 2018-11-03 12:33:50 --> Severity: error --> Exception: Too few arguments to function Course::complited_course(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Course.php 289
ERROR - 2018-11-03 12:34:28 --> Severity: error --> Exception: Too few arguments to function Course::complited_course(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Course.php 289
ERROR - 2018-11-03 12:34:38 --> Severity: error --> Exception: Too few arguments to function Course::complited_course(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Course.php 289
ERROR - 2018-11-03 12:36:29 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 12:36:32 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 12:37:32 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 12:38:28 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 13:01:00 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 13:03:38 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 13:50:08 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 300
ERROR - 2018-11-03 13:51:40 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 13:51:42 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 13:51:55 --> Severity: error --> Exception: syntax error, unexpected ''tbl_courseapply.capply_id'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 13:55:33 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 13:55:44 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 13:55:45 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 13:55:45 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 13:55:46 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 13:55:46 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 14:19:09 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 14:19:14 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 14:22:25 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 16:02:39 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 16:44:11 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 16:44:11 --> Severity: Notice --> Undefined variable: capply_id C:\xampp\htdocs\training\application\controllers\Course.php 301
ERROR - 2018-11-03 17:54:58 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:54:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:55:05 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:55:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:55:57 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:55:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:56:25 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:56:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:58:01 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:58:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:58:08 --> Severity: Notice --> Undefined variable: applications C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 17:58:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\back\certificates_archive.php 35
ERROR - 2018-11-03 22:52:25 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 22:52:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 22:52:25 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:52:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:52:28 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 22:52:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 22:52:28 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:52:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:53:04 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 22:53:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 22:53:04 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:53:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:53:09 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 22:53:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 22:53:09 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:53:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:55:00 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:55:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:55:00 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:55:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:55:06 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 22:55:06 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:55:53 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:55:53 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:55:53 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:55:53 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:56:50 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:56:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:56:50 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:56:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:57:58 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:57:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:57:58 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:57:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:58:07 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:58:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:58:07 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:58:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:58:10 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:58:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:58:10 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:58:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:59:02 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:59:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 22:59:02 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 22:59:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:01:14 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 23:01:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 23:01:14 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 17
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:01:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:02:34 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 23:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 23:02:34 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:02:34 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 23:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 36
ERROR - 2018-11-03 23:02:34 --> Severity: Notice --> Undefined variable: students C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:02:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:03:41 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:05:04 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:05:04 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:05:04 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:05:04 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:07:09 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:07:09 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:07:10 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:07:10 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:08:47 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:08:47 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:08:47 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:08:47 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:10:34 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:10:34 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:10:39 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:10:39 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:10:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:10:40 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:10:41 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:10:41 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:10:42 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:10:42 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:10:42 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:10:42 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:10:50 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:10:50 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
ERROR - 2018-11-03 23:10:58 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 23
ERROR - 2018-11-03 23:10:58 --> Severity: Notice --> Undefined property: stdClass::$stu_name C:\xampp\htdocs\training\application\views\back\attendance_entry.php 41
