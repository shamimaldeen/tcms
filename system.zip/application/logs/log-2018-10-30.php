<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-30 04:51:03 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\training\application\views\student\index.php 47
ERROR - 2018-10-30 04:51:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\index.php 47
ERROR - 2018-10-30 00:06:27 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Student.php 42
ERROR - 2018-10-30 13:49:15 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\student\update_student.php 25
ERROR - 2018-10-30 13:49:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\update_student.php 25
ERROR - 2018-10-30 13:49:15 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\student\update_student.php 26
ERROR - 2018-10-30 13:49:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\update_student.php 26
ERROR - 2018-10-30 09:42:44 --> Query error: Column 'stu_sex' cannot be null - Invalid query: INSERT INTO `tbl_student` (`stu_name`, `stu_dob`, `stu_sex`, `stu_religion`, `stu_marital`, `stu_nid`, `stu_occupation`, `stu_image`, `stu_father`, `stu_mother`, `stu_guardian`, `stu_relation`, `stu_guardian_mobile`, `stu_mobile`, `stu_email`, `stu_password`, `stu_present_address`, `stu_permanent_address`, `stu_have_experience`, `stu_institute`, `stu_session`, `stu_trade`, `stu_roll`, `stu_examination`, `stu_board`, `stu_group`, `stu_pass_year`, `stu_result`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '7d43ea0b4cd43a4f7d1a40f6eb8be9f3', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL)
ERROR - 2018-10-30 15:46:11 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Student.php 128
ERROR - 2018-10-30 15:46:11 --> Severity: Notice --> Undefined variable: stu_marital C:\xampp\htdocs\training\application\controllers\Student.php 131
ERROR - 2018-10-30 15:46:11 --> Severity: Notice --> Undefined variable: stu_occupation C:\xampp\htdocs\training\application\controllers\Student.php 132
ERROR - 2018-10-30 15:46:11 --> Severity: Notice --> Undefined variable: stu_guardian C:\xampp\htdocs\training\application\controllers\Student.php 133
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_relation C:\xampp\htdocs\training\application\controllers\Student.php 134
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_guardian_mobile C:\xampp\htdocs\training\application\controllers\Student.php 135
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_mobile C:\xampp\htdocs\training\application\controllers\Student.php 136
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_email C:\xampp\htdocs\training\application\controllers\Student.php 137
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_present_address C:\xampp\htdocs\training\application\controllers\Student.php 138
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_examination C:\xampp\htdocs\training\application\controllers\Student.php 139
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_board C:\xampp\htdocs\training\application\controllers\Student.php 140
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_group C:\xampp\htdocs\training\application\controllers\Student.php 141
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_pass_year C:\xampp\htdocs\training\application\controllers\Student.php 142
ERROR - 2018-10-30 15:46:12 --> Severity: Notice --> Undefined variable: stu_result C:\xampp\htdocs\training\application\controllers\Student.php 143
ERROR - 2018-10-30 15:48:39 --> Severity: Notice --> Undefined variable: stu_marital C:\xampp\htdocs\training\application\controllers\Student.php 131
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_occupation C:\xampp\htdocs\training\application\controllers\Student.php 132
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_guardian C:\xampp\htdocs\training\application\controllers\Student.php 133
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_relation C:\xampp\htdocs\training\application\controllers\Student.php 134
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_guardian_mobile C:\xampp\htdocs\training\application\controllers\Student.php 135
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_mobile C:\xampp\htdocs\training\application\controllers\Student.php 136
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_email C:\xampp\htdocs\training\application\controllers\Student.php 137
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_present_address C:\xampp\htdocs\training\application\controllers\Student.php 138
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_examination C:\xampp\htdocs\training\application\controllers\Student.php 139
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_board C:\xampp\htdocs\training\application\controllers\Student.php 140
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_group C:\xampp\htdocs\training\application\controllers\Student.php 141
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_pass_year C:\xampp\htdocs\training\application\controllers\Student.php 142
ERROR - 2018-10-30 15:48:40 --> Severity: Notice --> Undefined variable: stu_result C:\xampp\htdocs\training\application\controllers\Student.php 143
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_marital C:\xampp\htdocs\training\application\controllers\Student.php 131
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_occupation C:\xampp\htdocs\training\application\controllers\Student.php 132
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_guardian C:\xampp\htdocs\training\application\controllers\Student.php 133
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_relation C:\xampp\htdocs\training\application\controllers\Student.php 134
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_guardian_mobile C:\xampp\htdocs\training\application\controllers\Student.php 135
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_mobile C:\xampp\htdocs\training\application\controllers\Student.php 136
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_email C:\xampp\htdocs\training\application\controllers\Student.php 137
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_present_address C:\xampp\htdocs\training\application\controllers\Student.php 138
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_examination C:\xampp\htdocs\training\application\controllers\Student.php 139
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_board C:\xampp\htdocs\training\application\controllers\Student.php 140
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_group C:\xampp\htdocs\training\application\controllers\Student.php 141
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_pass_year C:\xampp\htdocs\training\application\controllers\Student.php 142
ERROR - 2018-10-30 15:48:41 --> Severity: Notice --> Undefined variable: stu_result C:\xampp\htdocs\training\application\controllers\Student.php 143
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_marital C:\xampp\htdocs\training\application\controllers\Student.php 131
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_occupation C:\xampp\htdocs\training\application\controllers\Student.php 132
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_guardian C:\xampp\htdocs\training\application\controllers\Student.php 133
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_relation C:\xampp\htdocs\training\application\controllers\Student.php 134
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_guardian_mobile C:\xampp\htdocs\training\application\controllers\Student.php 135
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_mobile C:\xampp\htdocs\training\application\controllers\Student.php 136
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_email C:\xampp\htdocs\training\application\controllers\Student.php 137
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_present_address C:\xampp\htdocs\training\application\controllers\Student.php 138
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_examination C:\xampp\htdocs\training\application\controllers\Student.php 139
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_board C:\xampp\htdocs\training\application\controllers\Student.php 140
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_group C:\xampp\htdocs\training\application\controllers\Student.php 141
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_pass_year C:\xampp\htdocs\training\application\controllers\Student.php 142
ERROR - 2018-10-30 15:48:43 --> Severity: Notice --> Undefined variable: stu_result C:\xampp\htdocs\training\application\controllers\Student.php 143
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_marital C:\xampp\htdocs\training\application\controllers\Student.php 131
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_occupation C:\xampp\htdocs\training\application\controllers\Student.php 132
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_guardian C:\xampp\htdocs\training\application\controllers\Student.php 133
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_relation C:\xampp\htdocs\training\application\controllers\Student.php 134
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_guardian_mobile C:\xampp\htdocs\training\application\controllers\Student.php 135
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_mobile C:\xampp\htdocs\training\application\controllers\Student.php 136
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_email C:\xampp\htdocs\training\application\controllers\Student.php 137
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_present_address C:\xampp\htdocs\training\application\controllers\Student.php 138
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_examination C:\xampp\htdocs\training\application\controllers\Student.php 139
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_board C:\xampp\htdocs\training\application\controllers\Student.php 140
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_group C:\xampp\htdocs\training\application\controllers\Student.php 141
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_pass_year C:\xampp\htdocs\training\application\controllers\Student.php 142
ERROR - 2018-10-30 15:51:19 --> Severity: Notice --> Undefined variable: stu_result C:\xampp\htdocs\training\application\controllers\Student.php 143
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 25
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 25
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 26
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 26
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 39
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 39
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 45
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 45
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 61
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 61
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 68
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 68
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 78
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 78
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 88
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 88
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 97
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 97
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 108
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 108
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 129
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 129
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 136
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 136
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 144
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 144
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 145
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 145
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 146
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 146
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 147
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 147
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 157
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 157
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 164
ERROR - 2018-10-30 11:13:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 164
ERROR - 2018-10-30 11:15:20 --> Severity: Notice --> Undefined index: view_students_archive C:\xampp\htdocs\training\application\controllers\Studentsarchive.php 70
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 25
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 25
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 26
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 26
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 39
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 39
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 45
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 45
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 61
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 61
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 68
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 68
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 78
ERROR - 2018-10-30 11:15:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 78
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 88
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 88
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 97
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 97
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 108
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 108
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 129
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 129
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 136
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 136
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 144
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 144
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 145
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 145
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 146
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 146
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 147
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 147
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 157
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 157
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Undefined variable: update_student C:\xampp\htdocs\training\application\views\back\edit_student.php 164
ERROR - 2018-10-30 11:15:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 164
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 25
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 26
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 27
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 28
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 41
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 42
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 48
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 49
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 65
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 66
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 73
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 74
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 84
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 85
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 95
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 96
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 105
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 106
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 117
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 118
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 139
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 140
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 147
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 148
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 156
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 157
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 158
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 159
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 160
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 161
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 162
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 163
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 173
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 174
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 181
ERROR - 2018-10-30 11:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 182
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 25
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 26
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 27
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 28
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 41
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 42
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 48
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 49
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 65
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 66
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 73
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 74
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 84
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 85
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 95
ERROR - 2018-10-30 11:16:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 96
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 105
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 106
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 117
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 118
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 139
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 140
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 147
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 148
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 156
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 157
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 158
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 159
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 160
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 161
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 162
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 163
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 173
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 174
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 181
ERROR - 2018-10-30 11:16:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 182
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 25
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 26
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 27
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 28
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 41
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 42
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 48
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 49
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 65
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 66
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 73
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 74
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 84
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 85
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 95
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 96
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 105
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 106
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 117
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 118
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 139
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 140
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 147
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 148
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 156
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 157
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 158
ERROR - 2018-10-30 11:16:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 159
ERROR - 2018-10-30 11:16:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 160
ERROR - 2018-10-30 11:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 161
ERROR - 2018-10-30 11:16:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 162
ERROR - 2018-10-30 11:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 163
ERROR - 2018-10-30 11:16:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 173
ERROR - 2018-10-30 11:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 174
ERROR - 2018-10-30 11:16:36 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\back\edit_student.php 181
ERROR - 2018-10-30 11:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\edit_student.php 182
ERROR - 2018-10-30 11:22:02 --> Severity: error --> Exception: Call to undefined method Studentsarchive::update_image() C:\xampp\htdocs\training\application\controllers\Studentsarchive.php 109
ERROR - 2018-10-30 13:28:44 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\training\application\controllers\Studentcourse.php 21
ERROR - 2018-10-30 13:33:41 --> Severity: error --> Exception: syntax error, unexpected 'public' (T_PUBLIC), expecting end of file C:\xampp\htdocs\training\application\controllers\Studentcourse.php 21
ERROR - 2018-10-30 14:44:02 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:44:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:44:05 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:44:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:44:42 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:44:44 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:44:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:45:05 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:45:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 12
ERROR - 2018-10-30 14:55:32 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:55:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:55:34 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:55:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:20 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:22 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:25 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:55 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:57 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:57:02 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:57:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:57:19 --> Severity: Notice --> Undefined variable: course C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 14:57:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\student\applycourse_details.php 14
ERROR - 2018-10-30 17:05:47 --> Severity: error --> Exception: Too few arguments to function Studentcourse::applycourse(), 0 passed in C:\xampp\htdocs\training\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\training\application\controllers\Studentcourse.php 59
ERROR - 2018-10-30 17:49:57 --> Query error: Column 'pay_method' cannot be null - Invalid query: INSERT INTO `tbl_payment` (`pay_paidamount`, `pay_method`, `pay_tra_id`) VALUES (NULL, NULL, NULL)
ERROR - 2018-10-30 17:56:25 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\training\application\controllers\Studentcourse.php 81
ERROR - 2018-10-30 19:44:15 --> Severity: error --> Exception: syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\training\application\controllers\Course.php 135
ERROR - 2018-10-30 19:47:01 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::orderby() C:\xampp\htdocs\training\application\controllers\Studentcourse.php 87
ERROR - 2018-10-30 19:48:47 --> Query error: Column 'pay_method' cannot be null - Invalid query: INSERT INTO `tbl_payment` (`pay_paidamount`, `pay_method`, `pay_tra_id`, `stu_id`, `pay_date`) VALUES (NULL, NULL, NULL, '16', '2018-10-30')
ERROR - 2018-10-30 19:49:05 --> Severity: Notice --> Undefined variable: stu_id C:\xampp\htdocs\training\application\controllers\Studentcourse.php 92
ERROR - 2018-10-30 19:49:05 --> Severity: Notice --> Undefined variable: course_id C:\xampp\htdocs\training\application\controllers\Studentcourse.php 93
ERROR - 2018-10-30 19:51:19 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\training\application\controllers\Studentcourse.php 92
ERROR - 2018-10-30 19:51:48 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ']' C:\xampp\htdocs\training\application\controllers\Studentcourse.php 93
ERROR - 2018-10-30 19:51:50 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ']' C:\xampp\htdocs\training\application\controllers\Studentcourse.php 93
ERROR - 2018-10-30 19:52:15 --> Query error: Column 'pay_method' cannot be null - Invalid query: INSERT INTO `tbl_payment` (`pay_paidamount`, `pay_method`, `pay_tra_id`, `stu_id`, `pay_date`) VALUES (NULL, NULL, NULL, '16', '2018-10-30')
ERROR - 2018-10-30 19:52:37 --> Severity: Notice --> Undefined index: course_id C:\xampp\htdocs\training\application\controllers\Studentcourse.php 93
ERROR - 2018-10-30 19:52:37 --> Severity: Notice --> Undefined index: pay_id C:\xampp\htdocs\training\application\controllers\Studentcourse.php 94
ERROR - 2018-10-30 20:33:38 --> Severity: Notice --> Undefined index: course_id C:\xampp\htdocs\training\application\controllers\Studentcourse.php 93
ERROR - 2018-10-30 20:33:38 --> Severity: Notice --> Undefined index: pay_id C:\xampp\htdocs\training\application\controllers\Studentcourse.php 94
ERROR - 2018-10-30 20:35:32 --> Query error: Unknown column 'course_id' in 'field list' - Invalid query: INSERT INTO `tbl_payment` (`pay_paidamount`, `pay_method`, `pay_tra_id`, `stu_id`, `pay_date`, `course_id`) VALUES ('500', 'Rocket', '6544', '16', '2018-10-30', 'Rocket')
ERROR - 2018-10-30 20:36:23 --> Severity: Notice --> Undefined index: pay_id C:\xampp\htdocs\training\application\controllers\Studentcourse.php 95
ERROR - 2018-10-30 20:44:13 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_result::result_objct() C:\xampp\htdocs\training\application\controllers\Course.php 136
ERROR - 2018-10-30 20:45:55 --> Query error: Unknown column 'tbl_courseapply' in 'field list' - Invalid query: SELECT `tbl_student`.`stu_id`, `tbl_student`.`stu_name`, `tbl_courseapply`
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
ERROR - 2018-10-30 20:49:04 --> Query error: Unknown column 'tbl_payment.tra_id' in 'field list' - Invalid query: SELECT `tbl_student`.`stu_id`, `tbl_student`.`stu_name`, `tbl_course`.`course_title`, `tbl_course`.`course_duration`, `tbl_payment`.`pay_date`, `tbl_payment`.`tra_id`, `tbl_payment`.`pay_method`
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
ERROR - 2018-10-30 20:57:40 --> Severity: Notice --> Undefined property: mysqli::$stu_id C:\xampp\htdocs\training\application\views\back\courseapp.php 33
ERROR - 2018-10-30 20:57:40 --> Severity: Notice --> Undefined property: mysqli_result::$stu_id C:\xampp\htdocs\training\application\views\back\courseapp.php 33
ERROR - 2018-10-30 20:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\courseapp.php 33
ERROR - 2018-10-30 20:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\courseapp.php 33
ERROR - 2018-10-30 20:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\courseapp.php 33
ERROR - 2018-10-30 20:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\courseapp.php 33
ERROR - 2018-10-30 20:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\courseapp.php 33
ERROR - 2018-10-30 20:57:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\back\courseapp.php 33
ERROR - 2018-10-30 20:58:05 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\training\application\views\back\courseapp.php 3
ERROR - 2018-10-30 21:06:18 --> Query error: Unknown column 'tbl_payment' in 'where clause' - Invalid query: SELECT `tbl_student`.`stu_id`, `tbl_courseapply`.`capply_id`, `tbl_student`.`stu_name`, `tbl_course`.`course_title`, `tbl_course`.`course_duration`, `tbl_payment`.`pay_id`, `tbl_payment`.`pay_date`, `tbl_payment`.`pay_tra_id`, `tbl_payment`.`pay_method`
FROM `tbl_courseapply`
JOIN `tbl_student` ON `tbl_student`.`stu_id` =  `tbl_courseapply`.`stu_id`
JOIN `tbl_course` ON `tbl_course`.`course_id` =  `tbl_courseapply`.`course_id`
JOIN `tbl_payment` ON `tbl_payment`.`pay_id` =  `tbl_courseapply`.`pay_id`
WHERE `tbl_payment` = 'tbl_payment.pay_status = pending'
ERROR - 2018-10-30 21:39:02 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:39:02 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:41:39 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:41:39 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:41:39 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:41:39 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:44:08 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:44:08 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:44:08 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:44:08 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:45:22 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:45:22 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:45:22 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:45:22 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:47:02 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:47:02 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:47:02 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:47:02 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:48:48 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:48:48 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
ERROR - 2018-10-30 21:48:48 --> Severity: Notice --> Undefined property: stdClass::$inquiry_date C:\xampp\htdocs\training\application\views\back\inquiry.php 31
ERROR - 2018-10-30 21:48:48 --> Severity: Notice --> Undefined property: stdClass::$inquiry_details C:\xampp\htdocs\training\application\views\back\inquiry.php 34
