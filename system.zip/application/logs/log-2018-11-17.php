<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-17 17:53:00 --> Severity: error --> Exception: syntax error, unexpected '}', expecting elseif (T_ELSEIF) or else (T_ELSE) or endif (T_ENDIF) C:\xampp\htdocs\training\application\views\front\index.php 25
ERROR - 2018-11-17 17:53:05 --> Severity: error --> Exception: syntax error, unexpected '}', expecting elseif (T_ELSEIF) or else (T_ELSE) or endif (T_ENDIF) C:\xampp\htdocs\training\application\views\front\index.php 25
