<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-11-18 09:00:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\training\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2018-11-18 09:00:05 --> Unable to connect to the database
ERROR - 2018-11-18 09:08:39 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:08:39 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:10:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:10:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:10:56 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:10:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:11:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:11:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:11:06 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:11:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:12:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:12:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:12:43 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:12:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:13:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:13:02 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:13:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:15:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:15:53 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:16:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:16:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:16:30 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:16:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:16:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:16:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:16:33 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:16:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:17:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:17:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:17:12 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:17:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:17:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:17:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:17:14 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:17:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:18:10 --> Severity: error --> Exception: syntax error, unexpected '?>' C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:30:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:30:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:30:07 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:30:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:30:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:30:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 47
ERROR - 2018-11-18 09:30:18 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 09:30:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\index.php 54
ERROR - 2018-11-18 11:05:56 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-18 11:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 4
ERROR - 2018-11-18 11:05:56 --> Severity: Notice --> Undefined variable: abouts C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-18 11:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\about.php 26
ERROR - 2018-11-18 11:14:48 --> Severity: Notice --> Undefined variable: news C:\xampp\htdocs\training\application\views\front\news.php 5
ERROR - 2018-11-18 11:14:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news.php 5
ERROR - 2018-11-18 11:37:20 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 5
ERROR - 2018-11-18 11:37:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news.php 5
ERROR - 2018-11-18 11:37:20 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:37:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:38:29 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 5
ERROR - 2018-11-18 11:38:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news.php 5
ERROR - 2018-11-18 11:38:29 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:38:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:39:57 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 5
ERROR - 2018-11-18 11:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\training\application\views\front\news.php 5
ERROR - 2018-11-18 11:39:57 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:41:01 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:41:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:41:09 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:41:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:41:11 --> Severity: Notice --> Undefined variable: News C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 11:41:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\news.php 16
ERROR - 2018-11-18 12:00:45 --> Severity: Notice --> Undefined variable: courses C:\xampp\htdocs\training\application\views\front\course.php 19
ERROR - 2018-11-18 12:00:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\training\application\views\front\course.php 19
