
						<div class="wrapper">
							<div class="container"> 
								<div class="row">
									<div class="span12">
										<div class="content">
											<div class="module">
												<div class="module-head">
													<div class="module-option clearfix">
														<div class="pull-left">
															<h3>Inquiry</h3>
														</div>
														<div class="pull-right">
														</div>
													</div>
												</div>
												<div class="module-body table">
													<table cellpadding="0" cellspacing="0" border="0" class="datatable-1 table table-bordered table-striped	 display" width="100%">
														<thead>
															<tr>
																<th nowrap  >Date</th>
																<th nowrap  >Student ID</th>
																<th  nowrap> Student Name</th>
																<th  nowrap> Inquiry Subject</th>
																<th nowrap width="1%"> - </th>
															</tr>
														</thead>
														<tbody>
															<tr class="odd gradeX">
																<td nowrap>01-12-2018</td>
																<td nowrap>4655</td>
																<td nowrap>Ariful Islam</td>
																<td nowrap>The quick brown fox jumps over the lazy dog</td>
																<td nowrap> 
																	<button type="button" class="btn btn-warning" data-toggle="modal" data-target="#myModal"> <i class="menu-icon icon-share-alt"></i> Replay </button>
																</td>
															</tr>
														</tbody>
														<tfoot>
														</tfoot>
													</table>
												</div>
											</div><!--/.module-->
										</div><!--/.content-->
									</div><!--/.span9-->
								</div>
							</div>
							<!--/.container-->
						</div>
						<!--/.wrapper-->
							
						<!-- Modal -->
						<div id="myModal" class="modal fade" role="dialog">
							<div class="modal-dialog">
								<!-- Modal content-->
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal">&times;</button>
										<h4 class="modal-title">Replay </h4>
									</div>
									<div class="modal-body">
										<form action="print_report.php" method="get">
											<div class="row-fluid">
												<div class="span12">
													<div class="form-group">
														<p>
															The quick brown fox jumps over the lazy dog.The quick brown fox jumps over the lazy dog.The quick brown fox jumps over the lazy dog.
														</p></div>
												</div>
											</div>
											<div class="row-fluid">
												<div class="span12">
													<div class="form-group">
														<label>Replay</label>
														<textarea class="span12"  id="editor" rows="4"> </textarea>
													</div>
												</div>
											</div>
										</div>
									</div>
								</form>
							</div>
							<div class="modal-footer">
								<center>
									<button type="submit" class="btn-large btn-success"><i class="menu-icon icon-Save"></i> Done</button>
								</center>
							</div>
						</div>
					</div>
					</div>																				