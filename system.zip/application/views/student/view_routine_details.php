<div class="wrapper">
							<div class="container"> 
								<div class="row">
									<!--/.span3-->
									<div class="span12">
										<div class="content">
											<div class="module">
												<div class="module-head">
													<h3> Routine  Details  </h3>
												</div>
												<div class="module-body">


												

														<div class="row-fluid">
															<div class="control-group">
																<label class="control-label" for="basicinput"></label>
																<div class="controls">
																	 <?php echo $routines[0]->routine_details;?>
																</div>
															</div>
														</div>
													
													</div>
								
											</div>
										</div><!--/.content-->
									</div><!--/.span9-->
									<div style="" class="span2">
										<div class="sidebar">

														</div><!--/.sidebar-->
									</div>
								</div>
							</div>
						<!--/.container-->
						</div>
						<!--/.wrapper-->
						
						<script src='http://cdn.tinymce.com/4/tinymce.min.js'></script> 						<script src="index.js"></script>											